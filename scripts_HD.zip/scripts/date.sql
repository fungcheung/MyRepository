alter session set NLS_DATE_FORMAT='DD-MM-RR HH24:MI:SS';
