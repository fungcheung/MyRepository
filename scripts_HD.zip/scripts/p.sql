set echo off
set verify off

prompt Enter parameter to display
prompt For example: %recovery%


SELECT 
    name 
    ,value 
--    ,display_value 
    ,issys_modifiable 
--    ,description 
FROM v$parameter 
WHERE name like '&1';
