set pages 2000 line 200
set feed on
set sqlprompt  "_user'@'_connect_identifier:SQL> "
-- set time on
-- set timing on
column owner format a15
column name format a30
column type format a15
column object_name format a30
column segment_name format a30
column table_name format a30
column column_name format a30
column object_type format a30

@@date
