@echo off
setlocal enabledelayedexpansion
set "alp=@ # % a A b B c C d D E e f F g G h H j J k K m M n N p P q Q r R s S t T u U v V w W x X y Y z Z 1 2 3 4 5 6 7 8 9"
set "cnt=0"
for %%a in (%alp%) do (
    set "rn.!cnt!=%%a"
    set /a "cnt+=1"
)
for /l %%i in (1,1,10) do (
 set "pssw="
 for /l %%a in (1,1,8) do (
    set /a "rand=!random! %% cnt"
    for %%b in (!rand!) do set "pssw=!pssw!!rn.%%b!"
)
 echo Your random password is: [ !pssw! ]
)