whenever sqlerror exit rollback;
set linesize 200
set pagesize 10000
set serveroutput on size 1000000
set echo on
set feedback on

set verify off
spool 'create_bkupuser.log'

create user BKUPUSER identified by Welcome1#;
grant create session to BKUPUSER;
grant sysbackup to BKUPUSER;
grant select any table to BKUPUSER;
grant alter system to BKUPUSER;
alter user SYSBACKUP account lock;

show errors
spool off
