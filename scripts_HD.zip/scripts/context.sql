column user format a20
column instance_name format a20
column server_host format a30
column current_schema format a20

select user,sys_context('userenv','instance_name') instance_name, sys_context('userenv','server_host') server_host, SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') current_schema from dual;
