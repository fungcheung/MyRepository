"%ProgramFiles%\Windows NT\Accessories\wordpad.exe" %1
