# \\housing\projects\team17(DA)\data_admin\Documentation\DBA Documents\eServices Platform\ESP 2.0 Project\Oracle documents\
# pesdbs11_oop_20251217.txt

# Grid Infrastructure Release Update 19.29.0.0.251021                    | PATCH 38298204
# regression tracking bug filed from mergereq                            | p30600773_1929000DBRU_Linux-x86-64.zip
# Data Pump Recommended Proactive Patches For 19.10 and Above (KB160561) | p38535360_1929000DBRU_Generic.zip

### 1.  SIT DB ###
### 1.1 prepare db home ###
ssh oracle@sesdbs12
cd /app/software-download/oracle
ls -lh LINUX.X64_193000_grid_home.zip LINUX.X64_193000_db_home.zip
ls -lh *6880880* *38298204* p30600773_1929000DBRU_Linux-x86-64.zip p38535360_1929000DBRU_Generic.zip

unzip p38298204_190000_Linux-x86-64.zip

. oraenv <<< disp2
echo $ORACLE_SID
cd /app/oracle/product/19.0.0/sit
ls -l
mkdir -p /app/oracle/product/19.0.0/sit/dbhome_29
cd /app/oracle/product/19.0.0/sit/dbhome_29
unzip -qa /app/software-download/oracle/LINUX.X64_193000_db_home.zip
rm -rf OPatch
unzip -qa /app/software-download/oracle/p6880880_190000_Linux-x86-64.zip
cd OPatch
# confirm OPatch Version: 12.2.0.1.48
./opatch version

cd /app/software-download/oracle
unzip -qa p30600773_1929000DBRU_Linux-x86-64.zip
unzip -qa p38535360_1929000DBRU_Generic.zip

ls -lh OOP-sitdb.rsp
grep '^[^#].*=' OOP-sitdb.rsp

export ORACLE_HOME=/app/oracle/product/19.0.0/sit/dbhome_29
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH
cd $ORACLE_HOME
# confirm directory /app/oracle/product/19.0.0/sit/dbhome_29
pwd
export CV_ASSUME_DISTID=OL7
export TMP=/app/tmp
export TMPDIR=/app/tmp
ls -lh /app/software-download/oracle/{OOP-sitdb.rsp,38298204,30600773,38535360}
# real    16m55.571s
time $ORACLE_HOME/runInstaller -silent -ignorePrereq -waitforcompletion -responseFile /app/software-download/oracle/OOP-sitdb.rsp -applyRU /app/software-download/oracle/38298204 -applyOneOffs /app/software-download/oracle/30600773,/app/software-download/oracle/38535360

export ORACLE_HOME=/app/oracle/product/19.0.0/sit/dbhome_29
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH
cd $ORACLE_HOME/rdbms/lib
make -f ins_rdbms.mk uniaud_on ioracle ORACLE_HOME=$ORACLE_HOME
sudo -i
/app/oracle/product/19.0.0/sit/dbhome_29/root.sh
exit
cd /app/oracle/product/19.0.0/sit/dbhome
cp -pr dbs network /app/oracle/product/19.0.0/sit/dbhome_29
# change oracle base to no _
cat $ORACLE_HOME/install/orabasetab
sed -i 's/_[^:]*:/:/' $ORACLE_HOME/install/orabasetab

##* begin run in [sesdbs11] *##
export ORACLE_HOME=/app/oracle/product/19.0.0/sit/dbhome_29
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH
cd $ORACLE_HOME/rdbms/lib
make -f ins_rdbms.mk uniaud_on ioracle ORACLE_HOME=$ORACLE_HOME
sudo -i
/app/oracle/product/19.0.0/sit/dbhome_29/root.sh
exit
cd /app/oracle/product/19.0.0/sit/dbhome
cp -pr dbs network /app/oracle/product/19.0.0/sit/dbhome_29
cat $ORACLE_HOME/install/orabasetab
sed -i 's/_[^:]*:/:/' $ORACLE_HOME/install/orabasetab
##* end run in [sesdbs11] *##

### 1.2 switch db home ###
# check existing config before restart db
. oraenv <<< disp2
echo $ORACLE_HOME
$ORACLE_HOME/bin/srvctl config database -verbose > /app/software-download/oracle/log/sitdb_before_$(date -I | tr -d '-')

lst="bis cpe eas eha esu haw hst isp lph mat nce"
db_list=$(echo "$lst" | awk '{for(i=1;i<=NF;i++) $i="d"$i""} 1')
echo $db_list
{
for db in $db_list ; do
echo -e "\n###  Configuration of database $db"
$ORACLE_HOME/bin/srvctl config database -d $db
echo -e "\n###  Status of database $db"
$ORACLE_HOME/bin/srvctl status database -d $db
echo -e "\n###  Service Configuration of database $db"
$ORACLE_HOME/bin/srvctl config service -d $db
done
} | tee -a /app/software-download/oracle/log/sitdb_before_$(date -I | tr -d '-')
 
SID_LIST=$(echo "$lst" | awk '{for(i=1;i<=NF;i++) $i="d"$i"2"} 1')
echo $SID_LIST
export JAVA_TOOL_OPTIONS="-Djansi.tmpdir=/app/tmp"
for sid in $SID_LIST ; do
. oraenv <<< $sid
sql -S / as sysdba <<< @/app/software-download/oracle/DB_patch_check.sql
done
ls -lt /app/software-download/oracle/log | head -12

echo $ORACLE_HOME
export WORK_DIR=/app/software-download/oracle/log
# restart to use new home #
$ORACLE_HOME/bin/srvctl stop home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/sitdb_status.sesdbs11-2.out
cd /app/oracle/product/19.0.0/sit/
ln -sfn dbhome_29 dbhome
$ORACLE_HOME/bin/srvctl start home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/sitdb_status.sesdbs11-2.out
srvctl status database -thishome

##* begin run in [sesdbs11] *##
. oraenv <<< disp1
echo $ORACLE_HOME
export WORK_DIR=/app/software-download/oracle/log
$ORACLE_HOME/bin/srvctl stop home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/sitdb_status.sesdbs11-2.out
cd /app/oracle/product/19.0.0/sit/
ln -sfn dbhome_29 dbhome
$ORACLE_HOME/bin/srvctl start home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/sitdb_status.sesdbs11-2.out
srvctl status database -thishome
##* end run in [sesdbs11] *##

### 1.3 datapatch ###
ssh oracle@sesdbs12
lst="bis cpe eas eha esu haw hst isp lph mat nce"
SID_LIST=$(echo "$lst" | awk '{for(i=1;i<=NF;i++) $i="d"$i"2"} 1')
echo $SID_LIST

echo $ORACLE_HOME
export WORK_DIR=/app/software-download/oracle/log
export PATH=$ORACLE_HOME/bin:$PATH
cd $ORACLE_HOME/OPatch/
for sid in $SID_LIST ; do
. oraenv <<< $sid
./datapatch -verbose >> $WORK_DIR/datapatch_${sid} 
done

ls -lt $WORK_DIR/datapatch_* | head -12
grep '^Patch ' $WORK_DIR/datapatch_*

{
for sid in $SID_LIST ; do
. oraenv <<< $sid
sqlplus / as sysdba <<'eof'
select bugno, value, is_default from v$system_fix_control where bugno =30587089 ;
alter system set "_fix_control"='30587089:1' scope=both ;
select bugno, value, is_default from v$system_fix_control where bugno =30587089 ;
exit
eof
done
} | tee /app/software-download/oracle/log/sitdb_30587089.out

### 2.  GRID ###
### 2.1 prepare grid home ###
ssh grid@sesdbs12
sudo su - 
cd /app/19.0.0/
mkdir /app/19.0.0/grid_29
chown grid:oinstall grid_29

##* begin run in [sesdbs11] *##
sudo su - 
cd /app/19.0.0/
mkdir /app/19.0.0/grid_29
chown grid:oinstall grid_29
##* end run in [sesdbs11] *##

su - grid
cd /app/19.0.0/grid_29
unzip -qa /app/software-download/oracle/LINUX.X64_193000_grid_home.zip
rm -rf OPatch
unzip -qa /app/software-download/oracle/p6880880_190000_Linux-x86-64.zip
cd OPatch
./opatch version

cd /app/software-download/oracle
ls -lh OOP-gi.rsp
grep '^[^#].*=' OOP-gi.rsp

cd /app/19.0.0/grid_29
export CV_ASSUME_DISTID=OL7
export TMP=/app/tmp
export TMPDIR=/app/tmp
# real    12m58.590s
time /app/19.0.0/grid_29/gridSetup.sh -applyRU /app/software-download/oracle/38298204 -responseFile /app/software-download/oracle/OOP-gi.rsp -ignorePrereq -waitforcompletion -silent
cp -pr $ORACLE_HOME/network/admin/{sqlnet,listener}.ora /app/19.0.0/grid_29/network/admin/

{
$ORACLE_HOME/OPatch/opatch lspatches 
$ORACLE_HOME/bin/crsctl query crs activeversion -f
$ORACLE_HOME/bin/crsctl query crs releasepatch
$ORACLE_HOME/bin/crsctl query crs softwareversion -all
$ORACLE_HOME/bin/crsctl status res -t
$ORACLE_HOME/bin/srvctl config all
} | tee /app/software-download/oracle/log/gi_before_$(date -I | tr -d '-')

### 2.2 switch grid home node2 then node1 ###
ssh grid@sesdbs12
export ORACLE_HOME=/app/19.0.0/grid_29
$ORACLE_HOME/gridSetup.sh -silent -switchGridHome oracle.install.option=CRS_SWONLY ORACLE_HOME=${ORACLE_HOME} oracle.install.crs.config.clusterNodes=$(hostname -s) oracle.install.crs.rootconfig.executeRootScript=false
sudo su -
cd /app/19.0.0
ln -sfn grid_29 grid
# real    17m28.633s
time /app/19.0.0/grid_29/root.sh
# may watch progress in another session #
ls -1 /app/grid/crsdata/$(hostname -s)/crsconfig/crs_postpatch_apply_oop_$(hostname -s)_$(date -I)_*
tail -f $(ls -1 /app/grid/crsdata/$(hostname -s)/crsconfig/crs_postpatch_apply_oop_$(hostname -s)_$(date -I)_*)
su - grid
cd $ORACLE_HOME/..
{
$ORACLE_HOME/OPatch/opatch lspatches 
$ORACLE_HOME/bin/crsctl query crs activeversion -f
$ORACLE_HOME/bin/crsctl query crs releasepatch
$ORACLE_HOME/bin/crsctl query crs softwareversion -all
$ORACLE_HOME/bin/crsctl status res -t
$ORACLE_HOME/bin/srvctl config all
} | tee /app/software-download/oracle/log/gi_after_$(date -I | tr -d '-')


### 3.  UAT DB ###
### 3.1 prepare db home ###
ssh oracle@sesdbs12
cd /app/software-download/oracle
ls -lh LINUX.X64_193000_grid_home.zip LINUX.X64_193000_db_home.zip
ls -ld *38298204* *30600773* *38535360*

. oraenv <<< aisp2
echo $ORACLE_SID
cd /app/oracle/product/19.0.0/uat
ls -l
mkdir /app/oracle/product/19.0.0/uat/dbhome_29
cd /app/oracle/product/19.0.0/uat/dbhome_29
unzip -qa /app/software-download/oracle/LINUX.X64_193000_db_home.zip
rm -rf OPatch
unzip -qa /app/software-download/oracle/p6880880_190000_Linux-x86-64.zip
cd OPatch
./opatch version

ls -lh /app/software-download/oracle/OOP-uatdb.rsp
grep '^[^#].*=' /app/software-download/oracle/OOP-uatdb.rsp

export ORACLE_HOME=/app/oracle/product/19.0.0/uat/dbhome_29
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH
cd $ORACLE_HOME
# confirm directory /app/oracle/product/19.0.0/uat/dbhome_29
pwd
export CV_ASSUME_DISTID=OL7
export TMP=/app/tmp
export TMPDIR=/app/tmp
ls -lh /app/software-download/oracle/{OOP-uatdb.rsp,38298204,30600773,38535360}
time $ORACLE_HOME/runInstaller -silent -ignorePrereq -waitforcompletion -responseFile /app/software-download/oracle/OOP-uatdb.rsp -applyRU /app/software-download/oracle/38298204 -applyOneOffs /app/software-download/oracle/30600773,/app/software-download/oracle/38535360

export ORACLE_HOME=/app/oracle/product/19.0.0/uat/dbhome_29
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH
cd $ORACLE_HOME/rdbms/lib
make -f ins_rdbms.mk uniaud_on ioracle ORACLE_HOME=$ORACLE_HOME
sudo -i
/app/oracle/product/19.0.0/uat/dbhome_29/root.sh
exit
cd /app/oracle/product/19.0.0/uat/dbhome
cp -pr dbs network /app/oracle/product/19.0.0/uat/dbhome_29
# change oracle base to no _
cat $ORACLE_HOME/install/orabasetab
sed -i 's/_[^:]*:/:/' $ORACLE_HOME/install/orabasetab

##* begin run in [sesdbs11] *##
export ORACLE_HOME=/app/oracle/product/19.0.0/uat/dbhome_29
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH
cd $ORACLE_HOME/rdbms/lib
make -f ins_rdbms.mk uniaud_on ioracle ORACLE_HOME=$ORACLE_HOME
sudo -i
/app/oracle/product/19.0.0/uat/dbhome_29/root.sh
exit
cd /app/oracle/product/19.0.0/uat/dbhome
cp -pr dbs network /app/oracle/product/19.0.0/uat/dbhome_29
cat $ORACLE_HOME/install/orabasetab
sed -i 's/_[^:]*:/:/' $ORACLE_HOME/install/orabasetab
##* end run in [sesdbs11] *##

### 3.2 switch db home ###
# check existing config before restart db
. oraenv <<< aisp2
echo $ORACLE_HOME
$ORACLE_HOME/bin/srvctl config database -verbose > /app/software-download/oracle/log/uatdb_before_$(date -I | tr -d '-')

# no abis yet
lst="cpe eas eha esu haw hst isp lph mat nce"
db_list=$(echo "$lst" | awk '{for(i=1;i<=NF;i++) $i="a"$i""} 1')
echo $db_list
{
for db in $db_list ; do
echo -e "\n###  Configuration of database $db"
$ORACLE_HOME/bin/srvctl config database -d $db
echo -e "\n###  Status of database $db"
$ORACLE_HOME/bin/srvctl status database -d $db
echo -e "\n###  Service Configuration of database $db"
$ORACLE_HOME/bin/srvctl config service -d $db
done
} | tee -a /app/software-download/oracle/log/uatdb_before_$(date -I | tr -d '-')
 
SID_LIST=$(echo "$lst" | awk '{for(i=1;i<=NF;i++) $i="a"$i"2"} 1')
echo $SID_LIST
export JAVA_TOOL_OPTIONS="-Djansi.tmpdir=/app/tmp"
for sid in $SID_LIST ; do
. oraenv <<< $sid
sql -S / as sysdba <<< @/app/software-download/oracle/DB_patch_check.sql
done
ls -lt /app/software-download/oracle/log | head -12

echo $ORACLE_HOME
export WORK_DIR=/app/software-download/oracle/log
# restart to use new home #
$ORACLE_HOME/bin/srvctl stop home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/uatdb_status.sesdbs11-2_dbhome29.out
cd /app/oracle/product/19.0.0/uat/
ln -sfn dbhome_31 dbhome
$ORACLE_HOME/bin/srvctl start home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/uatdb_status.sesdbs11-2_dbhome29.out
srvctl status database -thishome

##* begin run in [sesdbs11] *##
. oraenv <<< aisp1
echo $ORACLE_HOME
export WORK_DIR=/app/software-download/oracle/log
$ORACLE_HOME/bin/srvctl stop home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/uatdb_status.sesdbs11-2_dbhome29.out
cd /app/oracle/product/19.0.0/uat/
ln -sfn dbhome_31 dbhome
$ORACLE_HOME/bin/srvctl start home -o $ORACLE_HOME -n $(hostname -s) -s $WORK_DIR/uatdb_status.sesdbs11-2_dbhome29.out
srvctl status database -thishome
##* end run in [sesdbs11] *##

### 3.3 datapatch ###
ssh oracle@sesdbs12
lst="cpe eas eha esu haw hst isp lph mat nce bis"
SID_LIST=$(echo "$lst" | awk '{for(i=1;i<=NF;i++) $i="a"$i"2"} 1')
echo $SID_LIST

echo $ORACLE_HOME
export WORK_DIR=/app/software-download/oracle/log
export PATH=$ORACLE_HOME/bin:$PATH
cd $ORACLE_HOME/OPatch/
for sid in $SID_LIST ; do
. oraenv <<< $sid
./datapatch -verbose >> $WORK_DIR/datapatch_${sid} 
done

ls -lt $WORK_DIR/datapatch_* | head -12
grep '^Patch ' $WORK_DIR/datapatch_*

{
for sid in $SID_LIST ; do
. oraenv <<< $sid
sqlplus / as sysdba <<'eof'
select bugno, value, is_default from v$system_fix_control where bugno =30587089 ;
alter system set "_fix_control"='30587089:1' scope=both ;
select bugno, value, is_default from v$system_fix_control where bugno =30587089 ;
exit
eof
done
} | tee /app/software-download/oracle/log/uatdb_30587089.out

