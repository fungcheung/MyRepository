prompt enter schema name to recompile, such as ANHS01
EXEC DBMS_UTILITY.compile_schema(schema => '&1', compile_all => false);
