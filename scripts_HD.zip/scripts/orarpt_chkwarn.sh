#!/bin/ksh
## Filename: orarpt_chkwarn.sh
## Usage: ./orarpt_chkwarn.sh  

ORACLE_HOME=/data/oracle/product/9.2.0.4  
export ORACLE_HOME

TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN

ADMIN=samson.wk.cheung@db.com 
export ADMIN

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

/usr/bin/grep -i world $TNS_ADMIN/tnsnames.ora | /usr/bin/grep -vi 'port' | sort | uniq | /usr/bin/awk -F'.' '{print $1}' > /home/oracle/dbasql/db_list.lst

/usr/bin/rm /home/oracle/dbasql/temp/*

/usr/bin/cat /home/oracle/dbasql/db_list.lst | while read LINE
do
    ORACLE_SID=`echo $LINE | awk '{print $1}' `
    export ORACLE_SID

$ORACLE_HOME/bin/sqlplus dba_mon/keep1tsecret@$ORACLE_SID  <<EOM
@/home/oracle/dbasql/orarpt_chkwarn.sql
EOM

done

/usr/bin/cat /home/oracle/dbasql/temp/*chkwarn.spo  > /home/oracle/dbasql/temp/ORARPT_CHKWARN.log

if [ -f /home/oracle/dbasql/temp/ORARPT_CHKWARN.log ] ; then
   /usr/bin/cat /home/oracle/dbasql/temp/ORARPT_CHKWARN.log | /usr/bin/mailx -r sl2.apho@db.com -s "Warning Report - `date '+%y%m%d'`" $ADMIN
fi

exit 0

