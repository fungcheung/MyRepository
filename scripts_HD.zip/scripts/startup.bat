chcp 65001 > nul
set sqlpath=c:\scripts
set nls_lang=american_america.al32utf8
set tns_admin=C:\oracle\oracle19c_client\network\admin
set path=C:\UnxUtils\usr\local\wbin;C:\SQLDeveloper_21\sqldeveloper-21.4.3.063.0100-x64\sqldeveloper\sqldeveloper\bin;%path%
doskey sql=sql -L $*