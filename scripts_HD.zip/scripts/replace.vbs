Option Explicit

Const TristateFalse = 0
Const ForReading    = 1
Const ForWriting    = 2

Dim intValid
Dim objFSO, objFile
Dim strFind, strInFile, strOutFile, strReplace, strResult, strString


With WScript.Arguments
	If .Unnamed.Count > 0 Then Syntax
	If .Named.Count   < 3 Then Syntax
	If .Named.Count   > 4 Then Syntax
	If .Named.Exists("I") Then
		strInFile = .Named.Item("I")
		intValid = intValid + 1
	End If
	If .Named.Exists("S") Then
		strString = .Named.Item("S")
		intValid = intValid + 1
	End If
	If .Named.Exists("F") Then
		strFind = .Named.Item("F")
		intValid = intValid + 1
	End If
	If .Named.Exists("R") Then
		strReplace = .Named.Item("R")
		intValid = intValid + 1
	End If
	If .Named.Exists("O") Then
		strOutFile = .Named.Item("O")
		intValid = intValid + 1
	End If
	If intValid <> .Count Then Syntax
End With

Set objFSO = CreateObject( "Scripting.FileSystemObject" )

If strInFile <> "" Then
	Set objFile = objFSO.OpenTextFile ( strInFile, ForReading, False, TristateFalse )
	strString = objFile.ReadAll( )
	objFile.Close
	Set objFile = Nothing
End If

If strOutFile = "" Then
	strOutFile = strInFile
End If

strResult = Replace( strString, strFind, strReplace )

If strOutFile <> "" Then
	Set objFile = objFSO.OpenTextFile ( strOutFile, ForWriting, True, TristateFalse )
	objFile.Write strResult
	objFile.Close
	Set objFile = Nothing
Else
	WScript.Echo strResult
End If

Sub Syntax
	Dim strMsg
	strMsg = "SFaR.vbs,  Version 1.00" & vbCrLf _
	       & "Simple Find and Replace" & vbCrLf & vbCrLf _
	       & "Usage:  SFAR.VBS  /I:""file""  /F:""search""  /R:""replace""  [ /O:""target"" ]" _
	       & vbCrLf _
	       & "or:     SFAR.VBS  /S:""text""  /F:""search""  /R:""replace""  [ /O:""target"" ]" _
	       & vbCrLf & vbCrLf _
	       & "Where:  /I:""file""       specifies the text file to be edited" _
	       & vbCrLf _
	       & "        /S:""text""       specifies the text string to be edited" _
	       & vbCrLf _
	       & "        /F:""search""     is the search string to look for" _
	       & vbCrLf _
	       & "        /R:""replace""    is the text to replace the search string" _
	       & vbCrLf _
	       & "        /O:""target""     is the optional file where the result is stored" _
	       & vbCrLf _
	       & "                        (default: modify original file or display on screen)" _
	       & vbCrLf & vbCrLf _
	       & "Notes:  Searches are case sensitive." _
	       & vbCrLf _
	       & "        This script handles ASCII only, though it MAY handle UTF-8 as" _
	       & vbCrLf _
	       & "        long as no Unicode characters need to be found or replaced." _
	       & vbCrLf & vbCrLf _
	       & "Written by Rob van der Woude" & vbCrLf _
	       & "http://www.robvanderwoude.com"
	WScript.Echo strMsg
	WScript.Quit 1
End Sub
