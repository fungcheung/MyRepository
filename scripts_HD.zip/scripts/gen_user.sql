SET SERVEROUTPUT ON SIZE UNLIMITED;
SET FEEDBACK OFF;
SET VERIFY OFF; 
SET ECHO OFF

DECLARE
    v_user_pattern VARCHAR2(50) := UPPER('&1'); 
    
    CURSOR user_cur IS
        SELECT username 
        FROM dba_users 
        WHERE username LIKE v_user_pattern
        ORDER BY username;

    v_ddl CLOB;
    v_found BOOLEAN := FALSE;
BEGIN
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'SQLTERMINATOR', TRUE);
    DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'PRETTY', TRUE);

    FOR r_user IN user_cur LOOP
        v_found := TRUE;
        DBMS_OUTPUT.PUT_LINE('-- ==========================================');
        DBMS_OUTPUT.PUT_LINE('-- USER: ' || r_user.username);
        
        -- 1. Create User DDL
        BEGIN
            v_ddl := DBMS_METADATA.GET_DDL('USER', r_user.username);
            DBMS_OUTPUT.PUT_LINE(v_ddl);
        EXCEPTION WHEN OTHERS THEN NULL;
        END;

        -- 2. Role Grants
        BEGIN
            v_ddl := DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT', r_user.username);
            DBMS_OUTPUT.PUT_LINE(v_ddl);
        EXCEPTION WHEN OTHERS THEN NULL;
        END;

        -- 3. System Privileges
        BEGIN
            v_ddl := DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT', r_user.username);
            DBMS_OUTPUT.PUT_LINE(v_ddl);
        EXCEPTION WHEN OTHERS THEN NULL;
        END;
    END LOOP;

    IF NOT v_found THEN
        DBMS_OUTPUT.PUT_LINE('No users found matching: ' || v_user_pattern);
    END IF;
END;
/