load data
 infile 'c:\temp\salgrade.csv'
 into table salgrade
 fields terminated by "," optionally enclosed by '"'
 (grade,losal,hisal)