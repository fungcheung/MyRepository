select event_timestamp, os_username, userhost, dbusername, action_name, to_char(return_code) as return_code,
REGEXP_SUBSTR(authentication_type, '[^;]+', 1, 4) as authentication_type,
UNIFIED_AUDIT_POLICIES
from unified_audit_trail
where event_timestamp>sysdate-1/48 and ACTION_NAME='LOGON' and dbusername in('&1') 
order by event_timestamp desc;

