
@echo off

set rows=1000
set dept=10

echo alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;
echo alter table emp disable constraint fk_deptno;
echo truncate table emp;
echo truncate table dept;
echo truncate table salgrade;
echo alter table emp enable constraint fk_deptno;
echo set feedback off

for /L %%a in (1,1,%dept%) do echo insert into dept values(%%a, 'DEPT%%a' , 'LOC%%a' );

for /L %%a in (1,1,%rows%) do echo insert into emp values(%%a, 'ENAME%%a' , 'JOB%%a', null, '11-01-2011',1000,10,dbms_random.value(1,%dept%) );

echo insert into salgrade values (1,1,10000);
echo insert into salgrade values (2,10001,20000);
echo insert into salgrade values (3,20001,30000);
echo insert into salgrade values (4,30001,40000);
echo insert into salgrade values (5,40001,50000);
echo insert into salgrade values (6,50001,60000);


for /L %%a in (1,1,%rows%) do echo update emp set sal=(select dbms_random.value(10000,60000) from dual) where empno=%%a;

for /L %%a in (1,1,%rows%) do echo update emp set deptno=(select dbms_random.value(1,%dept%) from dual) where empno=%%a;

for /L %%a in (1,1,%rows%) do echo update emp set mgr=(select dbms_random.value(11,20) from dual) where empno not in (11,12,13,14,15,16,17,18,19,20) and empno=%%a;

echo update emp set mgr=11 where empno=16;
echo update emp set mgr=12 where empno=17;
echo update emp set mgr=13 where empno=18;
echo update emp set mgr=14 where empno=19;
echo update emp set mgr=15 where empno=29;



echo update emp set hiredate='15-12-2009' where empno between (select dbms_random.value(100,200) from  dual) and (select dbms_random.value(300,400) from dual);
echo update emp set hiredate='20-03-2007' where empno between (select dbms_random.value(300,400) from  dual) and (select dbms_random.value(500,600) from dual);
echo update emp set hiredate='23-03-2006' where empno between (select dbms_random.value(700,800) from  dual) and (select dbms_random.value(900,1000) from dual);




