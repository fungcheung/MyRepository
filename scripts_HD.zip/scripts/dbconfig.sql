set pages 2000
set lines 200
alter session set nls_date_format='YYYY-MM-DD HH24:MI:SS';

show parameter
@C:\scripts\redo
@C:\scripts\db
@C:\scripts\tsp1
@C:\scripts\show_user
@C:\scripts\show_profile
@C:\scripts\show_role
@C:\scripts\gen_cr_tblsp
@C:\scripts\gen_user '&1'
@C:\scripts\show_obj '&1'
@C:\scripts\gen_roles

