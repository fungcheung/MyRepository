-- Run this sql in GIH 2.0 to extract the column definition of SCHEMAS tables

DEFINE SCHEMAS = "'LANDS','ADM','APIX','BRIS','CENSUS','CHINA','CHP','DAM','DLO','GPS','HIGHWAYS','HOUSING','MI','PLANNING'"


set pages 9000 lines 130
column owner format a20
column table_name format a40
column column_name format a40
column DT format a12
column Mand format a2
column descr format a10

-- For schema rdataapp
select owner, table_name  
 from dba_tables where owner in 
 (&SCHEMAS
) and table_name not like '%IDX$' and table_name not like 'BIN$%' and table_name not like 'SDE_%' order by 1,2;


 -- Retrieve tables and their record counts
 /*
 begin
 dbms_stats.gather_schema_stats('RDATAAPP');
 end;
 /
*/  

/* Uncomment this if you want to have table num_rows  
select owner, table_name,'XXXXXXXXXX' descr, num_rows from dba_tables where owner in 
(&SCHEMAS
) and table_name not like '%IDX$' and table_name not like 'BIN$%' and table_name not like 'SDE_%' order by 1,2,3,4;
*/

UNDEFINE SCHEMAS
