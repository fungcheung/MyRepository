
SET PAGESIZE 200 LONG 2000000 LINESIZE 1000 FEEDBACK OFF VERIFY OFF TRIMSPool ON;
EXEC DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'SQLTERMINATOR', TRUE);
EXEC DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM, 'PRETTY', TRUE);


SELECT DBMS_METADATA.GET_DDL('ROLE', role) from dba_roles where oracle_maintained = 'N';
SELECT DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT', r.role)
FROM dba_roles r
WHERE r.oracle_maintained = 'N'
  AND EXISTS (SELECT 1 FROM dba_tab_privs tp WHERE tp.grantee = r.role);

SELECT DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT', role)
FROM dba_roles dr
WHERE dr.oracle_maintained = 'N'
AND EXISTS (
    SELECT 1
    FROM dba_sys_privs dsp
    WHERE dsp.grantee = dr.role
);

SELECT DBMS_METADATA.GET_GRANTED_DDL('ROLE_GRANT', role)
FROM dba_roles dr
WHERE dr.oracle_maintained = 'N'
AND EXISTS (
    SELECT 1
    FROM dba_role_privs drp
    WHERE drp.grantee = dr.role
);

