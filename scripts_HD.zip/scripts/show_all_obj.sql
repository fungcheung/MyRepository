column owner format a20
column object_type format a20
column object_name format a40
set lines 200 pages 50000

prompt Show object type count
select distinct owner,object_type, count(*) from dba_objects where owner like upper('&1') group by owner, object_type order by 1,2,3;

prompt Show all objects
select owner,object_type,object_name from dba_objects where owner like upper('&1') order by 1,2,3;


