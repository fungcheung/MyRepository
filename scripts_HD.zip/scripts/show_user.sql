-- fiilename: show_user.sql

clear col
set lines 333

-- alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ;
alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

col USERNAME        format a25
col PASSWORD        format a20
col PROFILE         format a30
col ACCOUNT_STATUS  format a18 heading 'Status'


select 'alter user '||name||' identified by values '||''''||spare4||''''||' ; ' 
from sys.user$
where name not in ('SYS','SYSTEM','DBSNMP','ORACLE','OUTLN', 'CHEUSA') and
spare4 is not null
order by 1 ;



select USERNAME, password, ACCOUNT_STATUS, profile, to_char(EXPIRY_DATE,'dd-mm-rr') as expiry_date, to_char(LOCK_DATE,'dd-mm-rr') as lock_date, to_char(CREATED,'dd-mm-rr') as created_date
from dba_users
order by 1 ;


prompt 

clear col
