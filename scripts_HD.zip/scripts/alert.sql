set pages 5000 lines 200
set markup csv on
prompt ======= Last 24 hours alert log ======= 
SELECT originating_timestamp, message_text FROM V$DIAG_ALERT_EXT WHERE originating_timestamp > SYSDATE - 1 ORDER BY originating_timestamp;

prompt ======= Last 24 hour ORA- errors ======= 
SELECT originating_timestamp, message_text FROM V$DIAG_ALERT_EXT WHERE message_text LIKE '%ORA-%' and originating_timestamp > SYSDATE - 1 ORDER BY originating_timestamp;

set markup csv on