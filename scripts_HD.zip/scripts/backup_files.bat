@echo off
setlocal enabledelayedexpansion

:: 1. Define Variables
set "TARGET_DIR=C:\data_hd\pwd"
set "INPUT_LIST=%~1"

:: 獲取日期 YYYYMMDD (使用 wmic)
set "STAMP="
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do (
    set "dt=%%I"
    set "STAMP=!dt:~0,8!"
)

:: 如果 wmic 失敗，改用傳統 %DATE% 方式 (格式視系統語言而定)
if "%STAMP%"=="" (
    for /f "tokens=1-3 delims=/ " %%a in ("%date%") do set "STAMP=%%a%%b%%c"
)

set "LOG_FILE=%TARGET_DIR%\copy_pwd_%STAMP%.log"

:: 確保目標目錄存在
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo ------------------------------------------ >> "%LOG_FILE%"
echo Backup Process Started: %DATE% %TIME% >> "%LOG_FILE%"

:: 2. Check if input parameter is provided
if "%INPUT_LIST%"=="" (
    echo [ERROR] No input file list provided. >> "%LOG_FILE%"
    goto :end
)

if not exist "%INPUT_LIST%" (
    echo [ERROR] Input list file not found: %INPUT_LIST% >> "%LOG_FILE%"
    goto :end
)

:: 3. Loop through the list of files
echo [INFO] Processing file list... >> "%LOG_FILE%"

for /f "usebackq tokens=*" %%F in ("%INPUT_LIST%") do (
    set "SOURCE_FILE=%%~F"
    
    if exist "!SOURCE_FILE!" (
        set "FNAME=%%~nF"
        set "FEXT=%%~xF"
        :: 修改點：Stamp 在檔名前面
        set "OUT_FNAME=%STAMP%_!FNAME!!FEXT!"
                
        copy /Y "!SOURCE_FILE!" "%TARGET_DIR%\!OUT_FNAME!" >> "%LOG_FILE%" 2>&1
        copy /Y "!SOURCE_FILE!" "%TARGET_DIR%" >> "%LOG_FILE%" 2>&1
        
        if !errorlevel! equ 0 (
            echo [SUCCESS] Source: "!SOURCE_FILE!" -^> Output: "!OUT_FNAME!" >> "%LOG_FILE%"
        ) else (
            echo [FAILED] Error copying: "!SOURCE_FILE!" >> "%LOG_FILE%"
        )
    ) else (
        echo [SKIP] File does not exist: "!SOURCE_FILE!" >> "%LOG_FILE%"
    )
)

:: 4. Delete old files (修正：天數改為 32768 以內，例如 3650 天約 10 年)
echo [CLEANUP] Checking for old files... >> "%LOG_FILE%"
:: 如果你原本是想設定 100 年，改為 32768 即可；若只是想清 3 個月，請改為 -90
forfiles /p "%TARGET_DIR%" /s /m *.* /d -32768 /c "cmd /c del @path" >> "%LOG_FILE%" 2>&1

echo [CLEANUP] Old files cleanup completed. >> "%LOG_FILE%"

:end
echo Backup Process Finished: %DATE% %TIME% >> "%LOG_FILE%"
echo ------------------------------------------ >> "%LOG_FILE%"
echo Task completed. See log at: %LOG_FILE%
