set var1=gdau1218
set var2=%var1:gdat=%
echo %var2%

set SERVER=gdat1218
IF /I %SERVER:gdat=%==%SERVER% (
SET TNSNAME=NO
) ELSE (
SET TNSNAME=YES
)
echo %TNSNAME%
