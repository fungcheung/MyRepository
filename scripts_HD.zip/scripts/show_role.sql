-- fiilename: show_role.sql

set lines 222
column role format a30
column oracle_maintained format a20

select role,oracle_maintained,password_required,authentication_type from dba_roles
order by oracle_maintained ;

set lines 99

