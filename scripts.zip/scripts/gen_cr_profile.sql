-- filename: gen_cr_profile.sql

select distinct 'create profile '||profile||' limit'
from dba_profiles
where profile like upper('%&1%')
union all
select RESOURCE_NAME||' '||limit||chr(10)
from dba_profiles
where profile like upper('%&&1%')
union all
select '/ ' from dual 
/
