-- fiilename: show_role.sql

set lines 222

select * from dba_roles
order by 1 ;

set lines 99

