set -x

ls -ltr /data/oracle/TWXBOS/backup/database
ls -ltr /data/oracle/TWXBOS/backup/export
ls -ltr /data/oracle/TWXBOS/backup/logs | tail
ls -ltr /data/oracle/TWXBOS/backup/logs/backup.log
grep 'ORA-' /data/oracle/TWXBOS/backup/logs/backup.log | grep -v 'ORA-08103'
tail  /data/oracle/TWXBOS/backup/logs/backup.log

df -k /data/oracle/TWXBOS/backup/database

