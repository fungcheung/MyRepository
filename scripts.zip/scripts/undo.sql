set linesize 188 pages 999


prompt =========================================================================================================================================================
prompt Active transactions using undo extents
SELECT s.sid , s.username, s.status, a.sql_text, t.xidusn, t.status, t.START_TIME, t.used_ublk
FROM v$session s, v$transaction t, v$sqlarea a
WHERE s.saddr = t.ses_addr and
s.sql_id = a.sql_id;

prompt =========================================================================================================================================================
prompt Active/Unexpired undo usage

column segment_name format a20
column tablespace_name format a15
compute sum of "Extent Count" on report
compute sum of "Total MB" on report
break on report

select segment_name,
tablespace_name,
count(extent_id) "Extent Count",
status,
sum(bytes)/1024/1024 "Total MB"
from dba_undo_extents
where status in ('UNEXPIRED','ACTIVE')
group by segment_name, tablespace_name, status
order by segment_name
/



