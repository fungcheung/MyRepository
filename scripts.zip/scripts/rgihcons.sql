-- Purpose: List rGIH constraints
-- Authur : James
-- Modified Date: 20171020
-- Version: 0.1

set lines 200
set pages 50000


alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

column owner format a10
column table_owner format a10
column index_name format a30
column index_type format a30
column table_name format a30
column generated format a10
column column_position format 999
column column_name format a30
column constraint_name format a30
column constraint_type format a10



select table_name,constraint_name,constraint_type from dba_constraints where owner in 
(
'RMAPAPP'
,'RDATAAPP'
) 
and constraint_type in 
(
'P'
,'R'
,'U'
) 
order by 1,2,3;

