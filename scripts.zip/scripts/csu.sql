SELECT DISTINCT a.st_code,
  a.eng_nm,
  a.chi_nm,
  d.TOTAL_SEGMENT,
  COUNT(a.st_code) over() AS TOTAL_RECORD,
  sde.st_geometrytype(shape) geometryType,
  sde.st_x(
  CASE
    WHEN sde.st_geometrytype(shape) = 'ST_POLYGON'
    OR sde.st_geometrytype(shape)   = 'ST_MULTIPOLYGON'
    THEN sde.st_pointonsurface(shape)
    ELSE
      CASE
        WHEN sde.st_geometrytype(shape) = 'ST_POINT'
        THEN sde.st_centroid (shape)
        ELSE
          CASE
            WHEN sde.st_numgeometries(shape) >1
            THEN sde.st_pointn (sde.st_geometryn(shape, sde.st_numgeometries(shape)/2), sde.st_numpoints (sde.st_geometryn(shape, sde.st_numgeometries(shape)/2))/2)
            ELSE sde.st_pointn (shape, (sde.st_numpoints (shape)                   /2))
          END
      END
  END ) CentroidX,
  sde.st_y(
  CASE
    WHEN sde.st_geometrytype(shape) = 'ST_POLYGON'
    OR sde.st_geometrytype(shape)   = 'ST_MULTIPOLYGON'
    THEN sde.st_pointonsurface(shape)
    ELSE
      CASE
        WHEN sde.st_geometrytype(shape) = 'ST_POINT'
        THEN sde.st_centroid (shape)
        ELSE
          CASE
            WHEN sde.st_numgeometries(shape) >1
            THEN sde.st_pointn (sde.st_geometryn(shape, sde.st_numgeometries(shape)/2), sde.st_numpoints (sde.st_geometryn(shape, sde.st_numgeometries(shape)/2))/2)
            ELSE sde.st_pointn (shape, (sde.st_numpoints (shape)                   /2))
          END
      END
  END ) CentroidY ,
  b.objectid,
  b.sub_id 
FROM DAM_STREET_ST_NAME a
INNER JOIN DAM_STREET_ARC b
ON a.ST_CODE = b.ST_CODE
INNER JOIN
  (SELECT st_code, COUNT(*) TOTAL_SEGMENT FROM DAM_STREET_ARC GROUP BY st_code
  ) d
ON a.st_code                                                                                    = d.st_code
WHERE sde.st_intersects(shape, sde.st_buffer( sde.st_point (&1, &2, &3), &4)) = 1
ORDER BY a.st_code,
  b.sub_id 
;  
