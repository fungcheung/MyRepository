-- Filename: ana_RSH.sql
-- Arthur: Samson CHEUNG
--

set echo on verify off feedback off pages  0 lines  132 recsep off

select 'analyze '||segment_type||' '||owner||'.'||segment_name||' '||
   decode(sign(10485760 - bytes),1,'compute statistics;','estimate statistics;') 
 from sys.dba_segments
where owner in ('RESEARCH', 'KAYR', 'ACE', 'WCWW')
  and segment_type = 'TABLE'
order by owner, segment_name

spool /tmp/analyzal.tmp
/
spool  off
spool /tmp/analyzal.out
set term on
@/tmp/analyzal.tmp

execute dbms_utility.compile_schema('KAYR',FALSE);
execute dbms_utility.compile_schema('RESEARCH',FALSE);
execute dbms_utility.compile_schema('WCWW',FALSE);

spool off
