col owner format a20
col object_name format a50

select owner, object_name, object_type from dba_objects where 
owner in ('SYS','PUBLIC') and 
(object_name like 'DBA_%' or
object_name like 'DBMS_%' or
object_name like 'V$_%' or
object_name like 'GV_$%' or
object_name like 'V_%') and
object_type in ('PACKAGE','VIEW','SYNONYM')
order by object_type, object_name;


