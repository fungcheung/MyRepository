#!/bin/ksh
## Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_clnlogfiles.sh
## Usage: ./orarpt_misc.sh  $SG  $ORACLE_HOME  $ORA_SID

SERVICE_GROUP=$1  ; export SERVICE_GROUP
ORACLE_HOME=$2    ; export ORACLE_HOME
ORACLE_SID=$3     ; export ORACLE_SID

find $ORACLE_HOME/rdbms/audit/*.aud -mtime +30 -exec rm -f {} \;
find /$SERVICE_GROUP/export/oracle/u001/admin/$ORACLE_SID/audit/*.aud -mtime +30 -exec rm -f {} \;
find /$SERVICE_GROUP/export/oracle/u001/admin/$ORACLE_SID/udump/*.trc -mtime +30 -exec rm -f {} \;

exit 0

