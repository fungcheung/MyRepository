Set heading on
set pagesize 1000
set linesize 350
set feed on

column Log_Time format A20
column SID         format 999999
column USERNAME    format a20
column OWNERID     format 999999999
column STATUS      format a10   
column OSUSER      format a30
column PROCESS     format a35
column MACHINE     format a30
column TERMINAL    format a30
column PROGRAM     format a60
column logon_time_str format a20
column uga_memory  format a12
column pga_memory  format a12

SELECT
--   to_char(sysdate , 'YYYY/DD/MM HH24:MI:SS') as Log_Time,
   e.SID,
   e.CON_ID,
   to_char(e.LOGON_TIME, 'yyyy-MM-dd hh24:mi:ss') as logon_time_str,
--   a.UGA_MEMORY,
   b.PGA_MEMORY,
   e.username,
   e.status,
   e.OSUSER,
   e.PROCESS,                                                       
   e.PROGRAM,
   e.TERMINAL
FROM
 (select y.SID, TO_CHAR(ROUND(y.value/1024),99999999) || ' KB' UGA_MEMORY from v$sesstat y, v$statname z where y.STATISTIC# = z.STATISTIC# and NAME = 'session uga memory') a,
 (select y.SID, TO_CHAR(ROUND(y.value/1024),99999999) || ' KB' PGA_MEMORY from v$sesstat y, v$statname z where y.STATISTIC# = z.STATISTIC# and NAME = 'session pga memory') b,
v$session e
WHERE  e.sid=a.sid 
   and e.sid=b.sid
--   and e.program = 'aimsserver.exe'
ORDER BY
   e.con_id,
   e.terminal,
   e.LOGON_TIME,
   b.PGA_MEMORY desc;

prompt ===================================================================================
prompt = Sessions Count of PDBS                                                                  =
prompt ===================================================================================
column name format a20
select a.con_id, a.name, b.sessions from v$containers a, (select count(*) as sessions, con_id from v$session where con_id not in (0,1,2) group by con_id) b 
 where a.con_id not in (0,1,2) and a.con_id=b.con_id;


prompt ===================================================================================
prompt = Total PGA used and PGA parameters                                               =
prompt ===================================================================================
select round(sum(y.value/1024/1024),2) || ' MB' PGA_MEMORY_USED from v$sesstat y, v$statname z where y.STATISTIC# = z.STATISTIC# and NAME = 'session pga memory';
show parameter pga_aggregate

prompt ========================++++++==========================================================
prompt = Total memory size(SGA) used by Oracle, not including the process stack and code size =
prompt = It should roughly equal to the virtual memory size in OS.                            =
prompt ========================================================================================

select sum(bytes)/1024/1024 Used_Memory_Mb from
(select bytes from v$sgastat
union
select value bytes from
v$sesstat s,
v$statname n
where n.statistic# = s.statistic# and
n.name = 'session pga memory'
);


