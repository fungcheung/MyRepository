
#!/bin/ksh
## Filename: mig_TWXBOS_uat.sh
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 

echo `date` Scp-ing  .......
date ; ls -ltr /data/oracle/TWXBOS/backup/expimp/TWXBOS_fullexp.dmp.Z

### last night copy
/usr/bin/scp -p  tpeeqxbosu1:/tpexbosdbp1/export/oracle/u004/XBOSTW/backup/export/XBOSTW_fullexp.dmp.Z \
                             /data/oracle/TWXBOS/backup/expimp/TWXBOS_fullexp.dmp.Z

date ; ls -ltr /data/oracle/TWXBOS/backup/expimp/TWXBOS_fullexp.dmp.Z

### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 

ORACLE_SID=TWXBOS ; export ORACLE_SID   
ORACLE_HOME=/data/oracle/TWXBOS/product/10.2.0.3 ; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib ;  export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ; export PATH
NLS_LANG=AMERICAN_AMERICA.ZHT16BIG5 ; export NLS_LANG

$ORACLE_HOME/bin/sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
startup
EOF

echo `date`  Pre_import  .......
$ORACLE_HOME/bin/sqlplus /  @/data/oracle/TWXBOS/home/dbasql/pre_TWXBOS_imp.sql > /data/oracle/TWXBOS/home/dbasql/pre_TWXBOS_imp.log 2>&1

echo `date`  WIP_import  .......
date   >  /data/oracle/TWXBOS/home/dbasql/imp_XBOSTW_uat.sh.log  2>&1
/data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_uat.sh  >>  /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_uat.log 2>&1
date  >>  /data/oracle/TWXBOS/home/dbasql/imp_XBOSTW_uat.sh.log  2>&1

echo `date` Post_import  .......
$ORACLE_HOME/bin/sqlplus / @/data/oracle/TWXBOS/home/dbasql/post_TWXBOS_imp.sql > /data/oracle/TWXBOS/home/dbasql/post_TWXBOS_imp.log 2>&1

### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 

echo `date` Mailing  .......
cat /tpexbosdbp1/export/oracle/dbasql/imp_TWXBOS.log | uuencode TWXBOS_import.log | /usr/bin/mailx -s "Import Finished ${ORACLE_SID}@`hostname`" samson.wk.cheung@db.com

$ORACLE_HOME/bin/sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
startup
EOF

echo Completed `date`
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 
exit 0
