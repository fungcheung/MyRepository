insert into tab_stat (
select sysdate, dt.owner, dt.table_name, dt.num_rows, ds.bytes, ds.blocks, ds.extents 
from dba_tables dt, dba_segments ds
where dt.table_name = ds.segment_name
and ds.segment_type = 'TABLE'
and dt.owner = 'ACE' 
and ds.owner = 'ACE' )
order by 1,2,3
/

insert into tab_stat (
select sysdate, dt.owner, dt.table_name, dt.num_rows, ds.bytes, ds.blocks, ds.extents
from dba_tables dt, dba_segments ds
where dt.table_name = ds.segment_name
and ds.segment_type = 'TABLE'
and dt.owner = 'WEB'
and ds.owner = 'WEB' )
order by 1,2,3
/

insert into tab_stat (
select sysdate, dt.owner, dt.table_name, dt.num_rows, ds.bytes, ds.blocks, ds.extents
from dba_tables dt, dba_segments ds
where dt.table_name = ds.segment_name
and ds.segment_type = 'TABLE'
and dt.owner = 'WCWW'
and ds.owner = 'WCWW' )
order by 1,2,3
/

commit;
exit
