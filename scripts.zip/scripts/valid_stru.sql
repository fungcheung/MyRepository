set feedback off
set pages 200
set lines 200
set head off
set echo off
set ver off

spool tmp.spo

select 'ANALYZE TABLE ' ||
owner || '.' || object_name || ' VALIDATE STRUCTURE CASCADE ONLINE;' from dba_objects
where owner='SH' and object_type= 'TABLE';

spool off

exit


