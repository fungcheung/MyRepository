-- filename: chk_lstana.sql

select distinct LAST_ANALYZED
from dba_tab_columns
where owner = upper('&v_owner')
/

