#!/bin/ksh
## Filename: mig_XBOS.sh

echo `date` scp-ing.......
date ; ls -ltr /tpexbosdbp1/export/oracle/u004/XBOS/backup/expimp/XBOS_fullexp.dmp.Z

### last night copy
### /usr/bin/scp -p  tpeeqxbosd1:/tpexbosdbp1/export/oracle/u004/XBOS/backup/export/XBOS_fullexp.dmp.Z   /tpexbosdbp1/export/oracle/u004/XBOS/backup/expimp/XBOS_fullexp.dmp.Z

/usr/bin/scp -p  tpexbosdbu1:/tpexbosdbu1/export/oracle/u004/XBOS/backup/export/U_XBOS_fullexp.dmp.Z   /tpexbosdbp1/export/oracle/u004/XBOS/backup/expimp/XBOS_fullexp.dmp.Z

date ; ls -ltr /tpexbosdbp1/export/oracle/u004/XBOS/backup/expimp/XBOS_fullexp.dmp.Z

ORACLE_SID=XBOS ; export ORACLE_SID   
ORACLE_HOME=/tpexbosdbp1/export/oracle/product/9.2.0.4 ; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib ;  export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ; export PATH

sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
startup
EOF


echo `date` dropping.......
$ORACLE_HOME/bin/sqlplus / @/tpexbosdbp1/export/oracle/dbasql/pre_XBOS_imp.sql > /tpexbosdbp1/export/oracle/dbasql/pre_XBOS_imp.log 2>&1

date   >  /tpexbosdbp1/export/oracle/dbasql/imp_XBOS.log 2>&1
echo `date` importing........
/tpexbosdbp1/export/oracle/dbasql/imp_XBOS.sh >> /tpexbosdbp1/export/oracle/dbasql/imp_XBOS.log 2>&1
date  >>  /tpexbosdbp1/export/oracle/dbasql/imp_XBOS.log 2>&1

echo `date` compiling......
$ORACLE_HOME/bin/sqlplus / @/tpexbosdbp1/export/oracle/dbasql/post_XBOS_imp.sql > /tpexbosdbp1/export/oracle/dbasql/post_XBOS_imp.log 2>&1

echo `date` mailing......
cat /tpexbosdbp1/export/oracle/dbasql/imp_XBOS.log | uuencode XBOS_import.log | /usr/bin/mailx -s "Import Finished ${ORACLE_SID}@`hostname`" samson.wk.cheung@db.com

echo Completed `date`

