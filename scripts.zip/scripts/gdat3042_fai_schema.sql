SQL> @show_user

Session altered.


'ALTERUSER'||USERNAME||'IDENTIFIEDBYVALUES'||''''||PASSWORD||''''||';'                                                                                                                                                                                                                                                                       
--------------------------------------------------------------------------------------------------                                                                                                                                                                                                                                           
alter user ACCMGR identified by values '40FA78EEC3F3FBCB' ;                                                                                                                                                                                                                                                                                  
alter user ADM identified by values 'A67E1BC5E3656755' ;                                                                                                                                                                                                                                                                                     
alter user ANONYMOUS identified by values 'anonymous' ;                                                                                                                                                                                                                                                                                      
alter user APIX identified by values '70A5492191BC955A' ;                                                                                                                                                                                                                                                                                    
alter user CENSUS identified by values '6A90B584B5D448BF' ;                                                                                                                                                                                                                                                                                  
alter user CTXSYS identified by values '24ABAB8B06281B4C' ;                                                                                                                                                                                                                                                                                  
alter user DIP identified by values 'CE4A36B8E06CA59C' ;                                                                                                                                                                                                                                                                                     
alter user EXFSYS identified by values '66F4EF5650C20355' ;                                                                                                                                                                                                                                                                                  
alter user LANDS identified by values 'B09F67B42D55D7CF' ;                                                                                                                                                                                                                                                                                   
alter user LNDGS054 identified by values '75457BC4FEB010ED' ;                                                                                                                                                                                                                                                                                
alter user MDDATA identified by values 'DF02A496267DEE66' ;                                                                                                                                                                                                                                                                                  
alter user MDSYS identified by values '72979A94BAD2AF80' ;                                                                                                                                                                                                                                                                                   
alter user MGMT_VIEW identified by values 'E5FADA68187C4631' ;                                                                                                                                                                                                                                                                               
alter user MI identified by values '112281C7D4220796' ;                                                                                                                                                                                                                                                                                      
alter user ORACLE_OCM identified by values '6D17CF1EB1611F94' ;                                                                                                                                                                                                                                                                              
alter user ORDPLUGINS identified by values '88A2B2C183431F00' ;                                                                                                                                                                                                                                                                              
alter user ORDSYS identified by values '7EFA02EC7EA6B86F' ;                                                                                                                                                                                                                                                                                  
alter user SDE identified by values '62B87072023B2E02' ;                                                                                                                                                                                                                                                                                     
alter user SI_INFORMTN_SCHEMA identified by values '84B8CBCA4D477FA3' ;                                                                                                                                                                                                                                                                      
alter user SYSMAN identified by values '6B69163949ED80D4' ;                                                                                                                                                                                                                                                                                  
alter user TSMSYS identified by values '3DF26A8B17D0F29F' ;                                                                                                                                                                                                                                                                                  
alter user USERS identified by values '4DFCDD9BEBFAFB9B' ;                                                                                                                                                                                                                                                                                   
alter user WMSYS identified by values '7C9BA362F8314299' ;                                                                                                                                                                                                                                                                                   
alter user XDB identified by values '88D8364765FCE6AF' ;                                                                                                                                                                                                                                                                                     

24 rows selected.


'ALTERUSER'||NAME||'IDENTIFIEDBYVALUES'||''''||PASSWORD||''''||';'                                                                                                                                                                                                                                                                           
--------------------------------------------------------------------------------------------------                                                                                                                                                                                                                                           
alter user ACCMGR identified by values '40FA78EEC3F3FBCB' ;                                                                                                                                                                                                                                                                                  
alter user ADM identified by values 'A67E1BC5E3656755' ;                                                                                                                                                                                                                                                                                     
alter user ANONYMOUS identified by values 'anonymous' ;                                                                                                                                                                                                                                                                                      
alter user APIX identified by values '70A5492191BC955A' ;                                                                                                                                                                                                                                                                                    
alter user CENSUS identified by values '6A90B584B5D448BF' ;                                                                                                                                                                                                                                                                                  
alter user CTXSYS identified by values '24ABAB8B06281B4C' ;                                                                                                                                                                                                                                                                                  
alter user DIP identified by values 'CE4A36B8E06CA59C' ;                                                                                                                                                                                                                                                                                     
alter user EXFSYS identified by values '66F4EF5650C20355' ;                                                                                                                                                                                                                                                                                  
alter user GLOBAL_AQ_USER_ROLE identified by values 'GLOBAL' ;                                                                                                                                                                                                                                                                               
alter user LANDS identified by values 'B09F67B42D55D7CF' ;                                                                                                                                                                                                                                                                                   
alter user LNDGS054 identified by values '75457BC4FEB010ED' ;                                                                                                                                                                                                                                                                                
alter user MDDATA identified by values 'DF02A496267DEE66' ;                                                                                                                                                                                                                                                                                  
alter user MDSYS identified by values '72979A94BAD2AF80' ;                                                                                                                                                                                                                                                                                   
alter user MGMT_VIEW identified by values 'E5FADA68187C4631' ;                                                                                                                                                                                                                                                                               
alter user MI identified by values '112281C7D4220796' ;                                                                                                                                                                                                                                                                                      
alter user ORACLE_OCM identified by values '6D17CF1EB1611F94' ;                                                                                                                                                                                                                                                                              
alter user ORDPLUGINS identified by values '88A2B2C183431F00' ;                                                                                                                                                                                                                                                                              
alter user ORDSYS identified by values '7EFA02EC7EA6B86F' ;                                                                                                                                                                                                                                                                                  
alter user SDE identified by values '62B87072023B2E02' ;                                                                                                                                                                                                                                                                                     
alter user SI_INFORMTN_SCHEMA identified by values '84B8CBCA4D477FA3' ;                                                                                                                                                                                                                                                                      
alter user SYSMAN identified by values '6B69163949ED80D4' ;                                                                                                                                                                                                                                                                                  
alter user TSMSYS identified by values '3DF26A8B17D0F29F' ;                                                                                                                                                                                                                                                                                  
alter user USERS identified by values '4DFCDD9BEBFAFB9B' ;                                                                                                                                                                                                                                                                                   
alter user WMSYS identified by values '7C9BA362F8314299' ;                                                                                                                                                                                                                                                                                   
alter user XDB identified by values '88D8364765FCE6AF' ;                                                                                                                                                                                                                                                                                     

25 rows selected.


USERNAME              PASSWORD             Status             PROFILE              EXPIRY_DAT LOCK_DATE  CREATED                                                                                                                                                                                                                             
--------------------- -------------------- ------------------ -------------------- ---------- ---------- ----------                                                                                                                                                                                                                          
ACCMGR                40FA78EEC3F3FBCB     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
ADM                   A67E1BC5E3656755     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
ANONYMOUS             anonymous            EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
APIX                  70A5492191BC955A     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
CENSUS                6A90B584B5D448BF     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
CTXSYS                24ABAB8B06281B4C     OPEN               DEFAULT                                    27-08-2012                                                                                                                                                                                                                          
DBSNMP                689E41C7C31B36DE     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
DIP                   CE4A36B8E06CA59C     EXPIRED & LOCKED   DEFAULT                         25-05-2007 25-05-2007                                                                                                                                                                                                                          
EXFSYS                66F4EF5650C20355     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
LANDS                 B09F67B42D55D7CF     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
LNDGS054              75457BC4FEB010ED     OPEN               DEFAULT                                    27-08-2012                                                                                                                                                                                                                          
MDDATA                DF02A496267DEE66     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
MDSYS                 72979A94BAD2AF80     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
MGMT_VIEW             E5FADA68187C4631     OPEN               DEFAULT                                    09-07-2010                                                                                                                                                                                                                          
MI                    112281C7D4220796     OPEN               DEFAULT                                    27-08-2012                                                                                                                                                                                                                          
ORACLE_OCM            6D17CF1EB1611F94     EXPIRED & LOCKED   DEFAULT                         09-07-2010 09-07-2010                                                                                                                                                                                                                          
ORDPLUGINS            88A2B2C183431F00     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
ORDSYS                7EFA02EC7EA6B86F     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
OUTLN                 4A3BA55E08595C81     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
SDE                   62B87072023B2E02     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
SI_INFORMTN_SCHEMA    84B8CBCA4D477FA3     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
SYS                   F75E6C0CFDE7C488     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
SYSMAN                6B69163949ED80D4     OPEN               DEFAULT                                    09-07-2010                                                                                                                                                                                                                          
SYSTEM                1A2A51E8BB0B485D     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
TSMSYS                3DF26A8B17D0F29F     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
USERS                 4DFCDD9BEBFAFB9B     OPEN               DEFAULT                                    25-05-2007                                                                                                                                                                                                                          
WMSYS                 7C9BA362F8314299     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          
XDB                   88D8364765FCE6AF     EXPIRED & LOCKED   DEFAULT              25-05-2007 25-05-2007 25-05-2007                                                                                                                                                                                                                          

28 rows selected.


SQL> @gen_cr_user
Enter value for v_user: ACCMGR

--------                                                                                           
create user ACCMGR                                                                                 
identified by accmgr123                                                                            
default tablespace ACCMGR                                                                          
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user ACCMGR identified by values '40FA78EEC3F3FBCB';                                         


grant RESOURCE to ACCMGR ;                                                                         
grant CONNECT to ACCMGR ;                                                                          
grant DBA to ACCMGR ;                                                                              

grant CREATE VIEW to ACCMGR ;                                                                      
grant CREATE SEQUENCE to ACCMGR ;                                                                  
grant CREATE TRIGGER to ACCMGR ;                                                                   
grant CREATE TABLE to ACCMGR ;                                                                     
grant CREATE PROCEDURE to ACCMGR ;                                                                 
grant CREATE SESSION to ACCMGR ;                                                                   
grant UNLIMITED TABLESPACE to ACCMGR ;                                                             

grant ALTER on ADM.CODE to ACCMGR  ;                                                               
grant ALTER on ADM.CODE2 to ACCMGR  ;                                                              
grant ALTER on ADM.DEPT to ACCMGR  ;                                                               
grant ALTER on ADM.DOWNLOADRECORDS to ACCMGR  ;                                                    
grant ALTER on ADM.LASTUPDATE to ACCMGR  ;                                                         
grant ALTER on ADM.LOGINRECORDS to ACCMGR  ;                                                       
grant ALTER on ADM.USER_CODE to ACCMGR  ;                                                          
grant ALTER on ADM.USER_INFO to ACCMGR  ;                                                          
grant ALTER on ADM.USER_POSTING to ACCMGR  ;                                                       
grant DELETE on ADM.CODE to ACCMGR  ;                                                              
grant DELETE on ADM.CODE2 to ACCMGR  ;                                                             
grant DELETE on ADM.DEPT to ACCMGR  ;                                                              
grant DELETE on ADM.DOWNLOADRECORDS to ACCMGR  ;                                                   
grant DELETE on ADM.DOWNLOADRECORDS_V to ACCMGR  ;                                                 
grant DELETE on ADM.LASTUPDATE to ACCMGR  ;                                                        
grant DELETE on ADM.LOGIN to ACCMGR  ;                                                             
grant DELETE on ADM.LOGINRECORDS to ACCMGR  ;                                                      
grant DELETE on ADM.USER_CODE to ACCMGR  ;                                                         
grant DELETE on ADM.USER_INFO to ACCMGR  ;                                                         
grant DELETE on ADM.USER_INFO_V to ACCMGR  ;                                                       
grant DELETE on ADM.USER_POSTING to ACCMGR  ;                                                      
grant EXECUTE on SYS.ENCRYPT to ACCMGR  ;                                                          
grant INSERT on ADM.CODE to ACCMGR  ;                                                              
grant INSERT on ADM.CODE2 to ACCMGR  ;                                                             
grant INSERT on ADM.DEPT to ACCMGR  ;                                                              
grant INSERT on ADM.DOWNLOADRECORDS to ACCMGR  ;                                                   
grant INSERT on ADM.DOWNLOADRECORDS_V to ACCMGR  ;                                                 
grant INSERT on ADM.LASTUPDATE to ACCMGR  ;                                                        
grant INSERT on ADM.LOGIN to ACCMGR  ;                                                             
grant INSERT on ADM.LOGINRECORDS to ACCMGR  ;                                                      
grant INSERT on ADM.USER_CODE to ACCMGR  ;                                                         
grant INSERT on ADM.USER_INFO to ACCMGR  ;                                                         
grant INSERT on ADM.USER_INFO_V to ACCMGR  ;                                                       
grant INSERT on ADM.USER_POSTING to ACCMGR  ;                                                      
grant SELECT on ADM.CODE to ACCMGR  ;                                                              
grant SELECT on ADM.CODE2 to ACCMGR  ;                                                             
grant SELECT on ADM.DEPT to ACCMGR  ;                                                              
grant SELECT on ADM.DOWNLOADRECORDS to ACCMGR  ;                                                   
grant SELECT on ADM.DOWNLOADRECORDS_V to ACCMGR  ;                                                 
grant SELECT on ADM.LASTUPDATE to ACCMGR  ;                                                        
grant SELECT on ADM.LOGIN to ACCMGR  ;                                                             
grant SELECT on ADM.LOGINRECORDS to ACCMGR  ;                                                      
grant SELECT on ADM.USER_CODE to ACCMGR  ;                                                         
grant SELECT on ADM.USER_INFO to ACCMGR  ;                                                         
grant SELECT on ADM.USER_INFO_V to ACCMGR  ;                                                       
grant SELECT on ADM.USER_POSTING to ACCMGR  ;                                                      
grant UPDATE on ADM.CODE to ACCMGR  ;                                                              
grant UPDATE on ADM.CODE2 to ACCMGR  ;                                                             
grant UPDATE on ADM.DEPT to ACCMGR  ;                                                              
grant UPDATE on ADM.DOWNLOADRECORDS to ACCMGR  ;                                                   
grant UPDATE on ADM.DOWNLOADRECORDS_V to ACCMGR  ;                                                 
grant UPDATE on ADM.LASTUPDATE to ACCMGR  ;                                                        
grant UPDATE on ADM.LOGIN to ACCMGR  ;                                                             
grant UPDATE on ADM.LOGINRECORDS to ACCMGR  ;                                                      
grant UPDATE on ADM.USER_CODE to ACCMGR  ;                                                         
grant UPDATE on ADM.USER_INFO to ACCMGR  ;                                                         
grant UPDATE on ADM.USER_INFO_V to ACCMGR  ;                                                       
grant UPDATE on ADM.USER_POSTING to ACCMGR  ;                                                      
SQL> @gen_cr_user
Enter value for v_user: ADM

--------                                                                                           
create user ADM                                                                                    
identified by adm123                                                                               
default tablespace ADM                                                                             
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user ADM identified by values 'A67E1BC5E3656755';                                            


grant DBA to ADM ;                                                                                 
grant RESOURCE to ADM ;                                                                            
grant CONNECT to ADM ;                                                                             

grant CREATE PROCEDURE to ADM ;                                                                    
grant CREATE SEQUENCE to ADM ;                                                                     
grant CREATE SESSION to ADM ;                                                                      
grant CREATE TABLE to ADM ;                                                                        
grant CREATE TRIGGER to ADM ;                                                                      
grant CREATE VIEW to ADM ;                                                                         
grant UNLIMITED TABLESPACE to ADM ;                                                                

grant EXECUTE on SYS.ENCRYPT to ADM  ;                                                             
grant EXECUTE on SYSTEM.ENCRYPT to ADM  ;                                                          
SQL> @gen_cr_user
Enter value for v_user: APIX

--------                                                                                           
create user APIX                                                                                   
identified by apix123                                                                              
default tablespace APIX                                                                            
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user APIX identified by values '70A5492191BC955A';                                           


grant CONNECT to APIX ;                                                                            
grant RESOURCE to APIX ;                                                                           

grant CREATE PROCEDURE to APIX ;                                                                   
grant CREATE TABLE to APIX ;                                                                       
grant CREATE SEQUENCE to APIX ;                                                                    
grant CREATE VIEW to APIX ;                                                                        
grant CREATE SESSION to APIX ;                                                                     
grant CREATE TRIGGER to APIX ;                                                                     
grant UNLIMITED TABLESPACE to APIX ;                                                               
SQL> @gen_cr_user
Enter value for v_user: CENSUS

--------                                                                                           
create user CENSUS                                                                                 
identified by census123                                                                            
default tablespace CENSUS                                                                          
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user CENSUS identified by values '6A90B584B5D448BF';                                         


grant CONNECT to CENSUS ;                                                                          
grant RESOURCE to CENSUS ;                                                                         

grant CREATE PROCEDURE to CENSUS ;                                                                 
grant UNLIMITED TABLESPACE to CENSUS ;                                                             
grant CREATE SEQUENCE to CENSUS ;                                                                  
grant CREATE TABLE to CENSUS ;                                                                     
grant CREATE TRIGGER to CENSUS ;                                                                   
grant CREATE VIEW to CENSUS ;                                                                      
grant CREATE SESSION to CENSUS ;                                                                   
SQL> @gen_cr_user
Enter value for v_user: LANDS

--------                                                                                           
create user LANDS                                                                                  
identified by lands123                                                                             
default tablespace LANDS                                                                           
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user LANDS identified by values 'B09F67B42D55D7CF';                                          


grant RESOURCE to LANDS ;                                                                          
grant CONNECT to LANDS ;                                                                           

grant CREATE TABLE to LANDS ;                                                                      
grant CREATE PROCEDURE to LANDS ;                                                                  
grant UNLIMITED TABLESPACE to LANDS ;                                                              
grant CREATE VIEW to LANDS ;                                                                       
grant CREATE SESSION to LANDS ;                                                                    
grant CREATE SEQUENCE to LANDS ;                                                                   
grant CREATE TRIGGER to LANDS ;                                                                    
SQL> @gen_cr_user
Enter value for v_user: lndgs054

--------                                                                                           
create user LNDGS054                                                                               
identified by lndgs054123                                                                          
default tablespace LANDS                                                                           
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user lndgs054 identified by values '75457BC4FEB010ED';                                       


grant RESOURCE to lndgs054 ;                                                                       
grant CONNECT to lndgs054 ;                                                                        

grant CREATE SEQUENCE to lndgs054 ;                                                                
grant CREATE TRIGGER to lndgs054 ;                                                                 
grant CREATE VIEW to lndgs054 ;                                                                    
grant CREATE PROCEDURE to lndgs054 ;                                                               
grant UNLIMITED TABLESPACE to lndgs054 ;                                                           
grant CREATE SESSION to lndgs054 ;                                                                 
grant CREATE TABLE to lndgs054 ;                                                                   

grant EXECUTE on CTXSYS.CTX_CLS to LNDGS054  ;                                                     
grant EXECUTE on CTXSYS.CTX_DDL to LNDGS054  ;                                                     
grant EXECUTE on CTXSYS.CTX_DOC to LNDGS054  ;                                                     
grant EXECUTE on CTXSYS.CTX_OUTPUT to LNDGS054  ;                                                  
grant EXECUTE on CTXSYS.CTX_QUERY to LNDGS054  ;                                                   
grant EXECUTE on CTXSYS.CTX_REPORT to LNDGS054  ;                                                  
grant EXECUTE on CTXSYS.CTX_THES to LNDGS054  ;                                                    
grant EXECUTE on CTXSYS.CTX_ULEXER to LNDGS054  ;                                                  
SQL> @gen_cr_user
Enter value for v_user: USERS

--------                                                                                           
create user USERS                                                                                  
identified by users123                                                                             
default tablespace USERS                                                                           
temporary tablespace TEMP                                                                          
account unlock ;                                                                                   
                                                                                                   
alter user USERS identified by values '4DFCDD9BEBFAFB9B';                                          


grant RESOURCE to USERS ;                                                                          
grant CONNECT to USERS ;                                                                           
grant DBA to USERS ;                                                                               
grant GIH_READ to USERS ;                                                                          

grant CREATE VIEW to USERS ;                                                                       
grant CREATE PROCEDURE to USERS ;                                                                  
grant CREATE SEQUENCE to USERS ;                                                                   
grant UNLIMITED TABLESPACE to USERS ;                                                              
grant CREATE TRIGGER to USERS ;                                                                    
grant CREATE SESSION to USERS ;                                                                    
grant CREATE TABLE to USERS ;                                                                      

grant EXECUTE on SYS.ENCRYPT to USERS  ;                                                           
grant EXECUTE on SYSTEM.ENCRYPT to USERS  ;                                                        
grant SELECT on LANDS.AVAILABLE_TILE_LIST to USERS  ;                                              
grant SELECT on LANDS.F554 to USERS  ;                                                             
grant SELECT on LANDS.S554 to USERS  ;                                                             
grant SELECT on LANDS.TILE_CNT_SUMMARY_V_POLY to USERS  ;                                          
SQL> @show_role

ROLE                           PASSWORD                                                                                                                                                                                       
------------------------------ --------                                                                                                                                                                                       
AQ_ADMINISTRATOR_ROLE          NO                                                                                                                                                                                             
AQ_USER_ROLE                   NO                                                                                                                                                                                             
AUTHENTICATEDUSER              NO                                                                                                                                                                                             
CONNECT                        NO                                                                                                                                                                                             
CTXAPP                         NO                                                                                                                                                                                             
DBA                            NO                                                                                                                                                                                             
DELETE_CATALOG_ROLE            NO                                                                                                                                                                                             
EJBCLIENT                      NO                                                                                                                                                                                             
EXECUTE_CATALOG_ROLE           NO                                                                                                                                                                                             
EXP_FULL_DATABASE              NO                                                                                                                                                                                             
GATHER_SYSTEM_STATISTICS       NO                                                                                                                                                                                             
GIH_READ                       NO                                                                                                                                                                                             
GLOBAL_AQ_USER_ROLE            GLOBAL                                                                                                                                                                                         
HS_ADMIN_ROLE                  NO                                                                                                                                                                                             
IMP_FULL_DATABASE              NO                                                                                                                                                                                             
JAVADEBUGPRIV                  NO                                                                                                                                                                                             
JAVAIDPRIV                     NO                                                                                                                                                                                             
JAVASYSPRIV                    NO                                                                                                                                                                                             
JAVAUSERPRIV                   NO                                                                                                                                                                                             
JAVA_ADMIN                     NO                                                                                                                                                                                             
JAVA_DEPLOY                    NO                                                                                                                                                                                             
LOGSTDBY_ADMINISTRATOR         NO                                                                                                                                                                                             
MGMT_USER                      NO                                                                                                                                                                                             
OEM_ADVISOR                    NO                                                                                                                                                                                             
OEM_MONITOR                    NO                                                                                                                                                                                             
RECOVERY_CATALOG_OWNER         NO                                                                                                                                                                                             
RESOURCE                       NO                                                                                                                                                                                             
SCHEDULER_ADMIN                NO                                                                                                                                                                                             
SELECT_CATALOG_ROLE            NO                                                                                                                                                                                             
WM_ADMIN_ROLE                  NO                                                                                                                                                                                             
XDBADMIN                       NO                                                                                                                                                                                             
XDBWEBSERVICES                 NO                                                                                                                                                                                             

32 rows selected.

SQL> @gen_cr_user
Enter value for v_user: GIH_READ
declare cursor version_cur
*
ERROR at line 1:
ORA-01403: no data found 
ORA-06512: at line 14 




grant INSERT on ADM.CODE to GIH_READ  ;                                                            
grant INSERT on ADM.CODE2 to GIH_READ  ;                                                           
grant INSERT on ADM.DEPT to GIH_READ  ;                                                            
grant INSERT on ADM.DOWNLOADRECORDS to GIH_READ  ;                                                 
grant INSERT on ADM.LASTUPDATE to GIH_READ  ;                                                      
grant INSERT on ADM.LOGINRECORDS to GIH_READ  ;                                                    
grant INSERT on ADM.USER_CODE to GIH_READ  ;                                                       
grant INSERT on ADM.USER_INFO to GIH_READ  ;                                                       
grant INSERT on ADM.USER_POSTING to GIH_READ  ;                                                    
grant SELECT on ADM.CODE to GIH_READ  ;                                                            
grant SELECT on ADM.CODE2 to GIH_READ  ;                                                           
grant SELECT on ADM.DEPT to GIH_READ  ;                                                            
grant SELECT on ADM.DOWNLOADRECORDS to GIH_READ  ;                                                 
grant SELECT on ADM.DOWNLOADRECORDS_V to GIH_READ  ;                                               
grant SELECT on ADM.F486 to GIH_READ  ;                                                            
grant SELECT on ADM.F487 to GIH_READ  ;                                                            
grant SELECT on ADM.F488 to GIH_READ  ;                                                            
grant SELECT on ADM.F489 to GIH_READ  ;                                                            
grant SELECT on ADM.F490 to GIH_READ  ;                                                            
grant SELECT on ADM.F491 to GIH_READ  ;                                                            
grant SELECT on ADM.F492 to GIH_READ  ;                                                            
grant SELECT on ADM.F493 to GIH_READ  ;                                                            
grant SELECT on ADM.F494 to GIH_READ  ;                                                            
grant SELECT on ADM.F495 to GIH_READ  ;                                                            
grant SELECT on ADM.F496 to GIH_READ  ;                                                            
grant SELECT on ADM.F497 to GIH_READ  ;                                                            
grant SELECT on ADM.F498 to GIH_READ  ;                                                            
grant SELECT on ADM.F499 to GIH_READ  ;                                                            
grant SELECT on ADM.F500 to GIH_READ  ;                                                            
grant SELECT on ADM.F501 to GIH_READ  ;                                                            
grant SELECT on ADM.F502 to GIH_READ  ;                                                            
grant SELECT on ADM.F503 to GIH_READ  ;                                                            
grant SELECT on ADM.F505 to GIH_READ  ;                                                            
grant SELECT on ADM.F506 to GIH_READ  ;                                                            
grant SELECT on ADM.F507 to GIH_READ  ;                                                            
grant SELECT on ADM.LASTUPDATE to GIH_READ  ;                                                      
grant SELECT on ADM.LOGIN to GIH_READ  ;                                                           
grant SELECT on ADM.LOGINRECORDS to GIH_READ  ;                                                    
grant SELECT on ADM.S486 to GIH_READ  ;                                                            
grant SELECT on ADM.S487 to GIH_READ  ;                                                            
grant SELECT on ADM.S488 to GIH_READ  ;                                                            
grant SELECT on ADM.S489 to GIH_READ  ;                                                            
grant SELECT on ADM.S490 to GIH_READ  ;                                                            
grant SELECT on ADM.S491 to GIH_READ  ;                                                            
grant SELECT on ADM.S492 to GIH_READ  ;                                                            
grant SELECT on ADM.S493 to GIH_READ  ;                                                            
grant SELECT on ADM.S494 to GIH_READ  ;                                                            
grant SELECT on ADM.S495 to GIH_READ  ;                                                            
grant SELECT on ADM.S496 to GIH_READ  ;                                                            
grant SELECT on ADM.S497 to GIH_READ  ;                                                            
grant SELECT on ADM.S498 to GIH_READ  ;                                                            
grant SELECT on ADM.S499 to GIH_READ  ;                                                            
grant SELECT on ADM.S500 to GIH_READ  ;                                                            
grant SELECT on ADM.S501 to GIH_READ  ;                                                            
grant SELECT on ADM.S502 to GIH_READ  ;                                                            
grant SELECT on ADM.S503 to GIH_READ  ;                                                            
grant SELECT on ADM.S505 to GIH_READ  ;                                                            
grant SELECT on ADM.S506 to GIH_READ  ;                                                            
grant SELECT on ADM.S507 to GIH_READ  ;                                                            
grant SELECT on ADM.USER_CODE to GIH_READ  ;                                                       
grant SELECT on ADM.USER_INFO to GIH_READ  ;                                                       
grant SELECT on ADM.USER_INFO_V to GIH_READ  ;                                                     
grant SELECT on ADM.USER_POSTING to GIH_READ  ;                                                    
grant SELECT on ADM.WATERMARK_0101_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0102_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0103_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0201_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0202_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0203_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0301_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0302_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0303_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0401_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0402_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0403_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0501_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0502_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0503_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0601_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0602_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0603_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0701_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0702_POINT to GIH_READ  ;                                            
grant SELECT on ADM.WATERMARK_0703_POINT to GIH_READ  ;                                            
grant SELECT on APIX.APIX_1963_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1964_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1972_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1973_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1974_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1975_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1976_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1977_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1978_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1979_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1980_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1981_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1982_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1983_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1984_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1985_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1986_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1987_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1988_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1989_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1990_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1991_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1992_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1993_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1994_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1995_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1996_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1997_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1998_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_1999_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2000_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2001_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2002_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2003_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2004_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2005_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2006_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2007_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2008_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2009_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_2010_POINT to GIH_READ  ;                                                
grant SELECT on APIX.APIX_ARC to GIH_READ  ;                                                       
grant SELECT on APIX.APIX_POINT to GIH_READ  ;                                                     
grant SELECT on APIX.APIX_POLY to GIH_READ  ;                                                      
grant SELECT on APIX.APIX_POLY_R to GIH_READ  ;                                                    
grant SELECT on APIX.F443 to GIH_READ  ;                                                           
grant SELECT on APIX.F444 to GIH_READ  ;                                                           
grant SELECT on APIX.F445 to GIH_READ  ;                                                           
grant SELECT on APIX.F446 to GIH_READ  ;                                                           
grant SELECT on APIX.F447 to GIH_READ  ;                                                           
grant SELECT on APIX.F448 to GIH_READ  ;                                                           
grant SELECT on APIX.F449 to GIH_READ  ;                                                           
grant SELECT on APIX.F450 to GIH_READ  ;                                                           
grant SELECT on APIX.F451 to GIH_READ  ;                                                           
grant SELECT on APIX.F452 to GIH_READ  ;                                                           
grant SELECT on APIX.F453 to GIH_READ  ;                                                           
grant SELECT on APIX.F454 to GIH_READ  ;                                                           
grant SELECT on APIX.F455 to GIH_READ  ;                                                           
grant SELECT on APIX.F456 to GIH_READ  ;                                                           
grant SELECT on APIX.F457 to GIH_READ  ;                                                           
grant SELECT on APIX.F458 to GIH_READ  ;                                                           
grant SELECT on APIX.F459 to GIH_READ  ;                                                           
grant SELECT on APIX.F460 to GIH_READ  ;                                                           
grant SELECT on APIX.F461 to GIH_READ  ;                                                           
grant SELECT on APIX.F462 to GIH_READ  ;                                                           
grant SELECT on APIX.F463 to GIH_READ  ;                                                           
grant SELECT on APIX.F464 to GIH_READ  ;                                                           
grant SELECT on APIX.F465 to GIH_READ  ;                                                           
grant SELECT on APIX.F466 to GIH_READ  ;                                                           
grant SELECT on APIX.F467 to GIH_READ  ;                                                           
grant SELECT on APIX.F468 to GIH_READ  ;                                                           
grant SELECT on APIX.F469 to GIH_READ  ;                                                           
grant SELECT on APIX.F470 to GIH_READ  ;                                                           
grant SELECT on APIX.F471 to GIH_READ  ;                                                           
grant SELECT on APIX.F472 to GIH_READ  ;                                                           
grant SELECT on APIX.F473 to GIH_READ  ;                                                           
grant SELECT on APIX.F474 to GIH_READ  ;                                                           
grant SELECT on APIX.F475 to GIH_READ  ;                                                           
grant SELECT on APIX.F476 to GIH_READ  ;                                                           
grant SELECT on APIX.F477 to GIH_READ  ;                                                           
grant SELECT on APIX.F478 to GIH_READ  ;                                                           
grant SELECT on APIX.F479 to GIH_READ  ;                                                           
grant SELECT on APIX.F480 to GIH_READ  ;                                                           
grant SELECT on APIX.F481 to GIH_READ  ;                                                           
grant SELECT on APIX.F482 to GIH_READ  ;                                                           
grant SELECT on APIX.F483 to GIH_READ  ;                                                           
grant SELECT on APIX.F484 to GIH_READ  ;                                                           
grant SELECT on APIX.F512 to GIH_READ  ;                                                           
grant SELECT on APIX.F513 to GIH_READ  ;                                                           
grant SELECT on APIX.F514 to GIH_READ  ;                                                           
grant SELECT on APIX.S443 to GIH_READ  ;                                                           
grant SELECT on APIX.S444 to GIH_READ  ;                                                           
grant SELECT on APIX.S445 to GIH_READ  ;                                                           
grant SELECT on APIX.S446 to GIH_READ  ;                                                           
grant SELECT on APIX.S447 to GIH_READ  ;                                                           
grant SELECT on APIX.S448 to GIH_READ  ;                                                           
grant SELECT on APIX.S449 to GIH_READ  ;                                                           
grant SELECT on APIX.S450 to GIH_READ  ;                                                           
grant SELECT on APIX.S451 to GIH_READ  ;                                                           
grant SELECT on APIX.S452 to GIH_READ  ;                                                           
grant SELECT on APIX.S453 to GIH_READ  ;                                                           
grant SELECT on APIX.S454 to GIH_READ  ;                                                           
grant SELECT on APIX.S455 to GIH_READ  ;                                                           
grant SELECT on APIX.S456 to GIH_READ  ;                                                           
grant SELECT on APIX.S457 to GIH_READ  ;                                                           
grant SELECT on APIX.S458 to GIH_READ  ;                                                           
grant SELECT on APIX.S459 to GIH_READ  ;                                                           
grant SELECT on APIX.S460 to GIH_READ  ;                                                           
grant SELECT on APIX.S461 to GIH_READ  ;                                                           
grant SELECT on APIX.S462 to GIH_READ  ;                                                           
grant SELECT on APIX.S463 to GIH_READ  ;                                                           
grant SELECT on APIX.S464 to GIH_READ  ;                                                           
grant SELECT on APIX.S465 to GIH_READ  ;                                                           
grant SELECT on APIX.S466 to GIH_READ  ;                                                           
grant SELECT on APIX.S467 to GIH_READ  ;                                                           
grant SELECT on APIX.S468 to GIH_READ  ;                                                           
grant SELECT on APIX.S469 to GIH_READ  ;                                                           
grant SELECT on APIX.S470 to GIH_READ  ;                                                           
grant SELECT on APIX.S471 to GIH_READ  ;                                                           
grant SELECT on APIX.S472 to GIH_READ  ;                                                           
grant SELECT on APIX.S473 to GIH_READ  ;                                                           
grant SELECT on APIX.S474 to GIH_READ  ;                                                           
grant SELECT on APIX.S475 to GIH_READ  ;                                                           
grant SELECT on APIX.S476 to GIH_READ  ;                                                           
grant SELECT on APIX.S477 to GIH_READ  ;                                                           
grant SELECT on APIX.S478 to GIH_READ  ;                                                           
grant SELECT on APIX.S479 to GIH_READ  ;                                                           
grant SELECT on APIX.S480 to GIH_READ  ;                                                           
grant SELECT on APIX.S481 to GIH_READ  ;                                                           
grant SELECT on APIX.S482 to GIH_READ  ;                                                           
grant SELECT on APIX.S483 to GIH_READ  ;                                                           
grant SELECT on APIX.S484 to GIH_READ  ;                                                           
grant SELECT on APIX.S512 to GIH_READ  ;                                                           
grant SELECT on APIX.S513 to GIH_READ  ;                                                           
grant SELECT on APIX.S514 to GIH_READ  ;                                                           
grant SELECT on CENSUS.BLDGTYPE_POLY to GIH_READ  ;                                                
grant SELECT on CENSUS.F398 to GIH_READ  ;                                                         
grant SELECT on CENSUS.S398 to GIH_READ  ;                                                         
grant SELECT on LANDS.ADDRHSNOV to GIH_READ  ;                                                     
grant SELECT on LANDS.ADDR_HSNO to GIH_READ  ;                                                     
grant SELECT on LANDS.B100K_BDRY_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_BDRY_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.B100K_BLDG_POLY to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_ELEV_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_ELEV_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.B100K_FACIPOLY_ANNO to GIH_READ  ;                                           
grant SELECT on LANDS.B100K_FACIPOLY_POLY to GIH_READ  ;                                           
grant SELECT on LANDS.B100K_FACI_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_FACI_POINT to GIH_READ  ;                                              
grant SELECT on LANDS.B100K_HEIGHT_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B100K_HEIGHT_POINT to GIH_READ  ;                                            
grant SELECT on LANDS.B100K_HYDRPOLY_ANNO to GIH_READ  ;                                           
grant SELECT on LANDS.B100K_HYDRPOLY_POLY to GIH_READ  ;                                           
grant SELECT on LANDS.B100K_HYDR_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.B100K_PARK_POLY to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_PLAC_ANNO_C to GIH_READ  ;                                             
grant SELECT on LANDS.B100K_PLAC_ANNO_E to GIH_READ  ;                                             
grant SELECT on LANDS.B100K_RAIL_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_RAIL_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.B100K_RELIPOLY_POLY to GIH_READ  ;                                           
grant SELECT on LANDS.B100K_ROAD_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B100K_ROAD_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.B100K_VEGE_POLY to GIH_READ  ;                                               
grant SELECT on LANDS.B10K_BDRY_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_BDRY_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_BDRY_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_BLDG_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_BLDG_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_BLDG_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_BLDG_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_ELEV_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_ELEV_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_FACIPOLY_ANNO_C to GIH_READ  ;                                          
grant SELECT on LANDS.B10K_FACIPOLY_ANNO_E to GIH_READ  ;                                          
grant SELECT on LANDS.B10K_FACIPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_FACI_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_FACI_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_FACI_POINT to GIH_READ  ;                                               
grant SELECT on LANDS.B10K_HEIGHT_ANNO_E to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_HEIGHT_POINT to GIH_READ  ;                                             
grant SELECT on LANDS.B10K_HYDRPOLY_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_HYDRPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_HYDR_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_HYDR_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_INDEX_POLY to GIH_READ  ;                                               
grant SELECT on LANDS.B10K_PARK_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_PARK_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_PARK_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_PLAC_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_PLAC_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_RAILPOLY_ANNO_C to GIH_READ  ;                                          
grant SELECT on LANDS.B10K_RAILPOLY_ANNO_E to GIH_READ  ;                                          
grant SELECT on LANDS.B10K_RAILPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_RAIL_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_RAIL_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_RELIPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_RELI_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_ROADPOLY_ANNO_C to GIH_READ  ;                                          
grant SELECT on LANDS.B10K_ROADPOLY_ANNO_E to GIH_READ  ;                                          
grant SELECT on LANDS.B10K_ROADPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B10K_ROAD_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_ROAD_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_ROAD_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B10K_ROAD_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_UTIL_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B10K_UTIL_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B10K_VEGE_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B1KP_PBLDGPOLY_ANNO to GIH_READ  ;                                           
grant SELECT on LANDS.B1KP_PBLDGPOLY_ANNO_BLDGPOLY_C to GIH_READ  ;                                
grant SELECT on LANDS.B1KP_PBLDGPOLY_ANNO_BLDGPOLY_E to GIH_READ  ;                                
grant SELECT on LANDS.B1KP_PBLDGPOLY_ARC to GIH_READ  ;                                            
grant SELECT on LANDS.B1KP_PBLDGPOLY_POLY to GIH_READ  ;                                           
grant SELECT on LANDS.B1KP_PBLDGPOLY_POLY_V to GIH_READ  ;                                         
grant SELECT on LANDS.B1KP_PPODPOLY_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B1KP_PPODPOLY_ANNO_PODPOLY_C to GIH_READ  ;                                  
grant SELECT on LANDS.B1KP_PPODPOLY_ANNO_PODPOLY_E to GIH_READ  ;                                  
grant SELECT on LANDS.B1KP_PPODPOLY_ARC to GIH_READ  ;                                             
grant SELECT on LANDS.B1KP_PPODPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B1KP_PPODPOLY_POLY_V to GIH_READ  ;                                          
grant SELECT on LANDS.B1KP_PROPINFRA_ANNO to GIH_READ  ;                                           
grant SELECT on LANDS.B1KP_PROPINFRA_ARC to GIH_READ  ;                                            
grant SELECT on LANDS.B1KP_PROPINFRA_POINT to GIH_READ  ;                                          
grant SELECT on LANDS.B1KP_PROPROAD_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B1KP_PROPROAD_ANNO_ROAD_C to GIH_READ  ;                                     
grant SELECT on LANDS.B1KP_PROPROAD_ANNO_ROAD_E to GIH_READ  ;                                     
grant SELECT on LANDS.B1KP_PROPROAD_ARC to GIH_READ  ;                                             
grant SELECT on LANDS.B1KP_PROPSITE_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B1KP_PROPSITE_POLY_V to GIH_READ  ;                                          
grant SELECT on LANDS.B1KP_PSPOTHT_POINT to GIH_READ  ;                                            
grant SELECT on LANDS.B1K_BDYFEAT_ARC to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_BLDGPOLY_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_BLDGPOLY_ANNO_BLDGPOLY_C to GIH_READ  ;                                  
grant SELECT on LANDS.B1K_BLDGPOLY_ANNO_BLDGPOLY_E to GIH_READ  ;                                  
grant SELECT on LANDS.B1K_BLDGPOLY_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_BLDGPOLY_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_BLDGPOLY_POLY_V to GIH_READ  ;                                           
grant SELECT on LANDS.B1K_BLDG_ANNO to GIH_READ  ;                                                 
grant SELECT on LANDS.B1K_BLDG_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B1K_CONTOUR_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_CONTOUR_ARC to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_DBLDGPOLY_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B1K_DBLDGPOLY_ANNO_BLDGPOLY_C to GIH_READ  ;                                 
grant SELECT on LANDS.B1K_DBLDGPOLY_ANNO_BLDGPOLY_E to GIH_READ  ;                                 
grant SELECT on LANDS.B1K_DBLDGPOLY_ARC to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_DBLDGPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B1K_DPODPOLY_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_DPODPOLY_ANNO_PODPOLY_C to GIH_READ  ;                                   
grant SELECT on LANDS.B1K_DPODPOLY_ANNO_PODPOLY_E to GIH_READ  ;                                   
grant SELECT on LANDS.B1K_DPODPOLY_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_DPODPOLY_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_GENANNO_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_GENANNO_DGS_POINT to GIH_READ  ;                                         
grant SELECT on LANDS.B1K_INDEX_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B1K_INDEX_PORTION_POLY to GIH_READ  ;                                        
grant SELECT on LANDS.B1K_INDEX_VRML_POLY to GIH_READ  ;                                           
grant SELECT on LANDS.B1K_MISCLINE_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_MISCLINE_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_MISCPT_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_MISCPT_POINT to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_OBLDG_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B1K_OBLDG_POINT to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_PODPOLY_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_PODPOLY_ANNO_PODPOLY_C to GIH_READ  ;                                    
grant SELECT on LANDS.B1K_PODPOLY_ANNO_PODPOLY_E to GIH_READ  ;                                    
grant SELECT on LANDS.B1K_PODPOLY_ARC to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_PODPOLY_POLY to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_PODPOLY_POLY_V to GIH_READ  ;                                            
grant SELECT on LANDS.B1K_POLYFEAT_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B1K_RAIL_ANNO to GIH_READ  ;                                                 
grant SELECT on LANDS.B1K_RAIL_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B1K_RELIEF_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_RELIEF_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.B1K_ROAD_ANNO to GIH_READ  ;                                                 
grant SELECT on LANDS.B1K_ROAD_ANNO_ROAD_C to GIH_READ  ;                                          
grant SELECT on LANDS.B1K_ROAD_ANNO_ROAD_E to GIH_READ  ;                                          
grant SELECT on LANDS.B1K_ROAD_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B1K_SLOPE_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B1K_SPOTHT_POINT to GIH_READ  ;                                              
grant SELECT on LANDS.B1K_UTILPT_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B1K_UTILPT_LP_POINT to GIH_READ  ;                                           
grant SELECT on LANDS.B1K_UTILPT_POINT to GIH_READ  ;                                              
grant SELECT on LANDS.B20K_BDRY_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_BDRY_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_BLDG_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_BLDG_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_ELEV_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_ELEV_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_FACIPOLY_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B20K_FACIPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B20K_FACI_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_FACI_POINT to GIH_READ  ;                                               
grant SELECT on LANDS.B20K_HEIGHT_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B20K_HEIGHT_POINT to GIH_READ  ;                                             
grant SELECT on LANDS.B20K_HYDRPOLY_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B20K_HYDRPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B20K_HYDR_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_HYDR_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_INDEX_POLY to GIH_READ  ;                                               
grant SELECT on LANDS.B20K_PARK_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_PARK_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_PLAC_ANNO_C to GIH_READ  ;                                              
grant SELECT on LANDS.B20K_PLAC_ANNO_E to GIH_READ  ;                                              
grant SELECT on LANDS.B20K_RAIL_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_RAIL_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_RELIPOLY_POLY to GIH_READ  ;                                            
grant SELECT on LANDS.B20K_RELI_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_ROAD_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_ROAD_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_UTIL_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B20K_UTIL_ARC to GIH_READ  ;                                                 
grant SELECT on LANDS.B20K_VEGE_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B2K_BLDGPOLY_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B2K_BLDGPOLY_ANNO_BLDGPOLY_C to GIH_READ  ;                                  
grant SELECT on LANDS.B2K_BLDGPOLY_ANNO_BLDGPOLY_E to GIH_READ  ;                                  
grant SELECT on LANDS.B2K_BLDG_ANNO to GIH_READ  ;                                                 
grant SELECT on LANDS.B2K_CONTOUR_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B2K_DBLDGPOLY_ANNO to GIH_READ  ;                                            
grant SELECT on LANDS.B2K_DBLDGPOLY_ANNO_BLDGPOLY_C to GIH_READ  ;                                 
grant SELECT on LANDS.B2K_DBLDGPOLY_ANNO_BLDGPOLY_E to GIH_READ  ;                                 
grant SELECT on LANDS.B2K_DPODPOLY_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B2K_DPODPOLY_ANNO_PODPOLY_C to GIH_READ  ;                                   
grant SELECT on LANDS.B2K_DPODPOLY_ANNO_PODPOLY_E to GIH_READ  ;                                   
grant SELECT on LANDS.B2K_GENANNO_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B2K_MISCLINE_ANNO to GIH_READ  ;                                             
grant SELECT on LANDS.B2K_MISCPT_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B2K_PODPOLY_ANNO to GIH_READ  ;                                              
grant SELECT on LANDS.B2K_PODPOLY_ANNO_PODPOLY_C to GIH_READ  ;                                    
grant SELECT on LANDS.B2K_PODPOLY_ANNO_PODPOLY_E to GIH_READ  ;                                    
grant SELECT on LANDS.B2K_RAIL_ANNO to GIH_READ  ;                                                 
grant SELECT on LANDS.B2K_RELIEF_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B2K_ROAD_ANNO to GIH_READ  ;                                                 
grant SELECT on LANDS.B2K_ROAD_ANNO_ROAD_C to GIH_READ  ;                                          
grant SELECT on LANDS.B2K_ROAD_ANNO_ROAD_E to GIH_READ  ;                                          
grant SELECT on LANDS.B2K_SLOPE_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B2K_UTILPT_ANNO to GIH_READ  ;                                               
grant SELECT on LANDS.B50K_BDRY_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_BLDG_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_ELEV_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_FACI_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_HYDR_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_PARK_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_PLAC_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_RAIL_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_RELI_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_ROAD_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_UTIL_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B50K_VEGE_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.B5K_ARFT_ANNO_ARFT_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_ARFT_ANNO_ARFT_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_ARFT_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_ARFT_POLY to GIH_READ  ;                                                 
grant SELECT on LANDS.B5K_BDFT_ANNO_BDFT_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_BDFT_ANNO_BDFT_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_BDFT_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_BLDG_ANNO_BLDG_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_BLDG_ANNO_BLDG_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_BLDG_ANNO_HSNO to GIH_READ  ;                                            
grant SELECT on LANDS.B5K_BLDG_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_BLDG_POLY to GIH_READ  ;                                                 
grant SELECT on LANDS.B5K_BRIDGEFILL_ARC to GIH_READ  ;                                            
grant SELECT on LANDS.B5K_BRIDGEFILL_POLY to GIH_READ  ;                                           
grant SELECT on LANDS.B5K_CONT_ANNO_HEIGHT to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_CONT_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_FACI_POINT to GIH_READ  ;                                                
grant SELECT on LANDS.B5K_GENO_ANNO_GENO_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_GENO_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_HYDR_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_HYDR_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_SETT_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_SETT_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_TOPO_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_GENO_ANNO_TOPO_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_HYDOFILL_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.B5K_HYDOFILL_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B5K_HYDO_ANNO_HYDO_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_HYDO_ANNO_HYDO_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_HYDO_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_INDEX_POLY to GIH_READ  ;                                                
grant SELECT on LANDS.B5K_LANDFILL_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.B5K_LANDFILL_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B5K_PARKFILL_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B5K_RAIL_ANNO_RAIL_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_RAIL_ANNO_RAIL_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_RAIL_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_RELI_ANNO_RELI_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_RELI_ANNO_RELI_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_RELI_ANNO_SLOPE to GIH_READ  ;                                           
grant SELECT on LANDS.B5K_RELI_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_ROADFILL_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.B5K_ROADFILL_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.B5K_ROAD_ANNO_NAME_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_ROAD_ANNO_NAME_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_ROAD_ANNO_ROAD_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_ROAD_ANNO_ROAD_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_ROAD_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_SPOT_POINT to GIH_READ  ;                                                
grant SELECT on LANDS.B5K_UTIL_ANNO_UTIL_C to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_UTIL_ANNO_UTIL_E to GIH_READ  ;                                          
grant SELECT on LANDS.B5K_UTIL_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.B5K_WIP_ANNO_WIP_C to GIH_READ  ;                                            
grant SELECT on LANDS.B5K_WIP_ANNO_WIP_E to GIH_READ  ;                                            
grant SELECT on LANDS.B5K_WIP_ARC to GIH_READ  ;                                                   
grant SELECT on LANDS.BIN$OpmOemBeT6+RKAmwJjB9CQ==$0 to GIH_READ  ;                                
grant SELECT on LANDS.BLDG to GIH_READ  ;                                                          
grant SELECT on LANDS.BLDGPOLY_PLU to GIH_READ  ;                                                  
grant SELECT on LANDS.BLDGTYPE to GIH_READ  ;                                                      
grant SELECT on LANDS.BLDG_CSUID to GIH_READ  ;                                                    
grant SELECT on LANDS.BLDG_NAME to GIH_READ  ;                                                     
grant SELECT on LANDS.BMIS to GIH_READ  ;                                                          
grant SELECT on LANDS.BMIS_GEOREFNO to GIH_READ  ;                                                 
grant SELECT on LANDS.CLASS_SYM to GIH_READ  ;                                                     
grant SELECT on LANDS.DB_ANNO to GIH_READ  ;                                                       
grant SELECT on LANDS.DB_ARC to GIH_READ  ;                                                        
grant SELECT on LANDS.DB_POLY to GIH_READ  ;                                                       
grant SELECT on LANDS.DTM_POLY to GIH_READ  ;                                                      
grant SELECT on LANDS.F1 to GIH_READ  ;                                                            
grant SELECT on LANDS.F100 to GIH_READ  ;                                                          
grant SELECT on LANDS.F101 to GIH_READ  ;                                                          
grant SELECT on LANDS.F102 to GIH_READ  ;                                                          
grant SELECT on LANDS.F103 to GIH_READ  ;                                                          
grant SELECT on LANDS.F104 to GIH_READ  ;                                                          
grant SELECT on LANDS.F105 to GIH_READ  ;                                                          
grant SELECT on LANDS.F106 to GIH_READ  ;                                                          
grant SELECT on LANDS.F107 to GIH_READ  ;                                                          
grant SELECT on LANDS.F108 to GIH_READ  ;                                                          
grant SELECT on LANDS.F109 to GIH_READ  ;                                                          
grant SELECT on LANDS.F11 to GIH_READ  ;                                                           
grant SELECT on LANDS.F110 to GIH_READ  ;                                                          
grant SELECT on LANDS.F111 to GIH_READ  ;                                                          
grant SELECT on LANDS.F112 to GIH_READ  ;                                                          
grant SELECT on LANDS.F113 to GIH_READ  ;                                                          
grant SELECT on LANDS.F114 to GIH_READ  ;                                                          
grant SELECT on LANDS.F115 to GIH_READ  ;                                                          
grant SELECT on LANDS.F116 to GIH_READ  ;                                                          
grant SELECT on LANDS.F117 to GIH_READ  ;                                                          
grant SELECT on LANDS.F118 to GIH_READ  ;                                                          
grant SELECT on LANDS.F119 to GIH_READ  ;                                                          
grant SELECT on LANDS.F12 to GIH_READ  ;                                                           
grant SELECT on LANDS.F120 to GIH_READ  ;                                                          
grant SELECT on LANDS.F121 to GIH_READ  ;                                                          
grant SELECT on LANDS.F122 to GIH_READ  ;                                                          
grant SELECT on LANDS.F123 to GIH_READ  ;                                                          
grant SELECT on LANDS.F124 to GIH_READ  ;                                                          
grant SELECT on LANDS.F125 to GIH_READ  ;                                                          
grant SELECT on LANDS.F126 to GIH_READ  ;                                                          
grant SELECT on LANDS.F127 to GIH_READ  ;                                                          
grant SELECT on LANDS.F128 to GIH_READ  ;                                                          
grant SELECT on LANDS.F129 to GIH_READ  ;                                                          
grant SELECT on LANDS.F13 to GIH_READ  ;                                                           
grant SELECT on LANDS.F130 to GIH_READ  ;                                                          
grant SELECT on LANDS.F131 to GIH_READ  ;                                                          
grant SELECT on LANDS.F132 to GIH_READ  ;                                                          
grant SELECT on LANDS.F133 to GIH_READ  ;                                                          
grant SELECT on LANDS.F134 to GIH_READ  ;                                                          
grant SELECT on LANDS.F135 to GIH_READ  ;                                                          
grant SELECT on LANDS.F136 to GIH_READ  ;                                                          
grant SELECT on LANDS.F137 to GIH_READ  ;                                                          
grant SELECT on LANDS.F138 to GIH_READ  ;                                                          
grant SELECT on LANDS.F139 to GIH_READ  ;                                                          
grant SELECT on LANDS.F14 to GIH_READ  ;                                                           
grant SELECT on LANDS.F140 to GIH_READ  ;                                                          
grant SELECT on LANDS.F141 to GIH_READ  ;                                                          
grant SELECT on LANDS.F142 to GIH_READ  ;                                                          
grant SELECT on LANDS.F143 to GIH_READ  ;                                                          
grant SELECT on LANDS.F144 to GIH_READ  ;                                                          
grant SELECT on LANDS.F145 to GIH_READ  ;                                                          
grant SELECT on LANDS.F146 to GIH_READ  ;                                                          
grant SELECT on LANDS.F147 to GIH_READ  ;                                                          
grant SELECT on LANDS.F148 to GIH_READ  ;                                                          
grant SELECT on LANDS.F149 to GIH_READ  ;                                                          
grant SELECT on LANDS.F15 to GIH_READ  ;                                                           
grant SELECT on LANDS.F150 to GIH_READ  ;                                                          
grant SELECT on LANDS.F151 to GIH_READ  ;                                                          
grant SELECT on LANDS.F152 to GIH_READ  ;                                                          
grant SELECT on LANDS.F153 to GIH_READ  ;                                                          
grant SELECT on LANDS.F154 to GIH_READ  ;                                                          
grant SELECT on LANDS.F155 to GIH_READ  ;                                                          
grant SELECT on LANDS.F156 to GIH_READ  ;                                                          
grant SELECT on LANDS.F157 to GIH_READ  ;                                                          
grant SELECT on LANDS.F158 to GIH_READ  ;                                                          
grant SELECT on LANDS.F159 to GIH_READ  ;                                                          
grant SELECT on LANDS.F16 to GIH_READ  ;                                                           
grant SELECT on LANDS.F160 to GIH_READ  ;                                                          
grant SELECT on LANDS.F161 to GIH_READ  ;                                                          
grant SELECT on LANDS.F162 to GIH_READ  ;                                                          
grant SELECT on LANDS.F163 to GIH_READ  ;                                                          
grant SELECT on LANDS.F164 to GIH_READ  ;                                                          
grant SELECT on LANDS.F165 to GIH_READ  ;                                                          
grant SELECT on LANDS.F166 to GIH_READ  ;                                                          
grant SELECT on LANDS.F167 to GIH_READ  ;                                                          
grant SELECT on LANDS.F168 to GIH_READ  ;                                                          
grant SELECT on LANDS.F169 to GIH_READ  ;                                                          
grant SELECT on LANDS.F17 to GIH_READ  ;                                                           
grant SELECT on LANDS.F170 to GIH_READ  ;                                                          
grant SELECT on LANDS.F171 to GIH_READ  ;                                                          
grant SELECT on LANDS.F172 to GIH_READ  ;                                                          
grant SELECT on LANDS.F173 to GIH_READ  ;                                                          
grant SELECT on LANDS.F174 to GIH_READ  ;                                                          
grant SELECT on LANDS.F175 to GIH_READ  ;                                                          
grant SELECT on LANDS.F176 to GIH_READ  ;                                                          
grant SELECT on LANDS.F177 to GIH_READ  ;                                                          
grant SELECT on LANDS.F178 to GIH_READ  ;                                                          
grant SELECT on LANDS.F179 to GIH_READ  ;                                                          
grant SELECT on LANDS.F18 to GIH_READ  ;                                                           
grant SELECT on LANDS.F180 to GIH_READ  ;                                                          
grant SELECT on LANDS.F181 to GIH_READ  ;                                                          
grant SELECT on LANDS.F182 to GIH_READ  ;                                                          
grant SELECT on LANDS.F183 to GIH_READ  ;                                                          
grant SELECT on LANDS.F184 to GIH_READ  ;                                                          
grant SELECT on LANDS.F185 to GIH_READ  ;                                                          
grant SELECT on LANDS.F186 to GIH_READ  ;                                                          
grant SELECT on LANDS.F187 to GIH_READ  ;                                                          
grant SELECT on LANDS.F188 to GIH_READ  ;                                                          
grant SELECT on LANDS.F189 to GIH_READ  ;                                                          
grant SELECT on LANDS.F19 to GIH_READ  ;                                                           
grant SELECT on LANDS.F190 to GIH_READ  ;                                                          
grant SELECT on LANDS.F191 to GIH_READ  ;                                                          
grant SELECT on LANDS.F192 to GIH_READ  ;                                                          
grant SELECT on LANDS.F193 to GIH_READ  ;                                                          
grant SELECT on LANDS.F194 to GIH_READ  ;                                                          
grant SELECT on LANDS.F195 to GIH_READ  ;                                                          
grant SELECT on LANDS.F196 to GIH_READ  ;                                                          
grant SELECT on LANDS.F197 to GIH_READ  ;                                                          
grant SELECT on LANDS.F198 to GIH_READ  ;                                                          
grant SELECT on LANDS.F199 to GIH_READ  ;                                                          
grant SELECT on LANDS.F2 to GIH_READ  ;                                                            
grant SELECT on LANDS.F20 to GIH_READ  ;                                                           
grant SELECT on LANDS.F200 to GIH_READ  ;                                                          
grant SELECT on LANDS.F201 to GIH_READ  ;                                                          
grant SELECT on LANDS.F202 to GIH_READ  ;                                                          
grant SELECT on LANDS.F203 to GIH_READ  ;                                                          
grant SELECT on LANDS.F204 to GIH_READ  ;                                                          
grant SELECT on LANDS.F205 to GIH_READ  ;                                                          
grant SELECT on LANDS.F206 to GIH_READ  ;                                                          
grant SELECT on LANDS.F207 to GIH_READ  ;                                                          
grant SELECT on LANDS.F208 to GIH_READ  ;                                                          
grant SELECT on LANDS.F209 to GIH_READ  ;                                                          
grant SELECT on LANDS.F21 to GIH_READ  ;                                                           
grant SELECT on LANDS.F210 to GIH_READ  ;                                                          
grant SELECT on LANDS.F211 to GIH_READ  ;                                                          
grant SELECT on LANDS.F212 to GIH_READ  ;                                                          
grant SELECT on LANDS.F213 to GIH_READ  ;                                                          
grant SELECT on LANDS.F214 to GIH_READ  ;                                                          
grant SELECT on LANDS.F215 to GIH_READ  ;                                                          
grant SELECT on LANDS.F216 to GIH_READ  ;                                                          
grant SELECT on LANDS.F217 to GIH_READ  ;                                                          
grant SELECT on LANDS.F218 to GIH_READ  ;                                                          
grant SELECT on LANDS.F219 to GIH_READ  ;                                                          
grant SELECT on LANDS.F22 to GIH_READ  ;                                                           
grant SELECT on LANDS.F220 to GIH_READ  ;                                                          
grant SELECT on LANDS.F221 to GIH_READ  ;                                                          
grant SELECT on LANDS.F222 to GIH_READ  ;                                                          
grant SELECT on LANDS.F223 to GIH_READ  ;                                                          
grant SELECT on LANDS.F224 to GIH_READ  ;                                                          
grant SELECT on LANDS.F225 to GIH_READ  ;                                                          
grant SELECT on LANDS.F226 to GIH_READ  ;                                                          
grant SELECT on LANDS.F227 to GIH_READ  ;                                                          
grant SELECT on LANDS.F228 to GIH_READ  ;                                                          
grant SELECT on LANDS.F229 to GIH_READ  ;                                                          
grant SELECT on LANDS.F23 to GIH_READ  ;                                                           
grant SELECT on LANDS.F230 to GIH_READ  ;                                                          
grant SELECT on LANDS.F231 to GIH_READ  ;                                                          
grant SELECT on LANDS.F232 to GIH_READ  ;                                                          
grant SELECT on LANDS.F233 to GIH_READ  ;                                                          
grant SELECT on LANDS.F234 to GIH_READ  ;                                                          
grant SELECT on LANDS.F235 to GIH_READ  ;                                                          
grant SELECT on LANDS.F236 to GIH_READ  ;                                                          
grant SELECT on LANDS.F237 to GIH_READ  ;                                                          
grant SELECT on LANDS.F238 to GIH_READ  ;                                                          
grant SELECT on LANDS.F239 to GIH_READ  ;                                                          
grant SELECT on LANDS.F24 to GIH_READ  ;                                                           
grant SELECT on LANDS.F240 to GIH_READ  ;                                                          
grant SELECT on LANDS.F241 to GIH_READ  ;                                                          
grant SELECT on LANDS.F242 to GIH_READ  ;                                                          
grant SELECT on LANDS.F243 to GIH_READ  ;                                                          
grant SELECT on LANDS.F244 to GIH_READ  ;                                                          
grant SELECT on LANDS.F245 to GIH_READ  ;                                                          
grant SELECT on LANDS.F246 to GIH_READ  ;                                                          
grant SELECT on LANDS.F247 to GIH_READ  ;                                                          
grant SELECT on LANDS.F248 to GIH_READ  ;                                                          
grant SELECT on LANDS.F249 to GIH_READ  ;                                                          
grant SELECT on LANDS.F250 to GIH_READ  ;                                                          
grant SELECT on LANDS.F251 to GIH_READ  ;                                                          
grant SELECT on LANDS.F252 to GIH_READ  ;                                                          
grant SELECT on LANDS.F253 to GIH_READ  ;                                                          
grant SELECT on LANDS.F254 to GIH_READ  ;                                                          
grant SELECT on LANDS.F255 to GIH_READ  ;                                                          
grant SELECT on LANDS.F256 to GIH_READ  ;                                                          
grant SELECT on LANDS.F257 to GIH_READ  ;                                                          
grant SELECT on LANDS.F258 to GIH_READ  ;                                                          
grant SELECT on LANDS.F259 to GIH_READ  ;                                                          
grant SELECT on LANDS.F26 to GIH_READ  ;                                                           
grant SELECT on LANDS.F260 to GIH_READ  ;                                                          
grant SELECT on LANDS.F261 to GIH_READ  ;                                                          
grant SELECT on LANDS.F262 to GIH_READ  ;                                                          
grant SELECT on LANDS.F263 to GIH_READ  ;                                                          
grant SELECT on LANDS.F264 to GIH_READ  ;                                                          
grant SELECT on LANDS.F265 to GIH_READ  ;                                                          
grant SELECT on LANDS.F266 to GIH_READ  ;                                                          
grant SELECT on LANDS.F27 to GIH_READ  ;                                                           
grant SELECT on LANDS.F275 to GIH_READ  ;                                                          
grant SELECT on LANDS.F276 to GIH_READ  ;                                                          
grant SELECT on LANDS.F277 to GIH_READ  ;                                                          
grant SELECT on LANDS.F28 to GIH_READ  ;                                                           
grant SELECT on LANDS.F280 to GIH_READ  ;                                                          
grant SELECT on LANDS.F281 to GIH_READ  ;                                                          
grant SELECT on LANDS.F282 to GIH_READ  ;                                                          
grant SELECT on LANDS.F283 to GIH_READ  ;                                                          
grant SELECT on LANDS.F284 to GIH_READ  ;                                                          
grant SELECT on LANDS.F285 to GIH_READ  ;                                                          
grant SELECT on LANDS.F286 to GIH_READ  ;                                                          
grant SELECT on LANDS.F29 to GIH_READ  ;                                                           
grant SELECT on LANDS.F30 to GIH_READ  ;                                                           
grant SELECT on LANDS.F31 to GIH_READ  ;                                                           
grant SELECT on LANDS.F32 to GIH_READ  ;                                                           
grant SELECT on LANDS.F33 to GIH_READ  ;                                                           
grant SELECT on LANDS.F34 to GIH_READ  ;                                                           
grant SELECT on LANDS.F35 to GIH_READ  ;                                                           
grant SELECT on LANDS.F36 to GIH_READ  ;                                                           
grant SELECT on LANDS.F37 to GIH_READ  ;                                                           
grant SELECT on LANDS.F38 to GIH_READ  ;                                                           
grant SELECT on LANDS.F39 to GIH_READ  ;                                                           
grant SELECT on LANDS.F4 to GIH_READ  ;                                                            
grant SELECT on LANDS.F40 to GIH_READ  ;                                                           
grant SELECT on LANDS.F41 to GIH_READ  ;                                                           
grant SELECT on LANDS.F410 to GIH_READ  ;                                                          
grant SELECT on LANDS.F411 to GIH_READ  ;                                                          
grant SELECT on LANDS.F412 to GIH_READ  ;                                                          
grant SELECT on LANDS.F413 to GIH_READ  ;                                                          
grant SELECT on LANDS.F414 to GIH_READ  ;                                                          
grant SELECT on LANDS.F415 to GIH_READ  ;                                                          
grant SELECT on LANDS.F416 to GIH_READ  ;                                                          
grant SELECT on LANDS.F417 to GIH_READ  ;                                                          
grant SELECT on LANDS.F42 to GIH_READ  ;                                                           
grant SELECT on LANDS.F425 to GIH_READ  ;                                                          
grant SELECT on LANDS.F426 to GIH_READ  ;                                                          
grant SELECT on LANDS.F427 to GIH_READ  ;                                                          
grant SELECT on LANDS.F428 to GIH_READ  ;                                                          
grant SELECT on LANDS.F43 to GIH_READ  ;                                                           
grant SELECT on LANDS.F432 to GIH_READ  ;                                                          
grant SELECT on LANDS.F435 to GIH_READ  ;                                                          
grant SELECT on LANDS.F437 to GIH_READ  ;                                                          
grant SELECT on LANDS.F438 to GIH_READ  ;                                                          
grant SELECT on LANDS.F439 to GIH_READ  ;                                                          
grant SELECT on LANDS.F44 to GIH_READ  ;                                                           
grant SELECT on LANDS.F441 to GIH_READ  ;                                                          
grant SELECT on LANDS.F442 to GIH_READ  ;                                                          
grant SELECT on LANDS.F45 to GIH_READ  ;                                                           
grant SELECT on LANDS.F46 to GIH_READ  ;                                                           
grant SELECT on LANDS.F47 to GIH_READ  ;                                                           
grant SELECT on LANDS.F48 to GIH_READ  ;                                                           
grant SELECT on LANDS.F49 to GIH_READ  ;                                                           
grant SELECT on LANDS.F5 to GIH_READ  ;                                                            
grant SELECT on LANDS.F50 to GIH_READ  ;                                                           
grant SELECT on LANDS.F508 to GIH_READ  ;                                                          
grant SELECT on LANDS.F509 to GIH_READ  ;                                                          
grant SELECT on LANDS.F51 to GIH_READ  ;                                                           
grant SELECT on LANDS.F510 to GIH_READ  ;                                                          
grant SELECT on LANDS.F511 to GIH_READ  ;                                                          
grant SELECT on LANDS.F52 to GIH_READ  ;                                                           
grant SELECT on LANDS.F53 to GIH_READ  ;                                                           
grant SELECT on LANDS.F54 to GIH_READ  ;                                                           
grant SELECT on LANDS.F549 to GIH_READ  ;                                                          
grant SELECT on LANDS.F55 to GIH_READ  ;                                                           
grant SELECT on LANDS.F59 to GIH_READ  ;                                                           
grant SELECT on LANDS.F6 to GIH_READ  ;                                                            
grant SELECT on LANDS.F60 to GIH_READ  ;                                                           
grant SELECT on LANDS.F61 to GIH_READ  ;                                                           
grant SELECT on LANDS.F62 to GIH_READ  ;                                                           
grant SELECT on LANDS.F63 to GIH_READ  ;                                                           
grant SELECT on LANDS.F64 to GIH_READ  ;                                                           
grant SELECT on LANDS.F65 to GIH_READ  ;                                                           
grant SELECT on LANDS.F66 to GIH_READ  ;                                                           
grant SELECT on LANDS.F67 to GIH_READ  ;                                                           
grant SELECT on LANDS.F68 to GIH_READ  ;                                                           
grant SELECT on LANDS.F69 to GIH_READ  ;                                                           
grant SELECT on LANDS.F7 to GIH_READ  ;                                                            
grant SELECT on LANDS.F70 to GIH_READ  ;                                                           
grant SELECT on LANDS.F71 to GIH_READ  ;                                                           
grant SELECT on LANDS.F72 to GIH_READ  ;                                                           
grant SELECT on LANDS.F73 to GIH_READ  ;                                                           
grant SELECT on LANDS.F74 to GIH_READ  ;                                                           
grant SELECT on LANDS.F75 to GIH_READ  ;                                                           
grant SELECT on LANDS.F79 to GIH_READ  ;                                                           
grant SELECT on LANDS.F8 to GIH_READ  ;                                                            
grant SELECT on LANDS.F80 to GIH_READ  ;                                                           
grant SELECT on LANDS.F81 to GIH_READ  ;                                                           
grant SELECT on LANDS.F82 to GIH_READ  ;                                                           
grant SELECT on LANDS.F83 to GIH_READ  ;                                                           
grant SELECT on LANDS.F84 to GIH_READ  ;                                                           
grant SELECT on LANDS.F85 to GIH_READ  ;                                                           
grant SELECT on LANDS.F86 to GIH_READ  ;                                                           
grant SELECT on LANDS.F87 to GIH_READ  ;                                                           
grant SELECT on LANDS.F88 to GIH_READ  ;                                                           
grant SELECT on LANDS.F89 to GIH_READ  ;                                                           
grant SELECT on LANDS.F9 to GIH_READ  ;                                                            
grant SELECT on LANDS.F90 to GIH_READ  ;                                                           
grant SELECT on LANDS.F91 to GIH_READ  ;                                                           
grant SELECT on LANDS.F92 to GIH_READ  ;                                                           
grant SELECT on LANDS.F93 to GIH_READ  ;                                                           
grant SELECT on LANDS.F94 to GIH_READ  ;                                                           
grant SELECT on LANDS.F95 to GIH_READ  ;                                                           
grant SELECT on LANDS.F96 to GIH_READ  ;                                                           
grant SELECT on LANDS.F97 to GIH_READ  ;                                                           
grant SELECT on LANDS.F98 to GIH_READ  ;                                                           
grant SELECT on LANDS.F99 to GIH_READ  ;                                                           
grant SELECT on LANDS.G1K_SITE_POLY to GIH_READ  ;                                                 
grant SELECT on LANDS.G1K_SITE_POLY_V to GIH_READ  ;                                               
grant SELECT on LANDS.G1K_STREET_ARC to GIH_READ  ;                                                
grant SELECT on LANDS.GEO_REFERENCE to GIH_READ  ;                                                 
grant SELECT on LANDS.L1KR_GEOSITE_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.L1KR_GEOSITE_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.L1KR_LICENCELN_ARC to GIH_READ  ;                                            
grant SELECT on LANDS.L1KR_LICENCE_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.L1KR_LICENCE_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.L1KR_LOT_ARC to GIH_READ  ;                                                  
grant SELECT on LANDS.L1KR_LOT_POLY to GIH_READ  ;                                                 
grant SELECT on LANDS.L1KR_LOT_POLY_B to GIH_READ  ;                                               
grant SELECT on LANDS.L1KR_OVERLAPLIC_ARC to GIH_READ  ;                                           
grant SELECT on LANDS.L1KR_OVERLAPLOT_ARC to GIH_READ  ;                                           
grant SELECT on LANDS.L1KR_OVERLAPVO_ARC to GIH_READ  ;                                            
grant SELECT on LANDS.L20K_DDBOUND_ARC to GIH_READ  ;                                              
grant SELECT on LANDS.L20K_DDBOUND_POLY to GIH_READ  ;                                             
grant SELECT on LANDS.L20K_RRESRV_ARC to GIH_READ  ;                                               
grant SELECT on LANDS.L20K_RRESRV_MTRL_ARC to GIH_READ  ;                                          
grant SELECT on LANDS.LANDOWNER to GIH_READ  ;                                                     
grant SELECT on LANDS.LICENCE to GIH_READ  ;                                                       
grant SELECT on LANDS.LOT to GIH_READ  ;                                                           
grant SELECT on LANDS.LOTCCDATE_LUT to GIH_READ  ;                                                 
grant SELECT on LANDS.LOTCODE to GIH_READ  ;                                                       
grant SELECT on LANDS.LOTNAME_BY_DIST to GIH_READ  ;                                               
grant SELECT on LANDS.LOTNAME_LUT to GIH_READ  ;                                                   
grant SELECT on LANDS.MAP_FACI_NAME_POINT to GIH_READ  ;                                           
grant SELECT on LANDS.MAP_PLAC_NAME_POINT to GIH_READ  ;                                           
grant SELECT on LANDS.PLACENAME to GIH_READ  ;                                                     
grant SELECT on LANDS.PLACENAME_ANNO to GIH_READ  ;                                                
grant SELECT on LANDS.PODIUM_NAME to GIH_READ  ;                                                   
grant SELECT on LANDS.RESUMLOT_LUT to GIH_READ  ;                                                  
grant SELECT on LANDS.RESUMNOTICE_LUT to GIH_READ  ;                                               
grant SELECT on LANDS.ROUTE_ARC to GIH_READ  ;                                                     
grant SELECT on LANDS.ROUTE_POINT to GIH_READ  ;                                                   
grant SELECT on LANDS.S1 to GIH_READ  ;                                                            
grant SELECT on LANDS.S100 to GIH_READ  ;                                                          
grant SELECT on LANDS.S101 to GIH_READ  ;                                                          
grant SELECT on LANDS.S102 to GIH_READ  ;                                                          
grant SELECT on LANDS.S103 to GIH_READ  ;                                                          
grant SELECT on LANDS.S104 to GIH_READ  ;                                                          
grant SELECT on LANDS.S105 to GIH_READ  ;                                                          
grant SELECT on LANDS.S106 to GIH_READ  ;                                                          
grant SELECT on LANDS.S107 to GIH_READ  ;                                                          
grant SELECT on LANDS.S108 to GIH_READ  ;                                                          
grant SELECT on LANDS.S109 to GIH_READ  ;                                                          
grant SELECT on LANDS.S11 to GIH_READ  ;                                                           
grant SELECT on LANDS.S110 to GIH_READ  ;                                                          
grant SELECT on LANDS.S111 to GIH_READ  ;                                                          
grant SELECT on LANDS.S112 to GIH_READ  ;                                                          
grant SELECT on LANDS.S113 to GIH_READ  ;                                                          
grant SELECT on LANDS.S114 to GIH_READ  ;                                                          
grant SELECT on LANDS.S115 to GIH_READ  ;                                                          
grant SELECT on LANDS.S116 to GIH_READ  ;                                                          
grant SELECT on LANDS.S117 to GIH_READ  ;                                                          
grant SELECT on LANDS.S118 to GIH_READ  ;                                                          
grant SELECT on LANDS.S119 to GIH_READ  ;                                                          
grant SELECT on LANDS.S12 to GIH_READ  ;                                                           
grant SELECT on LANDS.S120 to GIH_READ  ;                                                          
grant SELECT on LANDS.S121 to GIH_READ  ;                                                          
grant SELECT on LANDS.S122 to GIH_READ  ;                                                          
grant SELECT on LANDS.S123 to GIH_READ  ;                                                          
grant SELECT on LANDS.S124 to GIH_READ  ;                                                          
grant SELECT on LANDS.S125 to GIH_READ  ;                                                          
grant SELECT on LANDS.S126 to GIH_READ  ;                                                          
grant SELECT on LANDS.S127 to GIH_READ  ;                                                          
grant SELECT on LANDS.S128 to GIH_READ  ;                                                          
grant SELECT on LANDS.S129 to GIH_READ  ;                                                          
grant SELECT on LANDS.S13 to GIH_READ  ;                                                           
grant SELECT on LANDS.S130 to GIH_READ  ;                                                          
grant SELECT on LANDS.S131 to GIH_READ  ;                                                          
grant SELECT on LANDS.S132 to GIH_READ  ;                                                          
grant SELECT on LANDS.S133 to GIH_READ  ;                                                          
grant SELECT on LANDS.S134 to GIH_READ  ;                                                          
grant SELECT on LANDS.S135 to GIH_READ  ;                                                          
grant SELECT on LANDS.S136 to GIH_READ  ;                                                          
grant SELECT on LANDS.S137 to GIH_READ  ;                                                          
grant SELECT on LANDS.S138 to GIH_READ  ;                                                          
grant SELECT on LANDS.S139 to GIH_READ  ;                                                          
grant SELECT on LANDS.S14 to GIH_READ  ;                                                           
grant SELECT on LANDS.S140 to GIH_READ  ;                                                          
grant SELECT on LANDS.S141 to GIH_READ  ;                                                          
grant SELECT on LANDS.S142 to GIH_READ  ;                                                          
grant SELECT on LANDS.S143 to GIH_READ  ;                                                          
grant SELECT on LANDS.S144 to GIH_READ  ;                                                          
grant SELECT on LANDS.S145 to GIH_READ  ;                                                          
grant SELECT on LANDS.S146 to GIH_READ  ;                                                          
grant SELECT on LANDS.S147 to GIH_READ  ;                                                          
grant SELECT on LANDS.S148 to GIH_READ  ;                                                          
grant SELECT on LANDS.S149 to GIH_READ  ;                                                          
grant SELECT on LANDS.S15 to GIH_READ  ;                                                           
grant SELECT on LANDS.S150 to GIH_READ  ;                                                          
grant SELECT on LANDS.S151 to GIH_READ  ;                                                          
grant SELECT on LANDS.S152 to GIH_READ  ;                                                          
grant SELECT on LANDS.S153 to GIH_READ  ;                                                          
grant SELECT on LANDS.S154 to GIH_READ  ;                                                          
grant SELECT on LANDS.S155 to GIH_READ  ;                                                          
grant SELECT on LANDS.S156 to GIH_READ  ;                                                          
grant SELECT on LANDS.S157 to GIH_READ  ;                                                          
grant SELECT on LANDS.S158 to GIH_READ  ;                                                          
grant SELECT on LANDS.S159 to GIH_READ  ;                                                          
grant SELECT on LANDS.S16 to GIH_READ  ;                                                           
grant SELECT on LANDS.S160 to GIH_READ  ;                                                          
grant SELECT on LANDS.S161 to GIH_READ  ;                                                          
grant SELECT on LANDS.S162 to GIH_READ  ;                                                          
grant SELECT on LANDS.S163 to GIH_READ  ;                                                          
grant SELECT on LANDS.S164 to GIH_READ  ;                                                          
grant SELECT on LANDS.S165 to GIH_READ  ;                                                          
grant SELECT on LANDS.S166 to GIH_READ  ;                                                          
grant SELECT on LANDS.S167 to GIH_READ  ;                                                          
grant SELECT on LANDS.S168 to GIH_READ  ;                                                          
grant SELECT on LANDS.S169 to GIH_READ  ;                                                          
grant SELECT on LANDS.S17 to GIH_READ  ;                                                           
grant SELECT on LANDS.S170 to GIH_READ  ;                                                          
grant SELECT on LANDS.S171 to GIH_READ  ;                                                          
grant SELECT on LANDS.S172 to GIH_READ  ;                                                          
grant SELECT on LANDS.S173 to GIH_READ  ;                                                          
grant SELECT on LANDS.S174 to GIH_READ  ;                                                          
grant SELECT on LANDS.S175 to GIH_READ  ;                                                          
grant SELECT on LANDS.S176 to GIH_READ  ;                                                          
grant SELECT on LANDS.S177 to GIH_READ  ;                                                          
grant SELECT on LANDS.S178 to GIH_READ  ;                                                          
grant SELECT on LANDS.S179 to GIH_READ  ;                                                          
grant SELECT on LANDS.S18 to GIH_READ  ;                                                           
grant SELECT on LANDS.S180 to GIH_READ  ;                                                          
grant SELECT on LANDS.S181 to GIH_READ  ;                                                          
grant SELECT on LANDS.S182 to GIH_READ  ;                                                          
grant SELECT on LANDS.S183 to GIH_READ  ;                                                          
grant SELECT on LANDS.S184 to GIH_READ  ;                                                          
grant SELECT on LANDS.S185 to GIH_READ  ;                                                          
grant SELECT on LANDS.S186 to GIH_READ  ;                                                          
grant SELECT on LANDS.S187 to GIH_READ  ;                                                          
grant SELECT on LANDS.S188 to GIH_READ  ;                                                          
grant SELECT on LANDS.S189 to GIH_READ  ;                                                          
grant SELECT on LANDS.S19 to GIH_READ  ;                                                           
grant SELECT on LANDS.S190 to GIH_READ  ;                                                          
grant SELECT on LANDS.S191 to GIH_READ  ;                                                          
grant SELECT on LANDS.S192 to GIH_READ  ;                                                          
grant SELECT on LANDS.S193 to GIH_READ  ;                                                          
grant SELECT on LANDS.S194 to GIH_READ  ;                                                          
grant SELECT on LANDS.S195 to GIH_READ  ;                                                          
grant SELECT on LANDS.S196 to GIH_READ  ;                                                          
grant SELECT on LANDS.S197 to GIH_READ  ;                                                          
grant SELECT on LANDS.S198 to GIH_READ  ;                                                          
grant SELECT on LANDS.S199 to GIH_READ  ;                                                          
grant SELECT on LANDS.S2 to GIH_READ  ;                                                            
grant SELECT on LANDS.S20 to GIH_READ  ;                                                           
grant SELECT on LANDS.S200 to GIH_READ  ;                                                          
grant SELECT on LANDS.S201 to GIH_READ  ;                                                          
grant SELECT on LANDS.S202 to GIH_READ  ;                                                          
grant SELECT on LANDS.S203 to GIH_READ  ;                                                          
grant SELECT on LANDS.S204 to GIH_READ  ;                                                          
grant SELECT on LANDS.S205 to GIH_READ  ;                                                          
grant SELECT on LANDS.S206 to GIH_READ  ;                                                          
grant SELECT on LANDS.S207 to GIH_READ  ;                                                          
grant SELECT on LANDS.S208 to GIH_READ  ;                                                          
grant SELECT on LANDS.S209 to GIH_READ  ;                                                          
grant SELECT on LANDS.S21 to GIH_READ  ;                                                           
grant SELECT on LANDS.S210 to GIH_READ  ;                                                          
grant SELECT on LANDS.S211 to GIH_READ  ;                                                          
grant SELECT on LANDS.S212 to GIH_READ  ;                                                          
grant SELECT on LANDS.S213 to GIH_READ  ;                                                          
grant SELECT on LANDS.S214 to GIH_READ  ;                                                          
grant SELECT on LANDS.S215 to GIH_READ  ;                                                          
grant SELECT on LANDS.S216 to GIH_READ  ;                                                          
grant SELECT on LANDS.S217 to GIH_READ  ;                                                          
grant SELECT on LANDS.S218 to GIH_READ  ;                                                          
grant SELECT on LANDS.S219 to GIH_READ  ;                                                          
grant SELECT on LANDS.S22 to GIH_READ  ;                                                           
grant SELECT on LANDS.S220 to GIH_READ  ;                                                          
grant SELECT on LANDS.S221 to GIH_READ  ;                                                          
grant SELECT on LANDS.S222 to GIH_READ  ;                                                          
grant SELECT on LANDS.S223 to GIH_READ  ;                                                          
grant SELECT on LANDS.S224 to GIH_READ  ;                                                          
grant SELECT on LANDS.S225 to GIH_READ  ;                                                          
grant SELECT on LANDS.S226 to GIH_READ  ;                                                          
grant SELECT on LANDS.S227 to GIH_READ  ;                                                          
grant SELECT on LANDS.S228 to GIH_READ  ;                                                          
grant SELECT on LANDS.S229 to GIH_READ  ;                                                          
grant SELECT on LANDS.S23 to GIH_READ  ;                                                           
grant SELECT on LANDS.S230 to GIH_READ  ;                                                          
grant SELECT on LANDS.S231 to GIH_READ  ;                                                          
grant SELECT on LANDS.S232 to GIH_READ  ;                                                          
grant SELECT on LANDS.S233 to GIH_READ  ;                                                          
grant SELECT on LANDS.S234 to GIH_READ  ;                                                          
grant SELECT on LANDS.S235 to GIH_READ  ;                                                          
grant SELECT on LANDS.S236 to GIH_READ  ;                                                          
grant SELECT on LANDS.S237 to GIH_READ  ;                                                          
grant SELECT on LANDS.S238 to GIH_READ  ;                                                          
grant SELECT on LANDS.S239 to GIH_READ  ;                                                          
grant SELECT on LANDS.S24 to GIH_READ  ;                                                           
grant SELECT on LANDS.S240 to GIH_READ  ;                                                          
grant SELECT on LANDS.S241 to GIH_READ  ;                                                          
grant SELECT on LANDS.S242 to GIH_READ  ;                                                          
grant SELECT on LANDS.S243 to GIH_READ  ;                                                          
grant SELECT on LANDS.S244 to GIH_READ  ;                                                          
grant SELECT on LANDS.S245 to GIH_READ  ;                                                          
grant SELECT on LANDS.S246 to GIH_READ  ;                                                          
grant SELECT on LANDS.S247 to GIH_READ  ;                                                          
grant SELECT on LANDS.S248 to GIH_READ  ;                                                          
grant SELECT on LANDS.S249 to GIH_READ  ;                                                          
grant SELECT on LANDS.S250 to GIH_READ  ;                                                          
grant SELECT on LANDS.S251 to GIH_READ  ;                                                          
grant SELECT on LANDS.S252 to GIH_READ  ;                                                          
grant SELECT on LANDS.S253 to GIH_READ  ;                                                          
grant SELECT on LANDS.S254 to GIH_READ  ;                                                          
grant SELECT on LANDS.S255 to GIH_READ  ;                                                          
grant SELECT on LANDS.S256 to GIH_READ  ;                                                          

grant SELECT on LANDS.S257 to GIH_READ  ;                                                          
grant SELECT on LANDS.S258 to GIH_READ  ;                                                          
grant SELECT on LANDS.S259 to GIH_READ  ;                                                          
grant SELECT on LANDS.S26 to GIH_READ  ;                                                           
grant SELECT on LANDS.S260 to GIH_READ  ;                                                          
grant SELECT on LANDS.S261 to GIH_READ  ;                                                          
grant SELECT on LANDS.S262 to GIH_READ  ;                                                          
grant SELECT on LANDS.S263 to GIH_READ  ;                                                          
grant SELECT on LANDS.S264 to GIH_READ  ;                                                          
grant SELECT on LANDS.S265 to GIH_READ  ;                                                          
grant SELECT on LANDS.S266 to GIH_READ  ;                                                          
grant SELECT on LANDS.S27 to GIH_READ  ;                                                           
grant SELECT on LANDS.S275 to GIH_READ  ;                                                          
grant SELECT on LANDS.S276 to GIH_READ  ;                                                          
grant SELECT on LANDS.S277 to GIH_READ  ;                                                          
grant SELECT on LANDS.S28 to GIH_READ  ;                                                           
grant SELECT on LANDS.S280 to GIH_READ  ;                                                          
grant SELECT on LANDS.S281 to GIH_READ  ;                                                          
grant SELECT on LANDS.S282 to GIH_READ  ;                                                          
grant SELECT on LANDS.S283 to GIH_READ  ;                                                          
grant SELECT on LANDS.S284 to GIH_READ  ;                                                          
grant SELECT on LANDS.S285 to GIH_READ  ;                                                          
grant SELECT on LANDS.S286 to GIH_READ  ;                                                          
grant SELECT on LANDS.S29 to GIH_READ  ;                                                           
grant SELECT on LANDS.S30 to GIH_READ  ;                                                           
grant SELECT on LANDS.S31 to GIH_READ  ;                                                           
grant SELECT on LANDS.S32 to GIH_READ  ;                                                           
grant SELECT on LANDS.S33 to GIH_READ  ;                                                           
grant SELECT on LANDS.S34 to GIH_READ  ;                                                           
grant SELECT on LANDS.S35 to GIH_READ  ;                                                           
grant SELECT on LANDS.S36 to GIH_READ  ;                                                           
grant SELECT on LANDS.S37 to GIH_READ  ;                                                           
grant SELECT on LANDS.S38 to GIH_READ  ;                                                           
grant SELECT on LANDS.S39 to GIH_READ  ;                                                           
grant SELECT on LANDS.S4 to GIH_READ  ;                                                            
grant SELECT on LANDS.S40 to GIH_READ  ;                                                           
grant SELECT on LANDS.S41 to GIH_READ  ;                                                           
grant SELECT on LANDS.S410 to GIH_READ  ;                                                          
grant SELECT on LANDS.S411 to GIH_READ  ;                                                          
grant SELECT on LANDS.S412 to GIH_READ  ;                                                          
grant SELECT on LANDS.S413 to GIH_READ  ;                                                          
grant SELECT on LANDS.S414 to GIH_READ  ;                                                          
grant SELECT on LANDS.S415 to GIH_READ  ;                                                          
grant SELECT on LANDS.S416 to GIH_READ  ;                                                          
grant SELECT on LANDS.S417 to GIH_READ  ;                                                          
grant SELECT on LANDS.S42 to GIH_READ  ;                                                           
grant SELECT on LANDS.S425 to GIH_READ  ;                                                          
grant SELECT on LANDS.S426 to GIH_READ  ;                                                          
grant SELECT on LANDS.S427 to GIH_READ  ;                                                          
grant SELECT on LANDS.S428 to GIH_READ  ;                                                          
grant SELECT on LANDS.S43 to GIH_READ  ;                                                           
grant SELECT on LANDS.S432 to GIH_READ  ;                                                          
grant SELECT on LANDS.S435 to GIH_READ  ;                                                          
grant SELECT on LANDS.S437 to GIH_READ  ;                                                          
grant SELECT on LANDS.S438 to GIH_READ  ;                                                          
grant SELECT on LANDS.S439 to GIH_READ  ;                                                          
grant SELECT on LANDS.S44 to GIH_READ  ;                                                           
grant SELECT on LANDS.S441 to GIH_READ  ;                                                          
grant SELECT on LANDS.S442 to GIH_READ  ;                                                          
grant SELECT on LANDS.S45 to GIH_READ  ;                                                           
grant SELECT on LANDS.S46 to GIH_READ  ;                                                           
grant SELECT on LANDS.S47 to GIH_READ  ;                                                           
grant SELECT on LANDS.S48 to GIH_READ  ;                                                           
grant SELECT on LANDS.S49 to GIH_READ  ;                                                           
grant SELECT on LANDS.S5 to GIH_READ  ;                                                            
grant SELECT on LANDS.S50 to GIH_READ  ;                                                           
grant SELECT on LANDS.S508 to GIH_READ  ;                                                          
grant SELECT on LANDS.S509 to GIH_READ  ;                                                          
grant SELECT on LANDS.S51 to GIH_READ  ;                                                           
grant SELECT on LANDS.S510 to GIH_READ  ;                                                          
grant SELECT on LANDS.S511 to GIH_READ  ;                                                          
grant SELECT on LANDS.S52 to GIH_READ  ;                                                           
grant SELECT on LANDS.S53 to GIH_READ  ;                                                           
grant SELECT on LANDS.S54 to GIH_READ  ;                                                           
grant SELECT on LANDS.S549 to GIH_READ  ;                                                          
grant SELECT on LANDS.S55 to GIH_READ  ;                                                           
grant SELECT on LANDS.S59 to GIH_READ  ;                                                           
grant SELECT on LANDS.S6 to GIH_READ  ;                                                            
grant SELECT on LANDS.S60 to GIH_READ  ;                                                           
grant SELECT on LANDS.S61 to GIH_READ  ;                                                           
grant SELECT on LANDS.S62 to GIH_READ  ;                                                           
grant SELECT on LANDS.S63 to GIH_READ  ;                                                           
grant SELECT on LANDS.S64 to GIH_READ  ;                                                           
grant SELECT on LANDS.S65 to GIH_READ  ;                                                           
grant SELECT on LANDS.S66 to GIH_READ  ;                                                           
grant SELECT on LANDS.S67 to GIH_READ  ;                                                           
grant SELECT on LANDS.S68 to GIH_READ  ;                                                           
grant SELECT on LANDS.S69 to GIH_READ  ;                                                           
grant SELECT on LANDS.S7 to GIH_READ  ;                                                            
grant SELECT on LANDS.S70 to GIH_READ  ;                                                           
grant SELECT on LANDS.S71 to GIH_READ  ;                                                           
grant SELECT on LANDS.S72 to GIH_READ  ;                                                           
grant SELECT on LANDS.S73 to GIH_READ  ;                                                           
grant SELECT on LANDS.S74 to GIH_READ  ;                                                           
grant SELECT on LANDS.S75 to GIH_READ  ;                                                           
grant SELECT on LANDS.S79 to GIH_READ  ;                                                           
grant SELECT on LANDS.S8 to GIH_READ  ;                                                            
grant SELECT on LANDS.S80 to GIH_READ  ;                                                           
grant SELECT on LANDS.S81 to GIH_READ  ;                                                           
grant SELECT on LANDS.S82 to GIH_READ  ;                                                           
grant SELECT on LANDS.S83 to GIH_READ  ;                                                           
grant SELECT on LANDS.S84 to GIH_READ  ;                                                           
grant SELECT on LANDS.S85 to GIH_READ  ;                                                           
grant SELECT on LANDS.S86 to GIH_READ  ;                                                           
grant SELECT on LANDS.S87 to GIH_READ  ;                                                           
grant SELECT on LANDS.S88 to GIH_READ  ;                                                           
grant SELECT on LANDS.S89 to GIH_READ  ;                                                           
grant SELECT on LANDS.S9 to GIH_READ  ;                                                            
grant SELECT on LANDS.S90 to GIH_READ  ;                                                           
grant SELECT on LANDS.S91 to GIH_READ  ;                                                           
grant SELECT on LANDS.S92 to GIH_READ  ;                                                           
grant SELECT on LANDS.S93 to GIH_READ  ;                                                           
grant SELECT on LANDS.S94 to GIH_READ  ;                                                           
grant SELECT on LANDS.S95 to GIH_READ  ;                                                           
grant SELECT on LANDS.S96 to GIH_READ  ;                                                           
grant SELECT on LANDS.S97 to GIH_READ  ;                                                           
grant SELECT on LANDS.S98 to GIH_READ  ;                                                           
grant SELECT on LANDS.S99 to GIH_READ  ;                                                           
grant SELECT on LANDS.SITE to GIH_READ  ;                                                          
grant SELECT on LANDS.SITE_NAME to GIH_READ  ;                                                     
grant SELECT on LANDS.SITE_PLU to GIH_READ  ;                                                      
grant SELECT on LANDS.STATUS_LUT to GIH_READ  ;                                                    
grant SELECT on LANDS.STREET to GIH_READ  ;                                                        
grant SELECT on LANDS.STREETINT to GIH_READ  ;                                                     
grant SELECT on LANDS.STREET_CODE to GIH_READ  ;                                                   
grant SELECT on LANDS.STREET_INT to GIH_READ  ;                                                    
grant SELECT on LANDS.TILE to GIH_READ  ;                                                          
grant SELECT on LANDS.TRAIL_ARC to GIH_READ  ;                                                     
grant SELECT on LANDS.UTILPT to GIH_READ  ;                                                        
grant SELECT on LANDS.UTILPT_LUT to GIH_READ  ;                                                    
grant SELECT on LANDS.UTILPT_PLU to GIH_READ  ;                                                    
grant SELECT on LANDS.UTMGRID_POLY to GIH_READ  ;                                                  
grant SELECT on LNDGS054.F515 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.F516 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.F517 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.F518 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.GIH3_CYCLING_TRACK_POLY to GIH_READ  ;                                    
grant SELECT on LNDGS054.GIH3_GEOPARK_POLY to GIH_READ  ;                                          
grant SELECT on LNDGS054.GIH3_HTRAIL_ARC to GIH_READ  ;                                            
grant SELECT on LNDGS054.GIH3_MOUNTAIN_BIKE_ARC to GIH_READ  ;                                     
grant SELECT on LNDGS054.S515 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.S516 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.S517 to GIH_READ  ;                                                       
grant SELECT on LNDGS054.S518 to GIH_READ  ;                                                       
grant UPDATE on ADM.CODE to GIH_READ  ;                                                            
grant UPDATE on ADM.CODE2 to GIH_READ  ;                                                           
grant UPDATE on ADM.DEPT to GIH_READ  ;                                                            
grant UPDATE on ADM.DOWNLOADRECORDS to GIH_READ  ;                                                 
grant UPDATE on ADM.LASTUPDATE to GIH_READ  ;                                                      
grant UPDATE on ADM.LOGINRECORDS to GIH_READ  ;                                                    
grant UPDATE on ADM.USER_CODE to GIH_READ  ;                                                       
grant UPDATE on ADM.USER_INFO to GIH_READ  ;                                                       
grant UPDATE on ADM.USER_POSTING to GIH_READ  ;                                                    
SQL> @tsp1

Session altered.


Session altered.


                              Allocated          Used          Free            No. of     Largest  
Tablespace Name      Auto        MBytes        MBytes        MBytes Used %% Free Exts   Exts (KB)  
-------------------- ---- ------------- ------------- ------------- ------- --------- -----------  
   Smallest  Nxt Reqd                                                                              
  Exts (KB) Exts (KB)                                                                              
----------- ---------                                                                              
ACCMGR               NO          200.00           .50        199.50     .25         1     204,288  
    204,288         0                                                                              
                                                                                                   
ADM                  NO        1,200.00        901.50        298.50   75.13        30      62,976  
        512       512                                                                              
                                                                                                   
APIX                 NO        4,096.00        772.00      3,324.00   18.85       206     986,624  
        512       512                                                                              
                                                                                                   
CENSUS               NO          200.00        107.50         92.50   53.75         1      94,720  
     94,720       512                                                                              
                                                                                                   
LANDS                NO       16,384.00     11,723.00      4,661.00   71.55       402     733,184  
        512       512                                                                              
                                                                                                   
SDE                  NO          200.00         41.69        158.31   20.84         2     161,728  
        384         0                                                                              
                                                                                                   
SYSAUX               YES         450.00        444.38          5.63   98.75         7       4,032  
         64         0                                                                              
                                                                                                   
SYSTEM               YES         550.00        545.88          4.13   99.25         2       4,032  
        192     1,024                                                                              
                                                                                                   
TEMP                 YES       1,024.00      1,024.00           .00  100.00                        
                    0                                                                              
                                                                                                   
UNDOTBS1             YES       1,425.00         16.00      1,409.00    1.12        14   1,393,600  
         64        64                                                                              
                                                                                                   
USERS                NO          100.00          6.50         93.50    6.50         1      95,744  
     95,744       512                                                                              
                                                                                                   
                          ------------- ------------- -------------                                
                                                                                                   
                                                                                                   
sum                           25,829.00     15,582.94     10,246.06                                
                                                                                                   
                                                                                                   

11 rows selected.

SQL> @gen_cr_tblsp
CREATE TABLESPACE ACCMGR                                                                           
DATAFILE 'D:\ORADATA\GDAT3042\ACCMGR01.DBF' SIZE 209715200 REUSE                                   
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 524288                                                                                
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE ADM                                                                              
DATAFILE 'D:\ORADATA\GDAT3042\ADM01.DBF' SIZE 209715200 REUSE                                      
, 'D:\ORADATA\GDAT3042\ADM02.DBF' SIZE 209715200 REUSE                                             
, 'D:\ORADATA\GDAT3042\ADM03.DBF' SIZE 209715200 REUSE                                             
, 'D:\ORADATA\GDAT3042\ADM04.DBF' SIZE 209715200 REUSE                                             
, 'D:\ORADATA\GDAT3042\ADM05.DBF' SIZE 209715200 REUSE                                             
, 'D:\ORADATA\GDAT3042\ADM06.DBF' SIZE 209715200 REUSE                                             
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 524288                                                                                
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE APIX                                                                             
DATAFILE 'D:\ORADATA\GDAT3042\APIX01.DBF' SIZE 2147483648 REUSE                                    
, 'D:\ORADATA\GDAT3042\APIX02.DBF' SIZE 2147483648 REUSE                                           
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 524288                                                                                
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE CENSUS                                                                           
DATAFILE 'D:\ORADATA\GDAT3042\CENSUS01.DBF' SIZE 209715200 REUSE                                   
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 524288                                                                                
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE LANDS                                                                            
DATAFILE 'D:\ORADATA\GDAT3042\LANDS01.DBF' SIZE 2147483648 REUSE                                   
, 'D:\ORADATA\GDAT3042\LANDS02.DBF' SIZE 2147483648 REUSE                                          
, 'D:\ORADATA\GDAT3042\LANDS03.DBF' SIZE 2147483648 REUSE                                          
, 'D:\ORADATA\GDAT3042\LANDS04.DBF' SIZE 2147483648 REUSE                                          
, 'D:\ORADATA\GDAT3042\LANDS05.DBF' SIZE 2147483648 REUSE                                          
, 'D:\ORADATA\GDAT3042\LANDS06.DBF' SIZE 2147483648 REUSE                                          
, 'D:\ORADATA\GDAT3042\LANDS07.DBF' SIZE 2147483648 REUSE                                          
, 'D:\ORADATA\GDAT3042\LANDS08.DBF' SIZE 2147483648 REUSE                                          
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 524288                                                                                
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE SDE                                                                              
DATAFILE 'D:\ORADATA\GDAT3042\SDE01.DBF' SIZE 209715200 REUSE                                      
EXTENT MANAGEMENT LOCAL                                                                            
AUTOALLOCATE                                                                                       
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE SYSAUX                                                                           
DATAFILE 'D:\ORADATA\GDAT3042\SYSAUX01.DBF' SIZE 471859200 REUSE                                   
AUTOEXTEND ON NEXT 1280                                                                            
MAXSIZE 34359721984                                                                                
EXTENT MANAGEMENT LOCAL                                                                            
AUTOALLOCATE                                                                                       
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE TEMP                                                                             
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 1048576                                                                               
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE UNDOTBS1                                                                         
DATAFILE 'D:\ORADATA\GDAT3042\UNDOTBS01.DBF' SIZE 1494220800 REUSE                                 
AUTOEXTEND ON NEXT 640                                                                             
MAXSIZE 34359721984                                                                                
EXTENT MANAGEMENT LOCAL                                                                            
AUTOALLOCATE                                                                                       
ONLINE;                                                                                            
--                                                                                                 
CREATE TABLESPACE USERS                                                                            
DATAFILE 'D:\ORADATA\GDAT3042\USERS01.DBF' SIZE 104857600 REUSE                                    
EXTENT MANAGEMENT LOCAL                                                                            
UNIFORM SIZE 524288                                                                                
ONLINE;                                                                                            
--                                                                                                 

PL/SQL procedure successfully completed.


File                                                                                               
Name                                             FILE_ID Tablespace Name           BYTES     BLOCKS
--------------------------------------------- ---------- -------------------- ---------- ----------
STATUS    RELATIVE_FNO Auto   MAXBYTES  MAXBLOCKS INCREMENT_BY USER_BYTES USER_BLOCKS ONLINE_      
--------- ------------ ---- ---------- ---------- ------------ ---------- ----------- -------      
D:\ORADATA\GDAT3042\SYSTEM01.DBF                       1 SYSTEM                576716800      70400
AVAILABLE            1 YES  3.4360E+10    4194302         1280  576651264       70392 SYSTEM       
                                                                                                   
D:\ORADATA\GDAT3042\UNDOTBS01.DBF                      2 UNDOTBS1             1494220800     182400
AVAILABLE            2 YES  3.4360E+10    4194302          640 1494155264      182392 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\SYSAUX01.DBF                       3 SYSAUX                471859200      57600
AVAILABLE            3 YES  3.4360E+10    4194302         1280  471793664       57592 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\SDE01.DBF                          4 SDE                   209715200      25600
AVAILABLE            4 NO            0          0            0  209649664       25592 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ADM01.DBF                          5 ADM                   209715200      25600
AVAILABLE            5 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ADM02.DBF                          6 ADM                   209715200      25600
AVAILABLE            6 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ACCMGR01.DBF                       7 ACCMGR                209715200      25600
AVAILABLE            7 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS01.DBF                        8 LANDS                2147483648     262144
AVAILABLE            8 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS02.DBF                        9 LANDS                2147483648     262144
AVAILABLE            9 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS03.DBF                       10 LANDS                2147483648     262144
AVAILABLE           10 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS04.DBF                       11 LANDS                2147483648     262144
AVAILABLE           11 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS05.DBF                       12 LANDS                2147483648     262144
AVAILABLE           12 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS06.DBF                       13 LANDS                2147483648     262144
AVAILABLE           13 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS07.DBF                       14 LANDS                2147483648     262144
AVAILABLE           14 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\LANDS08.DBF                       15 LANDS                2147483648     262144
AVAILABLE           15 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\APIX01.DBF                        16 APIX                 2147483648     262144
AVAILABLE           16 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\APIX02.DBF                        17 APIX                 2147483648     262144
AVAILABLE           17 NO            0          0            0 2146959360      262080 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\CENSUS01.DBF                      18 CENSUS                209715200      25600
AVAILABLE           18 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\USERS01.DBF                       19 USERS                 104857600      12800
AVAILABLE           19 NO            0          0            0  104333312       12736 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ADM03.DBF                         20 ADM                   209715200      25600
AVAILABLE           20 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ADM04.DBF                         21 ADM                   209715200      25600
AVAILABLE           21 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ADM05.DBF                         22 ADM                   209715200      25600
AVAILABLE           22 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   
D:\ORADATA\GDAT3042\ADM06.DBF                         23 ADM                   209715200      25600
AVAILABLE           23 NO            0          0            0  209190912       25536 ONLINE       
                                                                                                   

23 rows selected.


File                                                                                               
Name                                             FILE_ID Tablespace Name           BYTES     BLOCKS
--------------------------------------------- ---------- -------------------- ---------- ----------
STATUS    RELATIVE_FNO Auto   MAXBYTES  MAXBLOCKS INCREMENT_BY USER_BYTES USER_BLOCKS              
--------- ------------ ---- ---------- ---------- ------------ ---------- -----------              
D:\ORADATA\GDAT3042\TEMP02.DBF                         2 TEMP                 1073741824     131072
AVAILABLE            2 YES  3.4360E+10    4194302        65536 1072693248      130944              
                                                                                                   

1 row selected.



SQL> @registry

Session altered.


Session altered.

=========================================================================================================================================================
Show components loaded into the database

COMP_ID    COMP_NAME                                VERSION    STATUS     MODIFIED     SCHEMA                                                                                               
---------- ---------------------------------------- ---------- ---------- ------------ ---------------                                                                                      
CONTEXT    Oracle Text                              10.2.0.4.0 VALID      27-AUG-2012  CTXSYS                                                                                               
SDO        Spatial                                  10.2.0.4.0 VALID      12-JUL-2010  MDSYS                                                                                                
EM         Oracle Enterprise Manager                10.2.0.4.0 VALID      09-JUL-2010  SYSMAN                                                                                               
ORDIM      Oracle interMedia                        10.2.0.4.0 VALID      12-JUL-2010  ORDSYS                                                                                               
XDB        Oracle XML Database                      10.2.0.4.0 VALID      12-JUL-2010  XDB                                                                                                  
EXF        Oracle Expression Filter                 10.2.0.4.0 VALID      12-JUL-2010  EXFSYS                                                                                               
RUL        Oracle Rule Manager                      10.2.0.4.0 VALID      12-JUL-2010  EXFSYS                                                                                               
OWM        Oracle Workspace Manager                 10.2.0.4.3 VALID      12-JUL-2010  WMSYS                                                                                                
CATALOG    Oracle Database Catalog Views            10.2.0.4.0 VALID      12-JUL-2010  SYS                                                                                                  
CATPROC    Oracle Database Packages and Types       10.2.0.4.0 VALID      12-JUL-2010  SYS                                                                                                  
JAVAVM     JServer JAVA Virtual Machine             10.2.0.4.0 VALID      12-JUL-2010  SYS                                                                                                  
XML        Oracle XDK                               10.2.0.4.0 VALID      12-JUL-2010  SYS                                                                                                  
CATJAVA    Oracle Database Java Packages            10.2.0.4.0 VALID      12-JUL-2010  SYS                                                                                                  

13 rows selected.

=========================================================================================================================================================
Show information about upgrade, downgrade and critical patch updates applied to the database

ACTION_TIME                         ACTION          VERSION            ID COMMENTS                                                                                                          
----------------------------------- --------------- ---------- ---------- --------------------------------------------------                                                                
12-JUL-10 02.01.03.093000 PM        CPU                           6452863 view recompilation                                                                                                
17-JAN-08 04.07.56.328000 PM        CPU             10.2.0.3.0    6430171 CPUOct2007                                                                                                        
09-JUL-10 04.22.29.984000 PM        UPGRADE         10.2.0.4.0            Upgraded from 10.2.0.3.0                                                                                          
12-JUL-10 01.52.23.500000 PM        APPLY           10.2.0.4           34 Patch 34                                                                                                          

4 rows selected.

SQL> @db

Connect: SYSTEM \ gdat3042 \ GDAT3052 \ 10.2.0.4.0                                                                                                                                                      
Uptime : 0days 0hours 0minutes                                                                                                                                                                          
                                                                                                                                                                                                        
                                                                                                                                                                                                        

      DBID NAME                 CREATED    STATUS     LOGINS     LOG_MODE     ARCHIVE                                                                                                                   
---------- -------------------- ---------- ---------- ---------- ------------ -------                                                                                                                   
1136406031 GDAT3042             25-05-2007 OPEN       ALLOWED    ARCHIVELOG   STARTED                                                                                                                   

NAME_COL_PLUS_SHOW_PARAM                                                         TYPE                                                                                                                   
-------------------------------------------------------------------------------- -----------                                                                                                            
VALUE_COL_PLUS_SHOW_PARAM                                                                                                                                                                               
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
db_block_size                                                                    integer                                                                                                                
8192                                                                                                                                                                                                    

CONTROLFIL CONTROLFIL OPEN_RESETL RESETLOGS_CHANGE# RESETLOGS_                                                                                                                                          
---------- ---------- ----------- ----------------- ----------                                                                                                                                          
25-05-2007 08-11-2012 NOT ALLOWED         272517425 27-08-2012                                                                                                                                          

VERSION_TI OPEN_MODE  REMOTE_A                                                                                                                                                                          
---------- ---------- --------                                                                                                                                                                          
27-08-2012 READ WRITE ENABLED                                                                                                                                                                           

DATABASE_ROLE    ARCHIVEL FOR                                                                                                                                                                           
---------------- -------- ---                                                                                                                                                                           
PRIMARY          DISABLED NO                                                                                                                                                                            

PLATFORM_ID PLATFORM_NAME                                      CURRENT_SCN FLASHBACK_ON                                                                                                                 
----------- -------------------------------------------------- ----------- ------------------                                                                                                           
         12 Microsoft Windows x86 64-bit                         279877935 NO                                                                                                                           

Database NLS parameters ....

PARAMETER                      VALUE                                                                                                                                                                    
------------------------------ ------------------------------                                                                                                                                           
NLS_CHARACTERSET               AL32UTF8                                                                                                                                                                 
NLS_DATE_FORMAT                DD-MON-RR                                                                                                                                                                
NLS_LANGUAGE                   TRADITIONAL CHINESE                                                                                                                                                      
NLS_NCHAR_CHARACTERSET         AL16UTF16                                                                                                                                                                
NLS_SORT                       BINARY                                                                                                                                                                   
NLS_TERRITORY                  HONG KONG                                                                                                                                                                
db_block_size                  8192                                                                                                                                                                     

Current NLS parameters ....

PARAMETER                                          VALUE                                                                                                                                                
-------------------------------------------------- --------------------------------------------------                                                                                                   
NLS_LANGUAGE                                       AMERICAN                                                                                                                                             
NLS_TERRITORY                                      AMERICA                                                                                                                                              
NLS_CURRENCY                                       $                                                                                                                                                    
NLS_ISO_CURRENCY                                   AMERICA                                                                                                                                              
NLS_NUMERIC_CHARACTERS                             .,                                                                                                                                                   
NLS_CALENDAR                                       GREGORIAN                                                                                                                                            
NLS_DATE_FORMAT                                    dd-mm-yyyy                                                                                                                                           
NLS_DATE_LANGUAGE                                  AMERICAN                                                                                                                                             
NLS_CHARACTERSET                                   AL32UTF8                                                                                                                                             
NLS_SORT                                           BINARY                                                                                                                                               
NLS_TIME_FORMAT                                    HH.MI.SSXFF AM                                                                                                                                       
NLS_TIMESTAMP_FORMAT                               DD-MON-RR HH.MI.SSXFF AM                                                                                                                             
NLS_TIME_TZ_FORMAT                                 HH.MI.SSXFF AM TZR                                                                                                                                   
NLS_TIMESTAMP_TZ_FORMAT                            DD-MON-RR HH.MI.SSXFF AM TZR                                                                                                                         
NLS_DUAL_CURRENCY                                  $                                                                                                                                                    
NLS_NCHAR_CHARACTERSET                             AL16UTF16                                                                                                                                            
NLS_COMP                                           BINARY                                                                                                                                               
NLS_LENGTH_SEMANTICS                               BYTE                                                                                                                                                 
NLS_NCHAR_CONV_EXCP                                FALSE                                                                                                                                                
SQL> spool off
