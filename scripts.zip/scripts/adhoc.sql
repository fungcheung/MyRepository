Note: Chk whether chained rows

@?\rdbms\admin\utlchain.sql

select 'ANALYZE TABLE ' ||
owner || '.' || object_name || ' LIST CHAINED ROWS INTO CHAINED_ROWS;' from dba_objects
where owner='SH' and object_type= 'TABLE';


Note: Chk whether corruption in table and its correspondents

select 'ANALYZE TABLE ' ||
owner || '.' || object_name || ' VALIDATE STRUCTURE CASCADE ONLINE;' from dba_objects
where owner='SH' and object_type= 'TABLE';



