#!/bin/sh

ORACLE_SID=XBOS ; export ORACLE_SID
ORACLE_HOME=/tpexbosdbp1/export/oracle/product/9.2.0.4 ; export ORACLE_HOME
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle 
export PATH

date ; ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/export/XBOS_fullexp.dmp.Z

rm -f /tmp/orap_XBOS_exp
/etc/mknod /tmp/orap_XBOS_exp p
cat /tmp/orap_XBOS_exp | compress > /tpexbosdbp1/export/oracle/u004/XBOS/backup/export/fullexp_XBOS.dmp.Z  &
exp / file=/tmp/orap_XBOS_exp full=y compress=n consistent=y buffer=32107600 statistics=none \
log=/tpexbosdbp1/export/oracle/u004/XBOS/backup/export/fullexp_XBOS.log
rm -f /tmp/orap_XBOS_exp
date ; ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/export/fullexp_XBOS.dmp.Z
date ; ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/export/fullexp_XBOS.log

