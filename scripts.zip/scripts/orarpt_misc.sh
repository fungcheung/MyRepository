#!/bin/ksh
## Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_misc.sh
## Usage: ./orarpt_misc.sh  $SG  $ORACLE_HOME  $ORA_SID

SERVICE_GROUP=$1  ; export SERVICE_GROUP
ORACLE_HOME=$2    ; export ORACLE_HOME
ORACLE_SID=$3     ; export ORACLE_SID

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

$ORACLE_HOME/bin/sqlplus / <<EOF
@/$SERVICE_GROUP/export/oracle/dbasql/orarpt_misc.sql
EOF

exit 0

