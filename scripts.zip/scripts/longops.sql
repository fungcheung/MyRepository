Set heading on
set pagesize 1000
set linesize 1000

column Log_Time format A20
column SID         format 9999
column USERNAME    format a20
column OWNERID     format 999999999
column STATUS      format a10   
column OSUSER      format a30
column PROCESS     format a35
column MACHINE     format a30
column TERMINAL    format a30
column PROGRAM     format a30
column logon_time_str format a20
column uga_memory  format a12
column pga_memory  format a12

prompt ################################################################################################
prompt # Show long operations order by start time
prompt ################################################################################################


select sid, username,opname, sofar, totalwork,start_time,LAST_UPDATE_TIME,message from sys.v_$session_longops order by start_time;

prompt ################################################################################################
prompt # Show long operations in progress
prompt ################################################################################################

SET LINE 9999  PAGESIZE 9999
 COL USERNAME FORMAT A10 
 COL SESSION_INFO FORMAT A30
 COL TARGET FORMAT A20
 COL OPNAME FORMAT A35 
 COL MESSAGE FORMAT A80 
 COL SOFAR_TOTALWORK FORMAT A20 
 COL PROGRESS FORMAT A8
 
SELECT A.USERNAME, 
       (SELECT NB.PROCESS || ',' || NB.SID || ',' || NB.SERIAL# || ',' || PR.SPID || ',' ||NB.OSUSER|| ',' ||NB.STATUS|| ',' ||NB.EVENT
          FROM GV$PROCESS PR, GV$SESSION NB
         WHERE NB.PADDR = PR.ADDR
           AND NB.SID = A.SID
           AND NB.SERIAL# = A.SERIAL#
           AND PR.INST_ID = NB.INST_ID) SESSION_INFO,
       A.TARGET,
       A.OPNAME,
a.units,
       TO_CHAR(A.START_TIME, 'YYYY-MM-DD HH24:MI:SS') START_TIME,
       ROUND(A.SOFAR * 100 / A.TOTALWORK, 2) || '%' AS PROGRESS,
       (A.SOFAR || ':' || A.TOTALWORK) SOFAR_TOTALWORK,
       A.TIME_REMAINING TIME_REMAINING,
       A.ELAPSED_SECONDS ELAPSED_SECONDS, a.con_id,
       MESSAGE MESSAGE
  FROM GV$SESSION_LONGOPS A
 WHERE 
A.TIME_REMAINING <> 0
 ORDER BY  A.TIME_REMAINING DESC, A.SQL_ID, A.SID;



