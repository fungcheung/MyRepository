#!/bin/ksh
## Filename: orarpt_chkbkup.sh
## Usage: ./orarpt_chkbkup.sh

ORACLE_HOME=/data/oracle/product/9.2.0.4  
export ORACLE_HOME

TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN

ADMIN=samson.wk.cheung@db.com 
export ADMIN

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

/usr/bin/rm /home/oracle/dbasql/temp/*
echo '--------------------------------------------------------------------------------' > /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log

#ssh -n tpexbosdbp1 "ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 

if [ -f /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log ] ; then
    /usr/bin/cat /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log | /usr/bin/mailx -r hk-saroot@discard.mail.db.com  -s "Backup Report - `date '+%y%m%d'`" $ADMIN
fi

exit 0

