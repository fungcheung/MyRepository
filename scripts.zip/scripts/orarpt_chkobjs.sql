-- 
-- Filename: orarpt_chkobjs.sql
-- 

clear column
set lines 222 pages 999

alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ; 
select sysdate from dual ;

-- Check invalid objects

select
   decode( OBJECT_TYPE, 'PACKAGE BODY', 'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body ;',
                        'UNDEFINED', 'ALTER MATERIALIZED VIEW ' || OWNER||'.'||OBJECT_NAME || ' compile ;',
   'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile ;' )
 from dba_objects
where STATUS = 'INVALID'
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW', 'UNDEFINED')
order by OWNER, OBJECT_TYPE, OBJECT_NAME ;

exit

