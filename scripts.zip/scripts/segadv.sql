set linesize 200 pages 999

col task_name format a20
col segname format a15
col partition format a15
col type format a10
col message format a100

prompt =========================================================================================================================================================
prompt Segment Advisor
select task_name, execution_end, owner, status from dba_advisor_tasks
   where advisor_name = 'Segment Advisor';

prompt =========================================================================================================================================================
prompt Segment Advisor Findings. If no findings, no entries will be displayed.

select af.task_name, t.execution_start, ao.attr2 segname, ao.attr3 partition, ao.type, af.message 
  from dba_advisor_findings af, dba_advisor_objects ao,       dba_advisor_tasks t
  where ao.task_id = af.task_id
  and ao.object_id = af.object_id
  and t.advisor_name = 'Segment Advisor' 
  and t.task_name = af.task_name  
  and ao.type in ('TABLE','INDEX')
order by t.EXECUTION_END, ao.type, segname
;





