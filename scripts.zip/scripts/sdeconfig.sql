spool 9174sde.log

set pages 300 lines 300

column PROP_NAME format a30
column CHAR_PROP_VALUE format a80
column NUM_PROP_VALUE format 999,999,999
select * from sde.server_config order by 1;


column KEYWORD format a40
column PARAMETER_NAME format a40
column CONFIG_STRING format a100
select * from sde.dbtune order by 1,2;

spool off
