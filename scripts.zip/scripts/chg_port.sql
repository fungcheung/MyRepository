prompt
prompt show how to change listener port
prompt


prompt 1. lsnrctl stop
prompt 2. Open net manager to change the listner port say from 1521 to 18521
prompt 3. Create a new service say called "mylistener" pointing to the new port.
prompt 4. Save the confiugration in net manager
prompt 5. Register the database , "alter system set local_listener='mylistener' scope=both;"
prompt 6. lsnrctl start






