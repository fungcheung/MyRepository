select 
'alter ' || object_type || ' ' || owner || '.' || object_name ||' compile;'
from dba_objects
where status = 'INVALID'
and owner not in ('SYS', 'SYSTEM') ;

