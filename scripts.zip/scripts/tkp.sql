set heading off
set verify off
set feedback off
set linesize 200

select
'host tkprof '||z.value||'/'||substr(p.program, 1,3)
||'_'||to_char(spid)||'.trc'||' '||'traceout'||' '||'explain=$logname/$logpass'
from v$process p,v$parameter z,v$database d
where USERENV('TERMINAL') = p.terminal
and z.name = 'user_dump_dest'
/

set heading on
set verify on
set feedback on
set linesize 80
-- host vi traceout.prf


