-- filename: list_jobs.sql

set lines 222 pages 999

col jid  format 999999 heading 'Id' 
col subu format a20    heading 'Submitter'     trunc 
col secd format a20    heading 'Security'      trunc 
col proc format a30    heading 'Job'           word_wrapped 
col lsd  format a5     heading 'Last|Ok|Date'  
col lst  format a5     heading 'Last|Ok|Time' 
col nrd  format a5     heading 'Next|Run|Date' 
col nrt  format a5     heading 'Next|Run|Time' 
col fail format 999    heading 'Errs' 
col ok   format a2     heading 'Ok' 
 
select 
  job                        jid, 
  log_user                   subu, 
  priv_user                  secd, 
  what                       proc, 
  to_char(last_date,'MM/DD') lsd, 
  substr(last_sec,1,5)       lst, 
  to_char(next_date,'MM/DD') nrd, 
  substr(next_sec,1,5)       nrt, 
  failures                   fail, 
  decode(broken,'Y','N','Y') ok 
from 
  sys.dba_jobs 
order by 1
/ 


