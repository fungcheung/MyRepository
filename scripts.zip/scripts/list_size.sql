-- filename: list_size.sql

set lines 222 pages 999

col owner 		for a33
col segment_type 	for a33 
col "Mb"		for 99,999.99  head "Mb"

select owner, segment_type, sum(bytes)/1024/1024 "Mb"
from dba_segments
where owner not in ('SYS','SYSTEM')
group by owner, segment_type ;



