rem locking.sql
rem
rem Samson Cheung

set pages 999 lines 111 verif off 

define 'Username' = '&&username'

column name1	heading	'Resource|1'	format a17
column name2	heading	'Resource|2'	format a13
column lmode	heading 	'Mode|Held'		format 999,999,999,999
column request	heading	'Mode|Requested'	format a9
column sid		heading 	'Session|Id'	format 9999999
column serial#	heading 	'Serial|Number'	format 999999
column type		heading 	'Lock|Type'		format a4
column username	heading 	'Username'		format a15
column object	heading 	'Objet Name'	format a30
column command	heading 	'Command'		format a11

prompt 
prompt	RW	Row wait enqueue lock
prompt	TM	DML enqueue lock
prompt	TX	Transaction enqueue lock
prompt	UL	User supplied lock
prompt 
prompt <<  Current Locking.....  >>

SELECT S.USERNAME, S.SID, S.SERIAL#,  L.TYPE, O1.NAME name1, O2.NAME name2,
       DECODE(L.LMODE, 0, 'NONE', 1, 'NULL', 2, '  RS', 3, '  RX', 4, '   S', 5, ' SRX', 6, '   X', '   ?') lmode,
       '  '||DECODE(L.REQUEST, 0, 'NONE', 1, 'NULL', 2, '  RS', 3, '  RX', 4, '   S', 5, ' SRX', 6, '   X', '   ?') request
FROM	SYS.OBJ$ O1, SYS.OBJ$ O2, V$LOCK L, V$SESSION S
WHERE  L.SID=S.SID
-- AND    S.USERNAME = (select upper(user) from dual )
AND    S.USERNAME like upper('%&&username%')
AND	O1.OBJ#(+)	= L.ID1
AND	O2.OBJ#(+)	= L.ID2
ORDER BY O1.NAME, S.SID,L.TYPE ;

prompt <<  User waiting for a LOCK.....  >>

column OBJECT_NAME	heading	'Object'	format a33
column Holder		heading	'Holder'	format a22
column Waiter		heading 	'Waiter'	format a22
column "Lock Type"	heading	'Lock Type'	format a9

select distinct o.object_name, sh.username||'('||sh.sid||')' "Holder", sw.username||'('||sw.sid||')' "Waiter",
       decode(lh.lmode, 1, 'null',  2, 'row share', 3, 'row exclusive',  4, 'share', 
              5, 'share row exclusive' , 6, 'exclusive')  "Lock Type"
  from all_objects o, v$session sw, v$lock lw, v$session sh, v$lock lh
where  lh.id1  = o.object_id
  and  lh.id1  = lw.id1
  and  sh.sid  = lh.sid
  and  sw.sid  = lw.sid
  and  sh.lockwait is null
  and  sw.lockwait is not null
  and  lh.type = 'TM'
  and  lw.type = 'TM' ;

select ses.username, acc.object, lck.type, lck.lmode,  
  decode(ses.command, 2,'INSERT', 3,'SELECT', 6, 'UPDATE', 7,'DELETE', 'Others..' ) command
from v$access acc, v$lock lck, v$session ses
where acc.sid=lck.sid  
  and acc.sid=ses.sid 
  and lck.request > 1
order by ses.username ;

undefine username


/*
set linesize 80  
set pagesize 66  
column lmode heading 'Lock|Held' format a4  
column request heading 'Lock|Req.' format a4  
column username  format a10  heading "Username"  
column tab format a30 heading "Table Name"  
column LAddr heading "ID1 - ID2" format a16  
column Lockt heading "Lock|Type" format a4  
select nvl(S.USERNAME,'Internal') username,  
      decode(command,  
0,'None',decode(l.id2,0,U1.NAME||'.'||substr(T1.NAME,1,20),  
'Rollback Segment')) tab,  
      decode(L.LMODE,1,'NoLk', 2,' RS ', 3,' RX ',  
                4,'  S ', 5,' SRX', 6,'  X ','NONE') lmode,  
      decode(L.REQUEST,1,'NoLk', 2,' RSh ', 3,' RX ',  
        4,'  S ', 5,' SRX', 6,'  X ','NONE') request,  
l.id1||'-'||l.id2 Laddr, l.type Lockt  
from    V$LOCK L, V$SESSION S, SYS.USER$ U1, SYS.OBJ$ T1  
where   L.SID = S.SID and       T1.OBJ#  = decode(L.ID2,0,L.ID1,1)   
and     U1.USER# = T1.OWNER# and        S.TYPE != 'BACKGROUND'  
order by 1,2,5  

*/



/*
set term on; 
set lines 130; 
column sid_ser format a12 heading 'session,|serial#'; 
column username format a12 heading 'os user/|db user'; 
column process format a9 heading 'os|process'; 
column spid format a7 heading 'trace|number'; 
column owner_object format a35 heading 'owner.object'; 
column locked_mode format a13 heading 'locked|mode'; 
column status format a8 heading 'status'; 

select 
substr(to_char(l.session_id)||','||to_char(s.serial#),1,12) sid_ser, 
substr(l.os_user_name||'/'||l.oracle_username,1,12) username, 
l.process, 
p.spid, 
substr(o.owner||'.'||o.object_name,1,35) owner_object, 
decode(l.locked_mode, 
1,'No Lock', 
2,'Row Share', 
3,'Row Exclusive', 
4,'Share', 
5,'Share Row Excl', 
6,'Exclusive',null) locked_mode, 
substr(s.status,1,8) status 
from 
v$locked_object l, 
all_objects o, 
v$session s, 
v$process p 
where 
l.object_id = o.object_id 
and l.session_id = s.sid 
and s.paddr = p.addr 
and s.status != 'KILLED'; 


>> 
----------- cut ---------------------- cut -------------- cut -------------- 
 
SET ECHO off 
REM NAME:   TFSCLOCK.SQL 
REM USAGE:"@path/tfsclock" 
REM ------------------------------------------------------------------------ 
REM REQUIREMENTS: 
REM    SELECT on V_$LOCK, V_$SESSION, SYS.USER$, SYS.OBJ$ 
REM ------------------------------------------------------------------------ 
REM PURPOSE: 
REM    The following locking information script provides fully DECODED 
REM    information regarding the locks currently held in the database. 
REM    The report generated is fairly complex and difficult to read, 
REM    but has considerable detail. 
REM 
REM    The TFTS series contains scripts to provide (less detailed) lock  
REM    information in a formats which are somewhat less difficult to read: 
REM    TFSMLOCK.SQL and TFSLLOCK.SQL. 
REM ------------------------------------------------------------------------ 
REM EXAMPLE: 
REM    Too complex to show a representative sample here 
REM  
REM ------------------------------------------------------------------------ 
REM DISCLAIMER: 
REM    This script is provided for educational purposes only. It is NOT  
REM    supported by Oracle World Wide Technical Support. 
REM    The script has been tested and appears to work as intended. 
REM    You should always run new scripts on a test instance initially. 
REM ------------------------------------------------------------------------ 
REM 

set lines 200 
set pagesize 66 
break on Kill on sid on  username on terminal 
column Kill heading 'Kill String' format a13 
column res heading 'Resource Type' format 999 
column id1 format 9999990 
column id2 format 9999990 
column locking heading 'Lock Held/Lock Requested' format a40 
column lmode heading 'Lock Held' format a20 
column request heading 'Lock Requested' format a20 
column serial# format 99999 
column username  format a10  heading "Username" 
column terminal heading Term format a6 
column tab format a30 heading "Table Name" 
column owner format a9 
column LAddr heading "ID1 - ID2" format a18 
column Lockt heading "Lock Type" format a40 
column command format a25 
column sid format 990 

select 
nvl(S.USERNAME,'Internal') username, 
        L.SID, 
        nvl(S.TERMINAL,'None') terminal, 
        decode(command, 
0,'None',decode(l.id2,0,U1.NAME||'.'||substr(T1.NAME,1,20),'None')) tab, 
decode(command, 
0,'BACKGROUND', 
1,'Create Table', 
2,'INSERT', 
3,'SELECT', 
4,'CREATE CLUSTER', 
5,'ALTER CLUSTER', 
6,'UPDATE', 
7,'DELETE', 
8,'DROP', 
9,'CREATE INDEX', 
10,'DROP INDEX', 
11,'ALTER INDEX', 
12,'DROP TABLE', 
13,'CREATE SEQUENCE', 
14,'ALTER SEQUENCE', 
15,'ALTER TABLE', 
16,'DROP SEQUENCE', 
17,'GRANT', 
18,'REVOKE', 
19,'CREATE SYNONYM', 
20,'DROP SYNONYM', 
21,'CREATE VIEW', 
22,'DROP VIEW', 
23,'VALIDATE INDEX', 
24,'CREATE PROCEDURE', 
25,'ALTER PROCEDURE', 
26,'LOCK TABLE', 
27,'NO OPERATION', 
28,'RENAME', 
29,'COMMENT', 
30,'AUDIT', 
31,'NOAUDIT', 
32,'CREATE EXTERNAL DATABASE', 
33,'DROP EXTERNAL DATABASE', 
34,'CREATE DATABASE', 
35,'ALTER DATABASE', 
36,'CREATE ROLLBACK SEGMENT', 
37,'ALTER ROLLBACK SEGMENT', 
38,'DROP ROLLBACK SEGMENT', 
39,'CREATE TABLESPACE', 
40,'ALTER TABLESPACE', 
41,'DROP TABLESPACE', 
42,'ALTER SESSION', 
43,'ALTER USER', 
44,'COMMIT', 
45,'ROLLBACK', 
46,'SAVEPOINT', 
47,'PL/SQL EXECUTE', 
48,'SET TRANSACTION', 
49,'ALTER SYSTEM SWITCH LOG', 
50,'EXPLAIN', 
51,'CREATE USER', 
52,'CREATE ROLE', 
53,'DROP USER', 
54,'DROP ROLE', 
55,'SET ROLE', 
56,'CREATE SCHEMA', 
57,'CREATE CONTROL FILE', 
58,'ALTER TRACING', 
59,'CREATE TRIGGER', 
60,'ALTER TRIGGER', 
61,'DROP TRIGGER', 
62,'ANALYZE TABLE', 
63,'ANALYZE INDEX', 
64,'ANALYZE CLUSTER', 
65,'CREATE PROFILE', 
66,'DROP PROFILE', 
67,'ALTER PROFILE', 
68,'DROP PROCEDURE', 
69,'DROP PROCEDURE',
70,'ALTER RESOURCE COST', 
71,'CREATE SNAPSHOT LOG', 
72,'ALTER SNAPSHOT LOG', 
73,'DROP SNAPSHOT LOG', 
74,'CREATE SNAPSHOT', 
75,'ALTER SNAPSHOT', 
76,'DROP SNAPSHOT', 
79,'ALTER ROLE',
85,'TRUNCATE TABLE', 
86,'TRUNCATE CLUSTER', 
87,'-', 
88,'ALTER VIEW', 
89,'-', 
90,'-', 
91,'CREATE FUNCTION', 
92,'ALTER FUNCTION', 
93,'DROP FUNCTION', 
94,'CREATE PACKAGE', 
95,'ALTER PACKAGE', 
96,'DROP PACKAGE', 
97,'CREATE PACKAGE BODY', 
98,'ALTER PACKAGE BODY', 
99,'DROP PACKAGE BODY', 
command||' - ???') COMMAND, 
        decode(L.LMODE,1,'No Lock', 
                2,'Row Share', 
                3,'Row Exclusive', 
                4,'Share', 
                5,'Share Row Exclusive', 
                6,'Exclusive','NONE') lmode, 
        decode(L.REQUEST,1,'No Lock', 
                2,'Row Share', 
                3,'Row Exclusive', 
                4,'Share', 
                5,'Share Row Exclusive', 
                6,'Exclusive','NONE') request, 
l.id1||'-'||l.id2 Laddr, 
l.type||' - '|| 
decode(l.type, 
'BL','Buffer hash table instance lock', 
'CF',' Control file schema global enqueue lock', 
'CI','Cross-instance function invocation instance lock',
'CS','Control file schema global enqueue lock', 
'CU','Cursor bind lock',
'DF','Data file instance lock', 
'DL','Direct loader parallel index create',
'DM','Mount/startup db primary/secondary instance lock', 
'DR','Distributed recovery process lock', 
'DX','Distributed transaction entry lock', 
'FI','SGA open-file information lock', 
'FS','File set lock', 
'HW','Space management operations on a specific segment lock',
'IN','Instance number lock',
'IR','Instance recovery serialization global enqueue lock', 
'IS','Instance state lock',
'IV','Library cache invalidation instance lock', 
'JQ','Job queue lock',
'KK','Thread kick lock',
'MB','Master buffer hash table instance lock', 
'MM','Mount definition gloabal enqueue lock', 
'MR','Media recovery lock', 
'PF','Password file lock',
'PI','Parallel operation lock',
'PR','Process startup lock',
'PS','Parallel operation lock',
'RE','USE_ROW_ENQUEUE enforcement lock', 
'RT','Redo thread global enqueue lock', 
'RW','Row wait enqueue lock', 
'SC','System commit number instance lock', 
'SH','System commit number high water mark enqueue lock', 
'SM','SMON lock',
'SN','Sequence number instance lock', 
'SQ','Sequence number enqueue lock', 
'SS','Sort segment lock',
'ST','Space transaction enqueue lock', 
'SV','Sequence number value lock', 
'TA','Generic enqueue lock', 
'TD','DDL enqueue lock', 
'TE','Extend-segment enqueue lock', 
'TM','DML enqueue lock', 
'TT','Temporary table enqueue lock', 
'TX','Transaction enqueue lock', 
'UL','User supplied lock', 
'UN','User name lock', 
'US','Undo segment DDL lock',
'WL','Being-written redo log instance lock', 
'WS','Write-atomic-log-switch global enqueue lock', 
'TS',decode(l.id2,0,'Temporary segment enqueue lock (ID2=0)', 
                   
'New block allocation enqueue lock (ID2=1)'), 
'LA','Library cache lock instance lock (A=namespace)', 
'LB','Library cache lock instance lock (B=namespace)', 
'LC','Library cache lock instance lock (C=namespace)', 
'LD','Library cache lock instance lock (D=namespace)', 
'LE','Library cache lock instance lock (E=namespace)', 
'LF','Library cache lock instance lock (F=namespace)', 
'LG','Library cache lock instance lock (G=namespace)', 
'LH','Library cache lock instance lock (H=namespace)', 
'LI','Library cache lock instance lock (I=namespace)', 
'LJ','Library cache lock instance lock (J=namespace)', 
'LK','Library cache lock instance lock (K=namespace)', 
'LL','Library cache lock instance lock (L=namespace)', 
'LM','Library cache lock instance lock (M=namespace)', 
'LN','Library cache lock instance lock (N=namespace)', 
'LO','Library cache lock instance lock (O=namespace)', 
'LP','Library cache lock instance lock (P=namespace)', 
'LS','Log start/log switch enqueue lock', 
'PA','Library cache pin instance lock (A=namespace)', 
'PB','Library cache pin instance lock (B=namespace)', 
'PC','Library cache pin instance lock (C=namespace)', 
'PD','Library cache pin instance lock (D=namespace)', 
'PE','Library cache pin instance lock (E=namespace)', 
'PF','Library cache pin instance lock (F=namespace)', 
'PG','Library cache pin instance lock (G=namespace)', 
'PH','Library cache pin instance lock (H=namespace)', 
'PI','Library cache pin instance lock (I=namespace)', 
'PJ','Library cache pin instance lock (J=namespace)', 
'PL','Library cache pin instance lock (K=namespace)', 
'PK','Library cache pin instance lock (L=namespace)', 
'PM','Library cache pin instance lock (M=namespace)', 
'PN','Library cache pin instance lock (N=namespace)', 
'PO','Library cache pin instance lock (O=namespace)', 
'PP','Library cache pin instance lock (P=namespace)', 
'PQ','Library cache pin instance lock (Q=namespace)', 
'PR','Library cache pin instance lock (R=namespace)', 
'PS','Library cache pin instance lock (S=namespace)', 
'PT','Library cache pin instance lock (T=namespace)', 
'PU','Library cache pin instance lock (U=namespace)', 
'PV','Library cache pin instance lock (V=namespace)', 
'PW','Library cache pin instance lock (W=namespace)', 
'PX','Library cache pin instance lock (X=namespace)', 
'PY','Library cache pin instance lock (Y=namespace)', 
'PZ','Library cache pin instance lock (Z=namespace)', 
'QA','Row cache instance lock (A=cache)', 
'QB','Row cache instance lock (B=cache)', 
'QC','Row cache instance lock (C=cache)', 
'QD','Row cache instance lock (D=cache)', 
'QE','Row cache instance lock (E=cache)', 
'QF','Row cache instance lock (F=cache)', 
'QG','Row cache instance lock (G=cache)', 
'QH','Row cache instance lock (H=cache)', 
'QI','Row cache instance lock (I=cache)', 
'QJ','Row cache instance lock (J=cache)', 
'QL','Row cache instance lock (K=cache)', 
'QK','Row cache instance lock (L=cache)', 
'QM','Row cache instance lock (M=cache)', 
'QN','Row cache instance lock (N=cache)', 
'QO','Row cache instance lock (O=cache)', 
'QP','Row cache instance lock (P=cache)', 
'QQ','Row cache instance lock (Q=cache)', 
'QR','Row cache instance lock (R=cache)', 
'QS','Row cache instance lock (S=cache)', 
'QT','Row cache instance lock (T=cache)', 
'QU','Row cache instance lock (U=cache)', 
'QV','Row cache instance lock (V=cache)', 
'QW','Row cache instance lock (W=cache)', 
'QX','Row cache instance lock (X=cache)', 
'QY','Row cache instance lock (Y=cache)', 
'QZ','Row cache instance lock (Z=cache)','????') Lockt 
from    V$LOCK L,  
        V$SESSION S, 
        SYS.USER$ U1, 
        SYS.OBJ$ T1 
where   L.SID = S.SID  
and     T1.OBJ#  = decode(L.ID2,0,L.ID1,1)  
and     U1.USER# = T1.OWNER# 
and     S.TYPE != 'BACKGROUND' 
order by 1,2,5 


*/

