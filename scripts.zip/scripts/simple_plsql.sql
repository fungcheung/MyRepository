set serveroutput on

declare
 v_empname varchar2(60); 
 v_empno number := 2;
begin

 select ename into v_empname from emp where empno = v_empno;
 dbms_output.put_line('Employer name :' || v_empname);
 
end;
/


