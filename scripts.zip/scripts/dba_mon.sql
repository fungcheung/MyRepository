-- filename: ACE_mon.sql

spool /export/oracle/u010/oracle/dbasql/dba_mon2.out

set pages 0 echo off head off feed off lines 180 term off

select 'Database Report of '||name||'_'||machine||' '||to_char(sysdate,'YYYY-MM-DD HH24:MI:SS')  
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

prompt

set pages 9999 head on feed on

prompt  >> 
prompt  >> Tablespace Usages
prompt  >> 

column tablespace_name   format a20          heading "Tablespace Name" 
column file_name         format a45          heading "File|Name" 
column Size_M            format 9,999,999.99 heading "Allocated|MBytes"
column Free_M            format 9,999,999.99 heading "Free|MBytes"
column Used_M            format 9,999,999.99 heading "Used|MBytes"
column Used_P            format 999.99       heading "Used %%"
column frag_count        format 999,999      heading "No. of|Free Exts" 
column large_frag        format 99,999,999   heading "Largest|Exts (KB)"  
column small_frag        format 99,999,999   heading "Smallest|Exts (KB)" 
column initext           format 999,999      heading "Initial|Exts (KB)" 
column nxtreqext         format 999,999      heading "Nxt Reqd|Exts (KB)" 

select a.tablespace_name, a.a1 "Size_M", a.a1-nvl(b.b1,0) "Used_M", 
nvl(b.b1,0) "Free_M" , (a.a1-nvl(b.b1,0))/a.a1*100 "Used_P", 
b2 frag_count, b3 large_frag, b4 small_frag,
nvl(c1,0) nxtreqext
from
(SELECT tablespace_name, sum(bytes/1024/1024) a1
   FROM dba_data_files
group BY tablespace_name) a,
(SELECT tablespace_name, 
        SUM(bytes/1024/1024) b1,
        count(*)             b2,
        max(bytes/1024)      b3,
        min(bytes/1024)      b4
   FROM dba_free_space
   GROUP BY tablespace_name) b,
(SELECT tablespace_name,  
        MAX(NEXT_EXTENT)/1024  c1 
   FROM DBA_SEGMENTS 
  GROUP BY tablespace_name) c
where a.tablespace_name = b.tablespace_name (+)
and  a.tablespace_name = c.tablespace_name (+)
order by 1  ;


prompt  >> 
prompt  >> Datafiles Usages
prompt  >> 

column tablespace_name   format a20        heading "Tblsp Name" 
column file_name         format a60        heading "File|Name" 
column auto              format a5         heading "Auto"
column Size_M            format 999,999.9  heading "Allocated|MBytes"
column Free_M            format 999,999.9  heading "Free|MBytes"
column Used_M            format 999,999.9  heading "Used|MBytes"
column Used_P            format 999.99     heading "Used %%"
column frag_count        format 999,999    heading "No. of|Free Exts" 
column large_frag        format 99,999.9   heading "Largest|Exts (MB)"  
column small_frag        format 99,999.9   heading "Smallest|Exts (MB)" 
column initext           format 999,999    heading "Initial|Exts (KB)" 
column nxtreqext         format 999,999    heading "Nxt Reqd|Exts (KB)" 

select 
  a.tablespace_name, a.file_name, a.AUTOEXTENSIBLE "Auto", a.a1 "Size_M", a.a1-b.b1 "Used_M", 
  nvl(b.b1,0) "Free_M" , (a.a1-b.b1)/a.a1*100 "Used_P", 
  b2 frag_count, b3 large_frag, b4 small_frag,
  nvl(c1,0) nxtreqext
from
(SELECT tablespace_name, file_name, file_id, AUTOEXTENSIBLE, sum(bytes/1024/1024) a1
   FROM dba_data_files
group BY tablespace_name, file_name, file_id, AUTOEXTENSIBLE) a,
(SELECT ddf.file_id,
        nvl(SUM(dfs.bytes/1024/1024),0) b1,
        count(*)             b2,
        nvl(max(dfs.bytes/1024/1024),0) b3,
        nvl(min(dfs.bytes/1024/1024),0) b4
   FROM dba_free_space dfs, dba_data_files ddf
   where dfs.file_id (+) = ddf.file_id
   GROUP BY ddf.file_id) b,
(SELECT tablespace_name,  
        MAX(NEXT_EXTENT)/1024  c1 
   FROM DBA_SEGMENTS 
  GROUP BY tablespace_name) c
where a.file_id = b.file_id(+)
and a.tablespace_name = c.tablespace_name (+)
order by a.tablespace_name, a.file_name ;


prompt  >> 
prompt  >> Avaliable Next Extents < 5
prompt  >> 

column owner format a10      heading "Owner"
column a1 format a17         heading "TableSp"
column a2 format a33         heading "Segment Name"
column a3 format 99,999,999  heading "Free|Tblsp (Kb)"
column a4 format 999,999,999 heading "Max Free|Bytes (Kb)"
column a5 format 999,999     heading "Next|Exts (Kb)"
column a6 format 9,999.99    heading "Avail|Extents"
column a7 format a10         heading "Segt Type"
break on owner skip 1

select
   b.owner, a.tablespace_name a1, b.segment_type a7, count(*) "Cnt"
from
  ( select tablespace_name, max(bytes) maxbyte, sum(bytes) sumbyte
    from dba_free_space
    group by tablespace_name ) a,
  ( select owner, tablespace_name, segment_name, segment_type, next_extent nxtext
    from dba_segments
    where owner not in ('SYS','SYSTEM') ) b
where a.tablespace_name = b.tablespace_name(+)
and a.maxbyte/b.nxtext < 5
group by b.owner, a.tablespace_name, b.segment_type
order by b.owner, a.tablespace_name, b.segment_type ;

prompt  >> 
prompt  >> Invalid Objects
prompt  >> 

column status format a10 heading "Status"

select owner, object_type, object_name, status 
  from all_objects
 where status = 'INVALID'
 and owner not in ('SYS','SYSTEM')
ORDER BY owner, object_type, object_name ;

prompt  >> 
prompt  >> Buffer Hit Ratio
prompt  >> 

  col "CACHE HIT RATIO" for 99990.00
  col Total_Reads for 999,999,999,999,990
  col Cached for 999,999,999,999,990

  SELECT (cur.value + con.value - phys.value) Cached, (cur.value + con.value) Total_Reads,
   ((cur.value + con.value - phys.value) / (cur.value + con.value)*100) "CACHE HIT RATIO"
   FROM v$sysstat cur, v$sysstat con, v$sysstat phys
  WHERE cur.name = 'db block gets' and con.name = 'consistent gets' and phys.name = 'physical reads' ;

prompt  >> 
prompt  >> Library Cache Hit Ratio
prompt  >> 

  col HIT_RATIO for 99990.00
  col RELOADS for 999,999,999,999,990
  col PINS for 999,999,999,999,990

  SELECT sum(reloads) RELOADS, sum(pins) PINS, 100*sum(reloads)/sum(pins) HIT_RATIO 
    FROM v$librarycache;

prompt  >> 
prompt  >> Data Dictionary Cache Hit Ratio
prompt  >> 

  col HIT_RATIO for 99990.00
  col GETMISSES for 999,999,999,999,990
  col GETS for 999,999,999,999,990

  SELECT sum(getmisses) GETMISSES,sum(gets) GETS, 100*sum(getmisses)/sum(gets) HIT_RATIO 
    FROM v$rowcache;

prompt  >> 
prompt  >> Shared Pool Freespace%  
prompt  >> 

  col pool     format a22    head "Pool"
  col name     format a22    head "Name"
  col value    format a22    head "Values"
  col percento format 990.00 head "Freespace %"

  SELECT f.pool, f.name, s.value, TO_CHAR((f.bytes/s.value)*100,'990.00')||' %' percento 
  FROM v$parameter s, v$sgastat f
  WHERE f.name='free memory' 
  AND f.pool='shared pool' 
  AND s.name='shared_pool_size' ;

prompt  >> 
prompt  >> Memory/Disk Sort
prompt  >> 

  col name for a16
  col value for 999,999,999,990

  SELECT name,value FROM v$sysstat 
   WHERE name IN ('sorts (memory)','sorts (disk)') ;

prompt  >> 
prompt  >> Initial Parameter
prompt  >> 

  col name for a30
  col value for a20

  SELECT name, value FROM v$parameter 
   WHERE name 
   IN ('sort_area_size', 'sort_area_retained_size','db_block_size',
       'db_block_buffers', 'shared_pool_size') ORDER BY name;

prompt
prompt  ~~ End ~~ 

spool off 

exit
