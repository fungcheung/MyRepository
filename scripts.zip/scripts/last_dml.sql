--
-- filename: last_dml.sql
-- Find the last modification DML(insert,update) timestamp of a table.

set lines 222 pages 999
alter session set nls_language='american' nls_territory='america';
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
prompt Find last change time of a table
prompt Enter the schema name and then the table name in CAPS LOCK

select max(ora_rowscn), scn_to_timestamp(max(ora_rowscn)) from "&&1"."&&2";

undef 1 
undef 2
