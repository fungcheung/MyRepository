set linesize 188 pages 999

prompt =========================================================================================================================================================
prompt Open txn has been running for longer than five minutes
 
SELECT   
s.osuser, 
vp.spid as os_pid, 
S.BLOCKING_SESSION blocker,   
S.SID, 
S.SERIAL#, 
S.USERNAME, 
S.MACHINE,   
Q.SQL_FULLTEXT cur_sql, 
PQ.SQL_FULLTEXT prev_sql,    
vt.used_urec, 
to_char(vt.start_date,'dd-mm-yy hh:mi:ss')
FROM    v$session S   LEFT JOIN v$sqlarea Q on S.SQL_ID = Q.SQL_ID   
LEFT JOIN v$sqlarea PQ on S.PREV_SQL_ID = PQ.SQL_ID   
LEFT JOIN v$process vp on s.paddr = vp.addr   
LEFT JOIN v$transaction vt on s.saddr = vt.ses_addr
WHERE   vt.start_date < SYSDATE - (1/1440)
--   AND
--   s.machine = 'machine.name'
ORDER BY    S.SID;  



prompt =========================================================================================================================================================
prompt Active transactions using undo extents
SELECT s.username, t.xidusn, t.ubafil, t.ubablk, t.used_ublk
FROM v$session s, v$transaction t
WHERE s.saddr = t.ses_addr;
