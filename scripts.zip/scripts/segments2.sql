set linesize 188 pages 999

col segment_name format a30
col owner format a15
col segment_type format a15
col tablespace_name format a15
col table_name format a30
col column_name format a30
col Size_M format 999,999

prompt =========================================================================================================================================================
prompt Show largest 80 segments and tables

select * from (
select a.owner, a.segment_name, a.segment_type, a.BYTES/1024/1024 Size_M ,a.tablespace_name, b.table_name, b.column_name 
from dba_segments a, dba_lobs b 
where a.segment_name not like 'BIN$%' and a.segment_type in ('LOBSEGMENT','TABLE') 
and a.owner = b.owner(+) and a.segment_name = b.segment_name(+)
order by Size_M desc) where rownum <= 80;


prompt =========================================================================================================================================================
prompt Enter tablespace name to show first 80 objects order by SIZE
 
select * from (
select a.owner, a.segment_name, a.segment_type, a.BYTES/1024/1024 Size_M ,a.tablespace_name, b.table_name, b.column_name 
from dba_segments a, dba_lobs b 
where a.segment_name not like 'BIN$%' and a.segment_type in ('LOBSEGMENT','TABLE') 
and a.owner = b.owner(+) and a.segment_name = b.segment_name(+) 
and a.tablespace_name = upper('&tablespace')
order by Size_M desc) where rownum <= 80;


prompt =========================================================================================================================================================
prompt Enter schema name to show first 80 objects order by SIZE
 
select * from (
select a.owner, a.segment_name, a.segment_type, a.BYTES/1024/1024 Size_M ,a.tablespace_name, b.table_name, b.column_name 
from dba_segments a, dba_lobs b 
where a.segment_name not like 'BIN$%' and a.segment_type in ('LOBSEGMENT','TABLE') 
and a.owner = b.owner(+) and a.segment_name = b.segment_name(+) 
and a.owner = upper('&schema')
order by Size_M desc) where rownum <= 80;


prompt =========================================================================================================================================================
prompt Enter segment name
 
select * from (
select a.owner, a.segment_name, a.segment_type, a.BYTES/1024/1024 Size_M ,a.tablespace_name, b.table_name, b.column_name 
from dba_segments a, dba_lobs b 
where a.segment_name not like 'BIN$%' and a.segment_type in ('LOBSEGMENT','TABLE') 
and a.owner = b.owner(+) and a.segment_name = b.segment_name(+) 
and a.segment_name like upper('%&segment%')
order by Size_M desc) where rownum <= 80;
