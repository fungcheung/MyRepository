set echo off feed off
set sqlprompt "_user'@'_connect_identifier> "

