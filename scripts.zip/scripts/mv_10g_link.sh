cd $ORACLE_HOME ; pwd

rm 	./bin/lbuilder 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/nls/lbuilder/lbuilder	./bin/lbuilder 

rm 	./ctx/lib/libXML4CMessages.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libXML4CMessages.so.54.0	./ctx/lib/libXML4CMessages.so 

rm 	./ctx/lib/libXML4CMessages.so.54 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libXML4CMessages.so.54.0	./ctx/lib/libXML4CMessages.so.54 

rm 	./ctx/lib/libicudata.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libicudata.so.26.1	./ctx/lib/libicudata.so 

rm 	./ctx/lib/libicudata.so.26 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libicudata.so.26.1	./ctx/lib/libicudata.so.26 

rm 	./ctx/lib/libicuuc.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libicuuc.so.26.1	./ctx/lib/libicuuc.so 

rm 	./ctx/lib/libicuuc.so.26 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libicuuc.so.26.1	./ctx/lib/libicuuc.so.26 

rm 	./ctx/lib/libxml4c.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libxml4c.so.54.0	./ctx/lib/libxml4c.so 

rm 	./ctx/lib/libxml4c.so.54 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/ctx/lib/libxml4c.so.54.0	./ctx/lib/libxml4c.so.54 

rm 	./instantclient32/libclntsh.so.10.1 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libclntsh.so.10.1	./instantclient32/libclntsh.so.10.1 

rm 	./instantclient32/libheteroxa10.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libheteroxa10.so	./instantclient32/libheteroxa10.so 

rm 	./instantclient32/libnnz10.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libnnz10.so	./instantclient32/libnnz10.so 

rm 	./instantclient32/libocci.so.10.1 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libocci.so.10.1	./instantclient32/libocci.so.10.1 

rm 	./instantclient32/libocijdbc10.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libocijdbc10.so	./instantclient32/libocijdbc10.so 

rm 	./instantclient32/libskgxp10.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libskgxp10.so	./instantclient32/libskgxp10.so 

rm 	./lib/libnavhoa.a 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/libnavhoa.a	./lib/libnavhoa.a 

rm 	./lib/hsdb_ora.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/hsdb_ora.so	./lib/hsdb_ora.so 

rm 	./lib/hsdb_odbc.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/hsdb_odbc.so	./lib/hsdb_odbc.so 

rm 	./lib/hsdb_inf.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/hsdb_inf.so	./lib/hsdb_inf.so 

rm 	./lib/hsdb_oing.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/hsdb_oing.so	./lib/hsdb_oing.so 

rm 	./lib/hsdb_syb.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib32/hsdb_syb.so	./lib/hsdb_syb.so 

rm 	./lib/libclntsh.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib/libclntsh.so.10.1	./lib/libclntsh.so 

rm 	./lib/liborasdkbase.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib/liborasdkbase.so.10.2	./lib/liborasdkbase.so 

rm 	./lib/liborasdk.so 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib/liborasdk.so.10.2	./lib/liborasdk.so 

rm 	./lib32/ldflags 
ln -s /data/oracle/TWXBOS/product/10.2.0.3/lib/ldflags	./lib32/ldflags 

