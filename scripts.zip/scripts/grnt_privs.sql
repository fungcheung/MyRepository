-- Filename: grnt_privs.sql

undef username

set pages 999 lines 88 head off feed off doc off

-->> schema role

select 'Privileges for user /* '||upper('&&username')||' */' from dual ;

prompt 
prompt >> Granted ROLE 
prompt 

select 'grant '||GRANTED_ROLE||' to '||upper('&&username')||' ; '
from dba_role_privs
where grantee = upper('&&username') ;

-->> object privs
prompt 
prompt >> Granted Object Privileges
prompt 
select 'grant '||PRIVILEGE||' on '||OWNER||'.'||TABLE_NAME||' to '||grantee||' ; ' 
from dba_tab_privs
where grantee in (
select GRANTED_ROLE from dba_role_privs
where grantee = upper('&&username') )
or grantee = upper('&&username') 
order by 1 ;

-->> system privs
prompt 
prompt >> Granted System Privileges
prompt 
select 'GRANT ' || rpad(upper(privilege),30) || ' TO ' || upper(grantee) || 
  decode(admin_option,'YES',' WITH ADMIN OPTION;',';') 
from sys.dba_sys_privs 
-- where grantee not in ('CONNECT','RESOURCE','DBA', 'EXP_FULL_DATABASE','IMP_FULL_DATABASE') 
where ( grantee in (
select GRANTED_ROLE from dba_role_privs
where grantee = upper('&&username')  )
or grantee = upper('&&username')   )
order by 1 ;

undef 1
undef 1

prompt
prompt  >> End
prompt
set head on feed on
clear column


