#!/bin/ksh
## Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_locking.sh

SERVICE_GROUP=hkgfccedbp1 
export SERVICE_GROUP

ORACLE_HOME=/hkgfccedbp1/export/oracle/product/9.2.0.6 
export ORACLE_HOME

ORACLE_SID=FCCE 
export ORACLE_SID

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

ADMIN=samson.wk.cheung@db.com
export ADMIN

OUT_FILE=/tmp/orarpt_locking_${ORACLE_SID}.out
export OUT_FILE

$ORACLE_HOME/bin/sqlplus / << EOF > $OUT_FILE
column OBJECT_NAME	heading	'Object'	format a33
column Holder		heading	'Holder'	format a15
column Waiter		heading 'Waiter'	format a15
column "Lock Type"	heading	'Lock Type'	format a9
set feed on head on  echo on lines 88
select distinct o.object_name, sh.username||'('||sh.sid||')' "Holder", sw.username||'('||sw.sid||')' "Waiter",
       decode(lh.lmode, 1, 'null',  2, 'row share', 3, 'row exclusive',  4, 'share', 
              5, 'share row exclusive' , 6, 'exclusive')  "Lock Type"
  from all_objects o, v\$session sw, v\$lock lw, v\$session sh, v\$lock lh
where  lh.id1  = o.object_id
  and  lh.id1  = lw.id1
  and  sh.sid  = lh.sid
  and  sw.sid  = lw.sid
  and  sh.lockwait is null
  and  sw.lockwait is not null
  and  lh.type = 'TM'
  and  lw.type = 'TM' ;

EOF

if [  `/usr/bin/grep 'no rows selected' $OUT_FILE | /usr/bin/wc -l` -eq 1 ] ; then
   echo 'No Locking found'
else
  /usr/bin/cat  /tmp/orarpt_locking_FCCE.out | /usr/bin/mailx -s "${ORACLE_SID}@`hostname` Locking Err" $ADMIN
fi

exit 0

