-- 
-- Filename: /hkgresdbp1/export/oracle/u001/admin/research/adhoc/post_imprsh.sql

drop user OPS$WONGD    cascade ;

alter rollback segment RBS01 online ;
alter rollback segment RBS02 online ;
alter rollback segment RBS03 online ;
alter rollback segment RBS04 online ;
alter rollback segment RBS05 online ;

alter rollback segment bigrbs offline ;

--

exit


