-- Filename: tblidx.sql

undef tbl_name
undef user1
def &&user1

clear break
clear compute

set serverout off
set term off

col c_logfile new_value logfile
select '&&user1'||'@'||machine||'_tbidx_'||to_char(sysdate,'rrrrmmdd') c_logfile
  from v$session 
 where upper(program) like upper('%oracle%')
   and rownum = 1 ; 


set pages 999
set lines 270
set feed on
set term off
set verif off
set echo off

col owner for a8
col table_name for a32
col index_name for a32
col t_mb for 999,999.99 head "Tab Mb"
col i_mb for 999,999.99 head "Idx Mb"
col ti_ra  for 99.99 head "Idx/Tab|Ratio"
col t_tsp  for a15 head "Tab|Tblsp"
col t_rows for 999,999,999 head "Tab|Rows"
col i_tsp  for a17 head "Idx|Tblsp"
col t_blk  for 999,999,999 head "Tab|Block"
col t_eblk for 999,999,999 head "Tab|Empty Blk"
col i_blk  for 999,999,999
col blksz  for a5
col tab_ext for 999,999 head "Tab|Exts"
col idx_ext for 999,999 head "Idx|Exts"
col tab_mxext for 999,999 head "Tab|MxExts"
col idx_mxext for 999,999 head "Idx|MxExts"
col tab_initext for 999,999 head "Tab|InitExt(K)"
col idx_initext for 999,999 head "Idx|InitExt(K)"
col tab_nxtext for 999,999 head "Tab|NxtExt(K)"
col idx_nxtext for 999,999 head "Idx|NxtExt(K)"
col maxfree    for 999,999,999 head "Tsp|MxFreeExt(K)"

break on owner on table_name on index_name on report
compute sum of i_mb on report skip 2
compute sum of t_mb on report skip 2

set head off
set feed off
select '<< Storage of Tables/Indexes for '||upper('&&user1')||'@'||upper(name)||' on '||sysdate||'>>'
from v$database, v$session
where rownum=1 and program like 'oracle%'
/
set head on
set feed on

select 
  tab1.owner, tab1.table_name, idx1.index_name, 
  tab1.t_tsp , idx1.i_tsp, tab1.t1_rows t_rows,
  par.BLKSZ blksz, tab1.t_blk*BLKSZ/1024/1024 t_mb, idx1.i_blk*BLKSZ/1024/1024 i_mb, 
  idx1.i_blk/decode(tab1.t_blk,0,-1,tab1.t_blk) ti_ra ,
  tab1.extents tab_ext, idx1.extents idx_ext, 
  tab1.max_extents tab_mxext, idx1.max_extents idx_mxext, 
  tab1.initial_extent/1024 tab_initext, tab1.next_extent/1024 tab_nxtext, idx1.next_extent/1024  idx_nxtext,
  tab1.t_blk, tab1.t_eblk,
  dfs.mxfree/1024 maxfree
from 
(-- tables --
select 
   dt.owner, dt.table_name, dt.tablespace_name t_tsp, dt.NUM_ROWS t1_rows, dt.blocks t_blk, dt.empty_blocks t_eblk, 
   ds.extents, dt.max_extents, dt.initial_extent, dt.next_extent
from dba_tables dt, dba_segments ds
where table_name like upper('%tbl_name%') and
-- where dt.owner = (select user from dual)
  dt.owner = upper('&&user1')
-- and dt.table_name in (select table_name from ctcstables) 
and dt.table_name = ds.segment_name
and dt.owner = ds.owner  ) tab1,
(-- indexes --
select 
   di.owner, di.table_name, di.index_name, di.tablespace_name i_tsp, ds.blocks i_blk, 
   ds.extents, di.max_extents, di.next_extent
from dba_indexes di, dba_segments ds
-- where di.owner = (select user from dual)
where di.owner = upper('&&user1')
-- and di.table_name in (select table_name from ctcstables)
and di.index_name = ds.segment_name
and di.owner = ds.owner ) idx1,
(-- block_size
  select value BLKSZ from v$parameter where name='db_block_size') par,
( -- FreeSpace
select tablespace_name, max(bytes) mxfree from dba_free_space 
 group by tablespace_name ) dfs
-- where tab1.owner = (select user from dual)
where tab1.owner = upper('&&user1')
--  and tab1.table_name in (select table_name from ctcstables)
--  and tab1.table_name = 'CTCS_ADDRESS'
  and tab1.owner = idx1.owner (+)
  and tab1.table_name= idx1.table_name (+)
  and tab1.t_tsp = dfs.tablespace_name
order by 1,2,3 ;

set pages 999
set feed on
set term on

