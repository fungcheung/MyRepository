-- Filename: Objs_alloc.sql

col username format a20
col Tab  format 99,990
col Ind  format 99990
col Syn  format 99990
col Vew  format 9990
col Seq  format 9990
col Prc  format 990
col Trg  format 990
col Pck  format 990
col Fun  format 990
col Dep  format 9990
set pages 50000 lines 111
break on sort_key skip 1 on username on report
compute sum of Tab on report
compute sum of Ind on report
compute sum of Syn on report
compute sum of Vew on report
compute sum of Seq on report
compute sum of Trg on report
compute sum of Fun on report
compute sum of Pck on report
compute sum of Prc on report
compute sum of Dep on report

spool c:\temp\Objs_alloc.out

prompt 
prompt << User Database Objects Allocation >>
prompt 

select owner, tablespace_name, segment_type, count(*)
from  dba_segments
group by owner, tablespace_name, segment_type
order by owner, tablespace_name, segment_type
/

prompt
prompt << User Database Objects Tablespace Usage >>
prompt

column "MB" format 9,999,999.99 heading "Used|MBytes"

select OWNER, TABLESPACE_NAME , SEGMENT_TYPE , sum(BYTES/1024/1024) "MB"
from dba_segments 
group by OWNER, TABLESPACE_NAME , SEGMENT_TYPE 
order by OWNER, TABLESPACE_NAME , SEGMENT_TYPE 
/

spool off
tti off

prompt 
prompt host write c:\temp\Objs_alloc.out
prompt 
