set linesize 188 pages 999

col segment_name format a30

prompt =========================================================================================================================================================
prompt Generate DDL for a object. Please input TYPE, OBJECT NAME and SCHEMA

set long 999999

select dbms_metadata.get_ddl(upper('&type'),upper('&object'),upper('&schema')) from dual;




