#!/bin/ksh
## Filename: orarpt_chkconn.sh
## Usage: ./orarpt_chkconn.sh 

ORACLE_HOME=/data/oracle/product/9.2.0.4  
export ORACLE_HOME

TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN

ADMIN=samson.wk.cheung@db.com 
export ADMIN

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

## /usr/bin/grep -i world $TNS_ADMIN/tnsnames.ora | /usr/bin/grep -vi 'port' | sort | uniq | /usr/bin/awk -F'.' '{print $1}' > /home/oracle/dbasql/db_list.lst
echo GELDEV > /home/oracle/dbasql/db_list.lst

/usr/bin/rm /home/oracle/dbasql/temp/*

/usr/bin/cat /home/oracle/dbasql/db_list.lst | while read LINE
do
    ORACLE_SID=`echo $LINE | awk '{print $1}' `
    export ORACLE_SID

    OUT_FILE=/tmp/orarpt_connect_${ORACLE_SID}.out   
    export OUT_FILE

$ORACLE_HOME/bin/sqlplus dba_mon/keep1tsecret@$ORACLE_SID  << EOF > $OUT_FILE
select name from v\$database ;
select to_char(sysdate, 'RRRRMMDD HH:MI:SS') from dual ;
EOF

    if [  `/usr/bin/grep 'ORA-' $OUT_FILE | /usr/bin/wc -l` -ge 1 ] ; then
       echo "${ORACLE_SID}` connection Err" | /usr/bin/mailx -s "${ORACLE_SID} connection Err" $ADMIN
       ## /apps/admin/bin/sendtivoli.sh 5 HKG_UNIX_ES DBCON0001 "${ORACLE_SID} connection Err"
    else 
       ## /apps/admin/bin/sendtivoli.sh 0 HKG_UNIX_ES DBCON0001 "${ORACLE_SID} connection Err"
    fi

done

exit 0

