-- 
-- Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_IESrecert.sql
-- 

set head off verify off feedback off linesize 111 pagesize 999 
set echo off term off serverout on size 9999 timing off doc off

col c_logfile new_value logfile
select name||'_'||machine||'_IESrecert' c_logfile
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

spool /home/oracle/dbasql/temp/&&logfile..spo

col STATUS for a22
col "Account Type" for a33

set head off
select rpad('-- SID: '||name,88,' --') from v$database ;
set head on 

select USERNAME,
decode(ACCOUNT_STATUS, 'OPEN', 'Keep',ACCOUNT_STATUS) "Status",
decode(PROFILE, 'DEFAULT', 'SYSTEM',
                'PASSWORD_PROFILE_DBA', 'DBA',
                'FOGLIGHT_PROFILE', 'SYSTEM') "Account Type"
from dba_users
where username in
   ('CHEUSA', 'CHOWKE', 'OPS$ORACLE', 'DBSNMP', 'OUTLN', 'SYS', 'SYSTEM',
   'AUDTASK', 'AUD_OWNER', 'DBA_MON', 'DB_TOOLS', 'FOGLIGHT', 'HIDS_AUDITOR', 'WMSYS')
order by 1 ;

spool off


