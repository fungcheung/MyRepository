set pages 999 lines 120 feed on head on echo off term on

