set feedback on
set pages 200 lines 200

prompt For example, to trun on/off ORA-01652 error in alert log in memory level
prompt alter system set events '1652 TRACE NAME ERRORSTACK LEVEL 3' ;;
prompt alter system set events '1652 TRACE NAME ERRORSTACK OFF';;

prompt

prompt To trun on/off ORA-01652 ORA-01653 error in alert log in spfile. Use : to separate ORA errors
prompt alter system set event='1653 TRACE NAME ERRORSTACK LEVEL 3 : 1652 TRACE NAME ERRORSTACK LEVEL 3' scope=spfile ;;
prompt alter system set event='1653 TRACE NAME ERRORSTACK OFF : 1652 TRACE NAME ERRORSTACK OFF' scope=spfile ;;

prompt

prompt To trun off all ORA-errors in alert log in spfile. 
prompt alter system set event='' scope=spfile ;;


prompt
prompt Common ORA- errors
prompt
prompt ORA-00000 normal, successful completion - not an error - but appears that way when creating JAVA SYSTEM
prompt ORA-00001 unique constraint (string.string) violated - RI is good. 
prompt ORA-00018 maximum number of sessions exceeded - send more $$$ to Redwood Shores
prompt ORA-00028 your session has been killed - this is usually accompanied by the sound of a BOFH's evil laugh.
prompt ORA-00054 resource busy and acquire with NOWAIT specified - I hear you knocking but you can't come in.
prompt ORA-00060 deadlock detected while waiting for resource - most likely seen in the Alert log.
prompt ORA-00257 archiver error. Connect internal only, until freed. - larger hard drives tend to delay this problem
prompt ORA-00600 internal error code, arguments: [string], [string], [string], [string], [string], [string], [string], [string]
prompt ORA-00904 Invalid column name
prompt ORA-00942 Table or View does not exist
prompt ORA-01001 invalid cursor - usually due to a lost dial-up connection
prompt ORA-01014 ORACLE shutdown in progress - someone decided to press the red
prompt ORA-1722  Invalid Number (#3) - You get this error when your SQL tries to convert a non-numeric string into a number.
prompt ORA-01000 maximum open cursors exceeded (#23)

prompt ORA-01017 invalid username/password; logon denied 
prompt ORA-01019 unable to allocate memory in the user side - typical for Mac SQL*Net Clients
prompt ORA-01031 insufficient privileges - tried to connect as internal with the wrong password 
prompt ORA-01033 ORACLE initialization or shutdown in progress
prompt ORA-01034 ORACLE not available
prompt ORA-01035 ORACLE only available to users with RESTRICTED SESSION

prompt ORA-01041 internal error. hostdef extension doesn't exist - can get this over bad WAN connection
prompt ORA-01045 user <username> lacks CREATE SESSION privilege; logon denied 
prompt ORA-01078 failure in processing system parameters - rookie DBA tried a new parameter without success - revert to old init.ora 
prompt ORA-01400 cannot insert NULL into (string) - NOT NULL constraint up - column value is NULL
prompt ORA-01401 inserted value too large for column - front end accepts unbounded data. The solution is not to use type LONG. 
prompt ORA-01552 cannot use system rollback segment for non-system tablespace 'string' - need public rollback segs.
prompt ORA-01650 unable to extend rollback segment string by string in tablespace string - datafile size is bounded, either by size or extents 
prompt ORA-01652 unable to extend temp segment by string in tablespace string - datafile size is bounded, either by size or extents 
prompt ORA-12154 TNS:could not resolve service name
prompt ORA-12560 TNS Protocol Adapter error
prompt ORA-03113 end of file on communication channel - many manifestations


