column username format a40
column timestamp format a40
column action_name format a40
column userhost format a40
column returncode format 999,999

SELECT username,timestamp,userhost, returncode
FROM DBA_AUDIT_TRAIL
WHERE 
  ACTION_NAME = 'LOGON'
  AND RETURNCODE > 0
  and TO_CHAR(CAST(timestamp AS DATE) , 'YYYY-MM-DD') >= '2024-01-17' AND TO_CHAR(CAST(timestamp AS DATE) , 'YYYY-MM-DD') < TO_CHAR((TO_DATE('2024-01-18', 'YYYY-MM-DD') + 1), 'YYYY-MM-DD') order by timestamp;



SELECT username,timestamp,action_name, userhost, returncode
FROM DBA_AUDIT_TRAIL
WHERE 
  ACTION_NAME = 'LOGON'
  AND RETURNCODE = 0
  and TO_CHAR(CAST(timestamp AS DATE) , 'YYYY-MM-DD') >= '2023-12-27' AND TO_CHAR(CAST(timestamp AS DATE) , 'YYYY-MM-DD') < TO_CHAR((TO_DATE('2023-12-27', 'YYYY-MM-DD') + 1), 'YYYY-MM-DD');


SELECT username,timestamp,action_name , userhost, returncode
FROM DBA_AUDIT_TRAIL
WHERE 
  ACTION_NAME = 'LOGON'
  AND RETURNCODE = 0
  and TO_CHAR(CAST(timestamp AS DATE) , 'YYYY-MM-DD') >= '2023-12-21' AND TO_CHAR(CAST(timestamp AS DATE) , 'YYYY-MM-DD') < TO_CHAR((TO_DATE('2023-12-22', 'YYYY-MM-DD') + 1), 'YYYY-MM-DD');
  order by timestamp;



