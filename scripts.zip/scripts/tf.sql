-- For sql tunning usage
set timing on
set autotrace trace
alter system flush shared_pool;
alter system flush buffer_cache;

