set verify off
set head off

@gen_views.sql wisapp LKU_WIS_COND
@gen_views.sql wisapp LKU_WIS_DIST
@gen_views.sql wisapp LKU_WIS_FACIGRP
@gen_views.sql wisapp LKU_WIS_FACISUBTYPE
@gen_views.sql wisapp LKU_WIS_FACITYPE
@gen_views.sql wisapp LKU_WIS_FIXTTYPE
@gen_views.sql wisapp LKU_WIS_FOLLOWUP_OPT
@gen_views.sql wisapp LKU_WIS_FUND
@gen_views.sql wisapp LKU_WIS_MAIN_AGT
@gen_views.sql wisapp LKU_WIS_MATL_TYPE
@gen_views.sql wisapp LKU_WIS_PLANTYPE
@gen_views.sql wisapp LKU_WIS_RECTYPE
@gen_views.sql wisapp LKU_WIS_STATUS
@gen_views.sql wisapp LKU_WIS_STRU_ELEM_OPT
@gen_views.sql wisapp LKU_WIS_STRU_ELEM_OPT_DTL
@gen_views.sql wisapp LKU_WIS_UNIT
@gen_views.sql wisapp TBL_WIS_RECSTATUS
@gen_views.sql wisapp RLT_WIS_CONT_FACI
@gen_views.sql wisapp RLT_WIS_FACITYPE_FIXTTYPE
@gen_views.sql wisapp RLT_WIS_FACI_MAIN
@gen_views.sql wisapp RLT_WIS_FACI_PHOTO
@gen_views.sql wisapp RLT_WIS_FACI_UPDATE
@gen_views.sql wisapp RLT_WIS_MAIN_PHOTO
@gen_views.sql wisapp RLT_WIS_PROJ_CONT
@gen_views.sql wisapp TBL_WIS_CONT
@gen_views.sql wisapp TBL_WIS_FACI
@gen_views.sql wisapp TBL_WIS_FACI_PT
@gen_views.sql wisapp TBL_WIS_FACI_ARC
@gen_views.sql wisapp TBL_WIS_FACI_POLY
@gen_views.sql wisapp TBL_WIS_FIXT
@gen_views.sql wisapp TBL_WIS_FOLLOWUP
@gen_views.sql wisapp TBL_WIS_MAIN
@gen_views.sql wisapp TBL_WIS_PHOTO
@gen_views.sql wisapp TBL_WIS_PLAN
@gen_views.sql wisapp TBL_WIS_PMI
@gen_views.sql wisapp TBL_WIS_PROJ
@gen_views.sql wisapp TBL_WIS_STRU_ELEM



