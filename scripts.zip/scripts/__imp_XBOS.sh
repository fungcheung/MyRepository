#### Filename: imp_XBOS.sh

ORACLE_SID=XBOS ; export ORACLE_SID   
ORACLE_HOME=/tpexbosdbp1/export/oracle/product/9.2.0.6 ; export ORACLE_HOME
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ; export PATH

rm -f /tmp/imp_XBOS.pipe
/usr/sbin/mknod /tmp/imp_XBOS.pipe p
zcat /tpexbosdbp1/export/oracle/u0.6/XBOS/backup/expimp/XBOS_fullexp.dmp.Z > /tmp/imp_XBOS.pipe &
imp / file=/tmp/imp_XBOS.pipe log=/tpexbosdbp1/export/oracle/u0.6/XBOS/backup/expimp/imp_XBOS.log \
full=y grants=y buffer=33554432  ignore=y commit=y
rm -f /tmp/imp_XBOS.pipe

