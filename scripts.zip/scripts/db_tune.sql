-- db_tune.sql
-- author : Samson Cheung

set head on verify off feedback off linesize 150 pagesize 999 
set echo off term off serverout on size 9999 doc off timing off

-- alter system set timed_statistics = true ;

break on today
col today noprint new_value _date
select substr(to_char(sysdate,'fmMonth DD, YYYY HH:MI:SS P.M.'),1,35) today
from dual ;

col namex noprint new_value _dbname
select name "namex"  from v$database ;

col blksize noprint new_vue _blksize
select to_number(value) "blksize"  from v$parameter
 where name = 'db_block_size' ;

col c_logfile new_value logfile
select user||'_'||machine||'_tune_'||to_char(sysdate,'rrrrmmdd_hh24:mi:ss') c_logfile
  from v$session 
 where upper(program) like upper('%oracle%')
   and rownum = 1 ; 

## spool /tmp/&&logfile.spo
spool /home/oracle/dbasql/db_tune.spo

select * from v$database  ;
select * from v$version ;

prompt 
prompt --> INIT.ORA Parameters 
prompt 

column name	format a36	heading 'Parameter Name' wrap
column val	format a60	heading 'Value' wrap
select name
      ,lpad(decode(type,1,'Boolean',2,'Character',3,'Integer',4,'File',null),9)
       ||' '||value val
from   v$parameter
order by 1;
		   
prompt 
prompt --> Undocumented Parameters
prompt 

col ksppinm  for a34
col ksppivl for a45

select ksppinm, ksppivl from x$ksppi  
 where substr(ksppinm,1,1) = '_'
 order by 1 ;

prompt 
prompt -- SGA Statistic Listing
prompt 

col bytes for 999,999,999,999
compute sum of bytes on report
break on report
select name, bytes from v$sgastat order by 1 ;

prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Monitor 'Free Memory' (Shared Pool) since it is a CACHE, nothing will 
prompt be aged out until the free memory has been used up. A high value 
prompt of 'Free Memory' can be wasted memory or sometimes it is a symptom 
prompt that a lot of objects have been aged out of the shared pool and 
prompt therefore the SGA is experiencing fragmentation problems.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> DB Block Buffer - Hit Ratio
prompt 

col "Physical Reads"  for  9,999,999,999,999
col "Consistent Gets" for  9,999,999,999,999
col "DB Block Gets"   for  9,999,999,999,999
col "Hit Ratio%"      for  999.99
 
prompt << Percent = (100*(1-(Physical Reads/(Consistent Gets + DB Block Gets)))) >>
prompt 

select pr.value "Physical Reads", cg.value "Consistent Gets", bg.value "DB Block Gets",  
       round((1-(pr.value/(bg.value+cg.value)))*100,2) "Hit Ratio%"
  from v$sysstat pr,  v$sysstat bg,  v$sysstat cg
 where pr.name = 'physical reads'
   and bg.name = 'db block gets'
   and cg.name = 'consistent gets' ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If ratio < 80%, increase DB_BLOCK_BUFFERS.     
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Shared Pool Size - Reloads/Pins Ratio by Class
prompt 

col "Pins" head "Pins(Exec)" for  9,999,999,990
col "Reloads" head "Reloads(Misses)" for 9,999,999,990
col "Ratio%" for 990.99

select namespace, reloads, pins, reloads/decode(pins,0,1,pins)*100 "Ratio%"
  from v$librarycache;

prompt 
prompt --> Shared Pool Size - Reloads/Pins Ratio in ALL
prompt 

col "Pins" head "Pins(Exec)" for  9,999,999,990
col "Reloads" head "Reloads(Misses)" for 9,999,999,990
col "Ratio%" for  990.99

select sum(reloads) "Reloads", sum(pins) "Pins", 
       (sum(reloads)/sum(pins)*100) "Ratio%"
  from v$librarycache ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The ideal is to have zero reloads. If > 0~1%, increase SHARED_POOL_SIZE 
prompt and re-check the figures. If the figures continue to come down, 
prompt continue the SHARED_POOL_SIZE in increments of 5 Meg.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt
prompt --> Shared Pool Size - Dictionary Gets
prompt 

col count for  999,999

select parameter, count, getmisses 
  from v$rowcache
where getmisses > count ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The ideal output would be to see the the getmisses less than or equal 
prompt to the count, which implies that the parameter has been set 
prompt sufficiently high enough to fit all of the dictionary items into 
prompt memory without having to flush them out and then reload them.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

col "Data Dictionary Gets" for  9,999,999,999
col "Get Misses" for  9,999,999,999
col "Ratio%" for 990.99

select sum(gets) "Data Dictionary Gets", sum(getmisses) "Get Misses",
       (sum(getmisses)/sum(gets))*100 "Ratio%"
  from v$rowcache ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The dictionary is tuned automatically by Oracle. 
prompt If % Ratio is above 12%, increase SHARED_POOL_SIZE.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Free Memory % in Shared Pool 
prompt 

col "Comment" for a44 head "Shared Pool Size"
col "% Free" for 990.99 head "% Free"

select 'free memory/Share Pool = '||to_char(s.bytes)||'/'||p.value "Comment", 
        round((S.bytes/P.value)*100,2) "% Free"
from   sys.v_$parameter P, sys.v_$sgastat S
where  S.name = 'free memory'
and    P.name = 'shared_pool_size' ;

select sum(loads),sum(EXECUTIONS),  
       round((sum(loads) / sum(EXECUTIONS)) * 100, 4) "% Load"
from   sys.v_$db_object_cache ;

prompt 
prompt --> Memory Usage of Shared Pool
prompt 

col owner for  a12
col name  for  a36
col sharable_mem for 999,999,999
col loads        for 999,999
col executions   for 999,999,999

select owner, name||' - '||type name, executions, loads, 
       sharable_mem, decode(kept,'NO',null,'Yes') Kept
  from v$db_object_cache
 where ( sharable_mem>10000 or executions>100 or loads>3 )
   and type in ('PACKAGE', 'PACKAGE BODY', 'FUNCTION', 'PROCEDURE')
 order by executions, loads , sharable_mem ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Consider keep the objects in the shared pool or assign the parameters 
prompt SHARED_POOL_RESERVED_SIZE / SHARED_POOL_RESERVED_MIN_ALLOC.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> Datafile Disk I/O s
prompt 

create or replace view tot_read_writes as 
select sum(phyrds) phys_reads, sum(phywrts) phys_wrts
  from v$filestat ;

col name for  a40 
col phyrds for  999,999,999 
col phywrts for  999,999,999 
col read_pct for  999.99 
col write_pct for  999.99
 
select name, phyrds, phyrds * 100 / trw.phys_reads read_pct, 
       phywrts,  phywrts * 100 / trw.phys_wrts write_pct
  from tot_read_writes trw, v$datafile df, v$filestat fs
 where df.file# = fs.file# 
 order by phyrds desc ;

drop view tot_read_writes ;

col "File Name" for  a44
col "File Total" for  999,999,999,990

select substr(df.file#,1,2) "ID",
       substr(name,22,44) "File Name",
       rpad(substr(phyrds,1,10),10,'.') "Phy Reads",
       rpad(substr(phywrts,1,10),10,'.') "Phy Writes",
       rpad(substr(phyblkrd,1,10),10,'.') "Blk Reads",
       rpad(substr(phyblkwrt,1,10),10,'.') "Blk Writes",
       rpad(substr(readtim,1,9),9,'.') "Read Time",
       rpad(substr(writetim,1,10),10,'.') "Write Time",
       rpad(substr((sum(phyrds+phywrts+phyblkrd+phyblkwrt+readtim)),1,10),10,'.') "File Total"
  from v$filestat fs, v$datafile df
 where fs.file# = df.file#
 group by df.file#, df.name, phyrds, phywrts, phyblkrd, phyblkwrt, readtim, writetim
 order by sum(phyrds+phywrts+phyblkrd+phyblkwrt+readtim) desc, df.name ;

prompt 
prompt --> I/O in database blocks by datafile
prompt 

select DF.Name "File Name",
       FS.Phyblkrd Blocks_Read,
       FS.Phyblkwrt Blocks_Written,
       FS.Phyblkrd+FS.Phyblkwrt Total_IOs,
        (FS.Phyblkrd+FS.Phyblkwrt)/Total*100 "Ratio%"
  from V$FILESTAT FS, V$DATAFILE DF,
(select sum(Total_IOs) Total from (
select distinct ts.name Tablespace_name, DF.Name File_Name,
       FS.Phyblkrd Blocks_Read,
       FS.Phyblkwrt Blocks_Written,
       FS.Phyblkrd+FS.Phyblkwrt Total_IOs
  from V$FILESTAT FS, V$DATAFILE DF,sys.fet$ ft,sys.ts$ ts
 where DF.File#=FS.File#
 and FS.File# = ft.File#
 and ft.ts# = ts.ts#))
 where DF.File#=FS.File#
 and (FS.Phyblkrd+FS.Phyblkwrt)>0
 order by FS.Phyblkrd+FS.Phyblkwrt desc;

prompt 
prompt --> I/O in database blocks by tablespace
prompt 

col pctio for 99.99 
select Tablespace_name,sum(Blocks_Read) Blocks_Read, 
    sum(Blocks_Written) Blocks_Written,
    sum(Total_IOs) Total_IOs, sum(Total_IOs)/Total*100 PctIO
from (
select distinct ts.name Tablespace_name, DF.Name File_Name,
       FS.Phyblkrd Blocks_Read,
       FS.Phyblkwrt Blocks_Written,
       FS.Phyblkrd+FS.Phyblkwrt Total_IOs
  from V$FILESTAT FS, V$DATAFILE DF,sys.fet$ ft,sys.ts$ ts
 where DF.File#=FS.File#
 and FS.File# = ft.File#
 and ft.ts# = ts.ts#),
(select sum(Total_IOs) Total from (
select distinct ts.name Tablespace_name, DF.Name File_Name,
       FS.Phyblkrd Blocks_Read,
       FS.Phyblkwrt Blocks_Written,
       FS.Phyblkrd+FS.Phyblkwrt Total_IOs
  from V$FILESTAT FS, V$DATAFILE DF,sys.fet$ ft,sys.ts$ ts
 where DF.File#=FS.File#
 and FS.File# = ft.File#
 and ft.ts# = ts.ts#))
group by Tablespace_name,Total
 order by 4 desc;

prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Ideally the disk I/O's should be even across disks. If the disk I/O on 
prompt one of the disks is too high, consider moving one of the datafiles on 
prompt that disk to another disk. If you are using raw devices, it is handy 
prompt to make the raw devices consistent sizes for this purpose. If you can't 
prompt move one of the datafiles, consider moving objects into tablespaces on 
prompt different disks.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Log Buffer and Redo Log Tuning Information
prompt 

col value for 999,999,999,999
select name, value from v$sysstat
 where name like 'redo%' and value > 0 
 order by 1 ;

prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If the value of 'redo log space requests' is not near 0, 
prompt increase LOG_BUFFER.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The "redo log space wait time" indicates that the user process had to 
prompt wait to get space in the redo file. The closer the value is to zero, 
prompt the better your log buffer is tuned.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Maximum, Minimum and Average time Between Checkpoints
prompt 

col "Mx_pts" head "Max Mins" for  999,999.99
col "Mn_pts" head "Min Mins" for  999,999.99
col "Ag_pts" head "Avg Mins" for  999,999.99

select 
   max(to_number(to_date(lh2.first_time, 'mm/dd/yy hh24:mi:ss') 
           - to_date(lh1.first_time, 'mm/dd/yy hh24:mi:ss'))*24*60) "Mx_pts",
   min(to_number(to_date(lh2.first_time, 'mm/dd/yy hh24:mi:ss') 
           - to_date(lh1.first_time, 'mm/dd/yy hh24:mi:ss'))*24*60) "Mn_pts",
       avg(to_number(to_date(lh2.first_time,'mm/dd/yy hh24:mi:ss') 
           - to_date(lh1.first_time,'mm/dd/yy hh24:mi:ss'))*24*60) "Ag_pts"
 from v$loghist lh1, v$loghist lh2
where lh1.sequence# + 1 = lh2.sequence#
  and lh1.sequence# < (select max (sequence#) from v$loghist ) ;

prompt 
doc 
prompt Minutes Between Checkpoints Listing
select to_number(to_date(lh2.first_time,'mm/dd/yy hh24:mi:ss') 
       - to_date(lh1.first_time,'mm/dd/yy hh24:mi:ss'))*24*60 "Min Mins BW Chkpts"
 from v$loghist lh1, v$loghist lh2
where lh1.sequence# + 1 = lh2.sequence#
  and lh1.sequence# < (select max (sequence#) from  v$loghist )
 group by to_number(to_date(lh2.first_time,'mm/dd/yy hh24:mi:ss') 
       - to_date(lh1.first_time,'mm/dd/yy hh24:mi:ss'))*24*60
 order by 1;
#

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Typically, the minimum time should exceed a few minutes. If the 
prompt switches are less than 30 seconds on a regular basis, enlarge the size 
prompt of the redo log files.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> Redo Thread Log History (count by date)
prompt 

rem #######################################################################
rem	Oracle V8 and above have changed the 'time' col in the
rem	v$log_history table to a 'stamp' column, so change time to stamp
rem	in the following 'Redo Thread Log History (by date)' script if
rem	you are using Oracle V8 and above.
rem #######################################################################

select thread#, substr(time,1,8) "Date", count(substr(time,1,8)) "Count"
  from v$log_history
 where to_date(substr(time,1,8),'mm/dd/yy') > trunc(sysdate-7)
 group by thread#, substr(time,1,8)
 order by thread#, substr(time,1,8) desc ;

prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The 'Count' col is the number of log files created on a certain date.  
prompt If this number is high, it may indicate a need to increase log file 
prompt size and/or look at Archive Log Buffer Blocks and Size parameters.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> System Events
prompt 

col event for a40
col "Ratio%" for 999.9
col "Avg Wait" for 999,999.9

select event, total_waits, total_timeouts,
	 100*(total_timeouts / total_waits) "Ratio%",
	 time_waited, average_wait "Avg Wait"
  from v$system_event
 order by 1 ;

prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Look for 'log file space/switch' parameter to determine 
prompt LOG_BUFFER increase.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Checking any Disk Sorts
prompt 

col name for a40
col value for 999,999,999,990.9
select name, value from v$sysstat
 where name like 'sort%'
union all
select rpad('=',40,'='), 0 from dual
union all
select 'sorts (disk) / sorts (memory) = %%', st1.value/st2.value*100 
  from v$sysstat st1, v$sysstat st2
 where st1.name = 'sorts (disk)' 
   and st2.name = 'sorts (memory)' ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The ideal is to have as much sorting in memory as possible. If there 
prompt is a large amount of sorting being done on disk, consider enlarging 
prompt the SORT_AREA_SIZE. Be aware that this parameter applies to all users 
prompt and there must be sufficient memory to adjust the parameter upwards.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt
doc
     The following query indicates the amount of rollbacks performed
     on the transaction tables. 

(i)  'transaction tables consistent reads - undo records applied'
      is the total # of undo records applied to rollback transaction
      tables only

      It should be < 10% of the total number of consistent changes

(ii) 'transaction tables consistent read rollbacks'
      is the number of times the transaction tables were rolled back

      It should be less than 0.1 % of the value of consistent gets

#
   
prompt 
prompt --> Amount of Rollbacks on Transaction Tables
prompt 

col name for a80
col value for 9,999,999,990.9
select name, value 
  from v$sysstat
 where name in
   ('consistent gets',
    'consistent changes',
    'transaction tables consistent reads - undo records applied',
    'transaction tables consistent read rollbacks') 
union all
select rpad('=',80,'='), 0 from dual 
union all
select 'transaction tables consistent read rollbacks/consistent gets == %%', 
       st1.value/st2.value*100
  from v$sysstat st1, v$sysstat st2
 where st1.name = 'transaction tables consistent read rollbacks'
   and st2.name = 'consistent gets'
   and ( st1.value > 0 and st2.value > 0)
union all
select rpad('=',80,'='), 0 from dual 
union all
select 'undo records applied/consistent changes == %%', 
       st1.value/st2.value*100
  from v$sysstat st1, v$sysstat st2
 where st1.name = 'transaction tables consistent reads - undo records applied'
   and st2.name = 'consistent changes'
   and ( st1.value > 0 and st2.value > 0) ;

select 'Undo Records Applied > 10% of Consistent Changes'||chr(10)||
       'Action: Create more Rollback Segments'
  from v$sysstat
 where decode (name,'transaction tables consistent reads - undo records applied',value)*100
        / decode (name,'consistent changes',value) > 10  
   and name in ('transaction tables consistent reads - undo records applied', 'consistent changes')
   and value > 0 ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If Tran Table Consistent Read Rollbacks > 0.1% of Consistent Gets
prompt Consider create more Rollback Segments
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If Undo Records Applied > 10% of Consistent Changes
prompt Consider create more Rollback Segments
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If either of these scenarios occur, consider creating more rollback 
prompt segments, or a greater number of extents in each rolback segment. 
prompt A rollback segment equates to a transaction table and an extent is like 
prompt a transaction slot in the table. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

select name, value
  from v$sysstat
 where name in
    ('data blocks consistent reads - undo records applied',
     'no work - consistent read gets',   
     'cleanouts only - consistent read gets',
     'rollbacks only - consistent read gets',
     'cleanouts and rollbacks - consistent read gets') ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If the number of rollbacks is continually growing, it can be due to 
prompt inappropriate work practice. Try breaking long running queries into 
prompt shorter queries, or find another method of querying hot blocks in 
prompt tables that are continually changing. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

select usn "Rollback Segs", Gets, Waits, 
       Waits/decode(Gets,0,1,Gets)*100 "Ratio%" , 
       xacts "Active Transactions"
  from v$rollstat ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The query lists the number of waits on a slot in the transaction 
prompt tables. The ideal is to have the waits zero, or as close to zero as 
prompt possible. At the very worst, the ratio of gets to waits should be 
prompt around 99%.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

col OPTSIZE for 999,999,999 head "OptSz Mb"
col HWMSIZE for 9,999,999,999
col AVESHRINK for 9,999,999,999

select USN "Rollback Segs", EXTENDS, SHRINKS, HWMSIZE, AVESHRINK, 
       OPTSIZE/1024/1024 OPTSIZE
  from v$rollstat ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt It is important that rollback segments do not extend very often. 
prompt We usually recommend NOT to use the OPTIMAL setting. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

col name for a70
col value for 9,999,999,990.9
select name, value from v$sysstat 
 where name in ('db block changes', 'rollback changes - undo records applied',
                'transaction rollbacks' )
union all
select rpad('=',70,'='),0 from dual
union all
select 'rollback changes-undo records applied/transaction rollbacks = %% ', 
        st1.value/st2.value*100
  from v$sysstat st1, v$sysstat st2
 where st1.name = 'rollback changes - undo records applied'
   and st2.name = 'transaction rollbacks' ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If 'rollback changes - undo records applied'/'transaction rollbacks' 
prompt is > 0.5%, you should question why are so many rows being rolled back. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 'db block changes' :- amount of overall changes that are made to data 
prompt blocks in the database
prompt 'rollback changes - undo records applied' :- number of blocks that 
prompt have been rolled back
prompt 'transaction rollbacks' :- number of rollback transactions
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> Rollback segmets counts vs Total Requests
prompt 

col "Ratio%" for 990.99
col "totreq" for 999,999,999,999 head "Tot Reqs for Data"

select class, count, ssum "totreq",
       count/st1.ssum*100 "Ratio%"
  from v$waitstat, (select sum(value) ssum from v$sysstat
                     where name in ('db block gets', 'consistent gets')) st1
 where class in ('free list','system undo header', 'system undo block', 
                 'undo header','undo block')
 order by 1,2  ;

prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt if any class count is > 1% of the total number of requests for data
prompt then more rollback segments are needed
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Rollback segmets Status
prompt 

col name for a10
select  V$rollname.NAME "NAME",
        V$rollstat.EXTENTS "EXTENT",
        v$rollstat.RSSIZE,
        v$rollstat.WRITES,
        v$rollstat.GETS,
        v$rollstat.WAITS "WAITS",
        waits/gets*100 "Ratio%",
        v$rollstat.HWMSIZE, 
        v$rollstat.SHRINKS "SHRINKS",
        v$rollstat.WRAPS "WRAPS",
        v$rollstat.AVESHRINK "AVESHRINK",
        v$rollstat.AVEACTIVE "AVEACTIVE",
        v$rollstat.OPTSIZE "OPTSIZE"
   from v$rollname, v$rollstat
  where v$rollname.USN = v$rollstat.USN
  order by v$rollname.USN ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If Ratio% is > 1% then more RBS may be needed.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> Rollback Segment Mapping 
prompt 

select r.name Name, p.pid Oracle_PID, p.spid OS_PID, 
        nvl(p.username,'NO TRANSACTION') Transaction, p.terminal Terminal
  from v$lock l, v$process p, v$rollname r
 where l.addr = p.addr(+)
   and trunc(l.id1(+)/65536)=r.usn
   and l.type(+) = 'TX'
   and l.lmode(+) = 6
 order by r.name ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Current transaction details for each rollback segment.        
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> Latch Contention (Gets and Misses)
prompt 

col name for a30
col "GETS"         for 9,999,999,999
col "MISSES"       for 9,999,999,999
col "WTW Ratio%"   for 990.99
col "SLEEPS"       for 9,999,999,999
col "IMMED_GETS"   for 9,999,999,999
col "IMMED_MISSES" for 9,999,999,999
col "IMMED_RATIO%" for 990.99

select substr(l.name,1,25) name, l.gets "GETS", l.misses "MISSES",
       decode(gets,0,0,(100*(misses/gets))) "WTW Ratio%", sleeps "SLEEPS",
       immediate_gets "IMMED_GETS", immediate_misses "IMMED_MISSES",
       (immediate_misses/(immediate_gets+.001))*100 "IMMED_RATIO%"
  from v$latch l, v$latchname ln
 where l.latch# = ln.latch#
   and ((misses/(gets+.001))*100 > .01 or (immediate_misses/(immediate_gets+.001))*100 > .01 )
order by l.name ;

-- OS process id: 

select a.name,pid from v$latch a , V$latchholder b 
where a.addr=b.laddr 
and a.name = 'library cache%';


prompt
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If the 'willing_to_wait' percentage is > 1% then latch contention 
prompt MAY be occuring. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt REDO SPECIFIC:
prompt If the database is configured to use the 'redo allocation latch'
prompt then the 'willing_to_wait' percentage should not be above 1%.
prompt (Try reducing 'LOG_SMALL_ENTRY_MAX_SIZE' in the init.ora).
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If the database is configured to use the 'redo copy latch' then
prompt the 'willing_to_wait' percentage should be high ie above 70%.
prompt (Try increasing 'log_simultaneous_copies' in the init.ora).
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

prompt 
prompt --> Current Buffer Cache Usage
prompt 

select status, count(*) from v$bh 
 group by status ;

prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If the FREE count is high, say > 50% of overall buffers, you may 
prompt consider decreasing the DB_BLOCK_BUFFERS parameter. Note however, 
prompt that Oracle attempts to maintain a free count > 0, so consistently 
prompt having free buffers does not automatically imply that you should have 
lower the parameter DB_BLOCK_BUFFERS.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt

Doc
The three main states are:
   CUR which is blocks read but not dirtied, 
       (XCUR= exclusive, SCUR= shared current)
    CR which are blocks that have been dirtied and are remaining 
       in cache with the intention of supplying the new values 
       to queries about to start up. 
  FREE indicates buffers that are usable to place new data being read into 
       the buffer cache. 

  READ which are those buffers currently being read from disk into the buffer cache
  MREC in media recovery mode
  IREC in instance recovery mode ?
#

prompt 
prompt --> Detailed Buffer Cache Usage by Objects
prompt 

col owner for  a12;
col segment_type for  a10;
col segment_name for  a30;
col tablespace_name for  a16;
col "Num Buffers" for  9999;

select e.owner, e.segment_type, e.segment_name, 
       tablespace_name, count(*) "Num Buffers"
  from dba_extents e, v$bh b
 where file# / 4 = e.file_id
   and b.block# between e.block_id and e.block_id + e.blocks
 group by e.owner, e.segment_type, e.segment_name, tablespace_name ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Consider setting parameters SORT_DIRECT_WRITES=TRUE or/and 
prompt COMPATIBLE=7.x.x to bypass the buffer cache for some of operations.            
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> Breakdown of what is Currently Being Stored in the Buffer Cache
prompt 

select kind, name, status, count(*) 
  from v$cache
 -- where lower(substr('Look_inside_Buffer_Cache?',1,1))='y'
 group by kind, name, status ;

prompt
doc

The "table fetch row continued rows" have been accessed and the row 
has either been chained or migrated. Both situations result from part 
of a row has been forced into another block. The distinction is for 
chained rows, a block is physically to large to fit in one physical block. 

Migrated rows are rows that have been expanded, and can no longer fit 
into the same block. In these cases, the index entries will point to the 
original block address, but the row will be moved to a new block. The end 
result is that FULL TABLE SCANS will run no slower, because the blocks 
are read in sequence regardless of where the rows are. Index selection 
of the row will cause some degradation to response times, because it 
continually has to read an additional block. To repair the migration 
problem, you need to increase the PCTFREE on the offending table.

The  other values include "table scans (long tables)" which is a scan 
of a table that has > 5 database blocks and table scans (short tables)
which is a count of Full Table Scans with 5 or less blocks. These values
are for Full Table Scans only. Any Full Table Scan of a long table can
be potentially crippling to your application's performance. If the number
of long table scans is significant, there is a strong possibility that
SQL statements in your application need tuning or indexes need to be added.

To get an appreciation of how many rows and blocks are being accessed on
average for the long full table scans:                           

Average Long Table Scan Blocks = 
  table scan blocks gotten - (short table scans * 5) / long table scans


Average Long Table Scan Rows = 
  table scan rows gotten - (short table scans * 5) / long table scans

The output also includes values for "table scan (direct read)" which
are those reads that have bypassed the buffer cache, table scans 
(rowid ranges) and table scans (cache partitions).

#

col name for a40
col value for 9,999,999,990.9
select name, value from v$sysstat
 where name like '%table %' 
 order by 1 ;

CREATE OR REPLACE VIEW cheusa.Full_Table_Scans as 
select ss.username||'('||se.sid||')'||ss.osuser "User Process", 
       sum(decode(name,'table scans (short tables)',value)) "Short Scans",
       sum(decode(name,'table scans (long tables)', value)) "Long Scans",
       sum(decode(name,'table scan rows gotten',value)) "Rows Retreived"
  from v$session ss, v$sesstat se, V$STATNAME sn
 where  se.statistic# = sn.statistic#
   and ( name like '%table scans (short tables)%' OR 
         name like '%table scans (long tables)%'  OR 
         name like '%table scan rows gotten%' )
   and se.sid = ss.sid
   and ss.username is not null
 group by ss.username||'('||se.sid||')'||ss.osuser ;

prompt 
prompt --> Table Access Activity By User
prompt 

col  "User Process"     for  a20;  
col  "Long Scans"       for  999,999,999;   
col  "Short Scans"      for  999,999,999;   
col  "Rows Retreived"   for  999,999,999,999;   
col  "Average Long Scan Length" for  999,999,999;   

select "User Process", "Long Scans", "Short Scans", "Rows Retreived"
  from Full_Table_Scans 
 order by "Long Scans" desc ;

prompt 
prompt --> Average Scan Length of Full Table Scans by User
prompt 

select "User Process", 
       ( "Rows Retreived" - ("Short Scans" * 5))/( "Long Scans" ) "Average Long Scan Length"
  from Full_Table_Scans 
 where "Long Scans" != 0
 order by "Long Scans" desc ;

drop view Full_Table_Scans ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt You should look at increasing the db_block_size.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
doc

The two figures of particular importance are the 'data block' 
and the 'undo header' waits. The undo header indicates a wait 
for rollback segment headers which can be solved by adding 
rollback segments. The data block wait is a little harder to 
find the cause of and a little harder to fix. 

The ideal count on the data block waits is 0, enlarging 
INITRANS can improve performance.

This is usually not achievable in the real world, because 
the storage overhead of increasing the INITRANS is usually 
not justified given the large amount of storage overhead 
that it will introduce. 

Data block contention can cause problems and enlarging 
INITRANS can improve performance, so don't dismiss the idea 
of enlarging INITRANS immediately.

Your best chance is to examine the output from the query 
from the V$SESSION_WAIT table below. You may consider 
increasing the PCTFREE in the table to have fewer rows 
per block, or make a designchange to your application to 
have fewer transactions accessing the sameblock. 

#

prompt 
prompt --> Get All Waits
prompt 

col class for a30
col count for  9999999;
select class, count from v$waitstat order by 1 ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The ideal count on the data block waits is 0, enlarging INITRANS can 
prompt improve performance. Rollback segment headers which can be solved by 
prompt adding rollback segments. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
doc

This can be caused by having to throw another transaction 
slot in the block. 

Remember that eachtransaction slot uses 23 bytes. 

The smaller the DB_BLOCK_SIZE the greater the possibility 
of row migration. The other cause of the locks in the 
following query is that a row within the block are sought 
after by two separate transactions. This problem is usually 
only fixable through an application change, where you 
postpone thechanges to the rows until the last possible 
moment in the transaction. 

#


prompt 
prompt --> Transactions Experiencing Lock Contention
prompt 

select 'TX lock count= '||to_char(count(*)) from v$lock where type = 'TX';
select * from v$lock where type = 'TX';

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt This problem is usually only fixable through an application change.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> The Amount of Times Buffers Have Had to Be Cleaned Out
prompt 

col name for a30
col value for 9,999,999,990.9
select name, value from v$sysstat
 where name like 'DBW%' order by 1 ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt See the parameters LOG_CHECKPOINT_INTERVAL and LOG_CHECKPOINT_TIMEOUT 
prompt which have a direct effect on the regularity of checkpoints. The size 
prompt of your redo logs can also have an effect on the number of checkpoints 
prompt if the LOG_CHECKPOINT_INTERVAL is set to a size larger than your redo 
prompt logs and the LOG_CHECKPOINT_TIMEOUT is longer than the time it takes 
prompt fill a redo log or it has not been set. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

prompt 
prompt --> The Average Length of the Write Request Queue
prompt 

col name for a40
col value for 9,999,999,990.9
select name, value 
  from v$sysstat
 where name in ('summed dirty queue length' ,'write requests')
   and value > 0 
union all
select rpad('=',40,'='),0 from dual
union all
select 'Dirty Queue / Write Requests =  ', st2.value/st1.value
  from v$sysstat st1, v$sysstat st2
 where st1.name = 'write requests'
   and st2.name = 'summed dirty queue length'
   and (st1.value > 0 and st2.value > 0 ) ;

prompt 
doc 

"Dirty Buffers Inspected" indicates that the DBWR process can't keep up 
through natural atrition and a dirty buffer has been aged out through
the LRU queue, when a user process has been looking for a free buffer
to use. 

This value should ideally be zero. The value is probably 
THE key indicator of the DB_BLOCK_BUFFERS init.ora parameter being 
set too small, particularly if you enlarge the DB_BLOCK_BUFFERS 
parameter and the value reduces after each decrease. 

"Free Buffers Inspected" indicates the number of times a user process 
has scanned the LRU list for free buffers. A high value would indicate 
that there are too many dirty blocks on the LRU list and the user 
process had to stop because the dirty queue was at its threshold. 

#

prompt 
prompt --> Lazy DBWR Indicators - Buffers Inspected
prompt 

col value for  999,999,999;

select name, value from v$sysstat
 where name in ('dirty buffers inspected' ,'free buffer inspected')
   and value > 0 ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt "Dirty Buffers Inspected" should ideally be zero. It is probably 
prompt the KEY indicator of the DB_BLOCK_BUFFERS init.ora parameter being 
prompt set too small, particularly if you enlarge the DB_BLOCK_BUFFERS 
prompt parameter and the value reduces after each decrease. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt "Free Buffers Inspected" indicates the number of times a user process 
prompt has scanned the LRU list for free buffers. A high value would indicate 
prompt that there are too many dirty blocks on the LRU list and the user 
prompt process had to stop because the dirty queue was at its threshold. 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 

doc
prompt ~~~~ Oracle Parallel Server Start ~~~~
prompt 
prompt --> Objects which are sharing the same PCM lock
prompt --> NB: Too much, skipped
prompt 

-- run long --
-- SELECT MOD(header_block, ltrim(r.value * 1.5)) lock_no, segment_name, segment_type
--   FROM dba_segments , v$parameter r
--  WHERE name = 'gc_segments'
--    AND segment_type in ('TABLE', 'INDEX', 'CLUSTER')
--  ORDER BY lock_no ;

prompt 
prompt  --> Percentage of physical writes to the database that due to pings.
prompt 

col name for a50
SELECT a.name||' / '||b.name Name, (a.value / b.value) * 100 "Ratio%"
  FROM v$sysstat a, v$sysstat b
 WHERE a.name = 'DBWR cross instance writes'    
    AND b.name  = 'physical writes' ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The nearer to zero the better. Figures as high as 10% usually indicate 
prompt that you should redesign your table or index asscess
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt --> Frequency of each buffer has been pinged out of the buffer cache
prompt 

col file_name for a50
SELECT  df.tablespace_name, df.file_name, SUM(NVL(buf.xnc,0))    "PINGS"
  FROM  dba_data_files df, v$bh buf
 WHERE df.file_id = buf.file#
 GROUP BY df.tablespace_name, df.file_name ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt Design your application to minimize the number of pings
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt --> Index contention
prompt 

col username for a20
col pingname for a20

SELECT  usr.name username, vp.name pingname, vp.kind, SUM(vp.xnc) 
        -- , SUM(vp.lock_element_addr)
  FROM  sys.user$ usr, v$ping vp
 WHERE  vp.owner# = usr.user#
   and  usr.name not in ('SYSTEM', 'SYS', 'PUBLIC')
 GROUP  BY usr.name, vp.name, vp.kind ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If the problem is substantial, it can usually be solved only by 
prompt partitioning the usuage of the index perhjaps by adding an instance 
prompt specific column to the leading part of the index key.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt 1. Number of locks allocated to each blocks class 
prompt 2. Average number of blocks allocated to each class
prompt 

col class for a12
col "AVG" for 990.999
SELECT to_char(class, '999999999') "Class", count(*) "CNT", avg(block_count) "AVG"
FROM  v$lock_element GROUP BY class ;

prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt PCM blocks are used to protect one or more database blocks. They are 
prompt all maintained in the v$lock_element table.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt --> Number of PCM locks being used by the datafile
prompt 

col lock_element_addr for a10 head "Lock Addr"
-- SELECT df.tablespace_name, df.file_name, buf.lock_element_addr, COUNT(*)
--   FROM dba_data_files df, v$bh buf
--   WHERE df.file_id = buf.file#
-- and df.tablespace_name not in ('SYSTEM', 'TEMP')
-- GROUP BY df.tablespace_name, df.file_name, buf.lock_element_addr
-- HAVING COUNT(*) > 1 ;

prompt 
prompt --> Number of PCM locks being used by the datafile (Datafile Level)
prompt 

SELECT df.tablespace_name, df.file_name, COUNT(*)
  FROM dba_data_files df, v$bh buf
 WHERE df.file_id = buf.file#
   AND df.tablespace_name not in ('SYSTEM', 'TEMP')
 GROUP BY df.tablespace_name, df.file_name
HAVING COUNT(*) > 1 ;

prompt 
prompt --> Number of PCM locks being used by the datafile (Tablespace Level)
prompt 

SELECT df.tablespace_name, COUNT(*)
  FROM dba_data_files df, v$bh buf
 WHERE df.file_id = buf.file#
   AND df.tablespace_name not in ('SYSTEM', 'TEMP')
 GROUP BY df.tablespace_name
HAVING COUNT(*) > 1 ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt This example provides you with the count of PCM locks that are locking 
prompt your buffers by data file.
prompt The ideal situation is to have no more than on PCM lock per buffer, but 
prompt this may not always be practical. If you have two or more buffers 
prompt covered by the one PCM lock, false collisions can occur, which can 
prompt adverselly affect performance.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt --> Number of cross instance operations that caused writes to the 
prompt --> database and the number of blocks written.
prompt 

col "Ping Rate" for 990.99
SELECT value / (a.counter + b.counter + c.counter) "Ping Rate"
  FROM v$sysstat, v$lock_activity a, v$lock_activity b, v$lock_activity c
 WHERE a.from_val = 'X' AND a.to_val = 'NULL'
   AND b.from_val = 'X' AND b.to_val = 'S'
   AND c.from_val = 'X' AND c.to_val = 'SSX'
   AND name = 'DBWR cross instance writes' ;

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If "Ping Rate" <1, DBWR is writing fast enough:
prompt no writes to the database are occurring as a result of lock activity
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If Ping Rate = 1, each lock activity that has potential to course a 
prompt write to disk does cause a write to occur.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt If ping rate > 1, false pings a definitely occuring, 
prompt the percentage of prompt false pings is (ping rate -1)/Ping rate *100 
prompt INCREASE your PCM locks.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt 
prompt --> Number of locks per datafile
prompt 

SELECT ts_name "Tablespace", file_name, frequency 
FROM sys.file_ping
ORDER BY frequency  desc, 1,2 ;

col Tablespace for a12 
col FILE_NAME  for a44

prompt 
prompt --> Datafiles are allocated locks via a gc_files_to_locks setting 
prompt 

SELECT ts_name "Tablespace", file_id, file_name, start_lk, nlocks, blocking 
FROM sys.file_lock
ORDER BY 1,2 ;

prompt 
prompt --> Datafiles are NOT allocated locks via a gc_files_to_locks setting 
prompt 

select file_id, tablespace_name, file_name
from dba_data_files
minus
select file_id, ts_name, file_name 
from sys.file_lock
where start_lk > 0
order by tablespace_name, file_id
/

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt The start_lk column indidcates the first lock corresponding to the 
prompt datafile; nlocks is the number of locks allocated to the datafile; 
prompt and blocking is the numer of blocks that each PCM lock protects
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt --> The following query shows the number of global locks. 
prompt --> If you are tuning parallel server and see no reduction in the 
prompt --> figures below, you are wasting your time tuning further.
prompt 

SELECT substr(name, 1, 40), COUNT(*) 
  FROM v$sysstat
 WHERE name LIKE 'global%'
    OR name LIKE 'nxt scns gotten%'
 GROUP BY substr(name, 1, 40);

prompt 
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt "global lock converts (async)" are mostly PCM locks
prompt "global lock converts (non sync)" are mostly used for SCN locks
prompt "global lock gets (non async)" are mostly Table and Transaction locks opens
prompt "global lock releases (async)" are mostly Table and Transaction locks closes
prompt "next scns gotten without going to DLM" are scn locks
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt continue to tune as long as tuning continues to decrease the number of 
prompt locks shown in the output for a consistent level of workload. Reducing 
prompt lock converts will also imporve your scalability.
prompt %-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%-%
prompt 
prompt --> The following query shows the lock conversion ratio. If the ratio 
prompt --> falls below 95% after you have tuned parallel server, it is likely
prompt --> that your site will not scale if you have to add additional nodes
prompt --> and instances.
prompt 

SELECT (a.value - b.value) * 100 / (a.value)  "Lock Conversion Ratio"
  FROM v$sysstat a, v$sysstat b
 WHERE a.name = 'consistent gets'
   AND b.name = 'async lock converts';

select ((a.value + c.value + d.value) -b.value) *100 / (a.value +c.value + d.value) 
       " Lock conversion Ratio"
from v$sysstat a, v$sysstat b, v$sysstat c, v$sysstat d
where a.name = 'consistent gets'
  and b.name = 'async lock converts'
  and c.name = 'db block changes'
  and d.name = 'consistent changes' ;

prompt 
prompt ~~~~ Oracle Parallel Server End ~~~
#

prompt 
prompt  ~~~~ END ~~~~

-- alter system set timed_statistics = false ;

spool off
spool off
exit

set term on feed on

