-- Purpose: List rGIH database tables
-- Authur : James
-- Modified Date: 20171016
-- Version: 0.1

set lines 200
set pages 20000

alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

column owner format a30
column table_name format a30
column status format a10
column last_analyzed format a30



select owner, table_name, status, last_analyzed  
from dba_tables where table_name not like 'S%_IDX$' 
and owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1,2,3,4
/

