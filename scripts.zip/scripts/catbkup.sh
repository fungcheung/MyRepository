#!/bin/sh
. ~/.bash_profile
cd /home/oracle/setup_dg

# Example shell script to perform a nightly full backup of the database and scan for errors
# Copyright (c) 2008, 2014 Caleb.com All Rights Reserved
# This script is provided as an EXAMPLE ONLY and is NOT SAFE to run anywere
# except an expendable test system.
#
# Do not invoke the script with dot-slash, it will not work with RMAN's msgfile, use a full path,
# for example: /home/oracle/rman_backup.sh
# The oracle environment must be set, including ORACLE_HOME, ORACLE_SID and PATH
# Run as the oracle user
# Return code is set at the end to indicate complete success or failure
# A time and date named log file is generated in the script directory
# RMAN-08137: is expected behaviour in a DataGuard environment and is ignored
# It may be desirable to also filter the following errors :
# RMAN-08138: is a byproduct of using an archive log deletion policy
# --------------------------------------------------------------------------------
# Initialization section - set or get parameters for backup
# --------------------------------------------------------------------------------
# Set the maximum number of RMAN-08137 errors to ignore, if exceeded all are reported
MAX_RMAN_08137_IGNORE=5
# Define retention policies to be used for deleting obsolete backups
# eg. 'REDUNDANCY n' or 'RECOVERY WINDOW OF n DAYS'
# This does NOT set the persistent setting, only what is deleted by this script!
# TEST! - set retention policy appropriately for production (eg. 7 and 31 days)

# DISK_RETENTION_POLICY='RECOVERY WINDOW OF 7 DAYS'
DISK_RETENTION_POLICY='REDUNDANCY=1'

# Generate a unique log file name and initialize
LOGFILE=${0}_`date +%F_%H%M%S`_$HOSTNAME\_$ORACLE_SID.out
echo -e "\n***\n*** Backup script started at `date`\n***\n" >> $LOGFILE
chmod 666 $LOGFILE
# Scan and error files are for temporary output
TMPFILE=${0}_TMPFILE_$HOSTNAME\_$ORACLE_SID.out
ERRFILE=${0}_ERRFILE_$HOSTNAME\_$ORACLE_SID.out
# Set NLS parameters to keep output readable
export NLS_DATE_FORMAT='dd-mon-yy hh24:mi:ss'
export NLS_LANG=AMERICAN_AMERICA.AL32UTF8
# The backups will be taged so they can be easily identified for reporting.
# The prefix will indicate the backup type (eg. DB incremental level, archive log or control/spfile).
# The suffix is a numeric time and date stamp to uniquely identify this backup.
# The teme/date stamp is the same for all steps of this backup and indicates the backup start time.
BACKUP_TAG_SUFFIX="`date +%y%m%d_%H%M`"
# --------------------------------------------------------------------------------
# Perform the RMAN backup to disk
# --------------------------------------------------------------------------------
#
# Build command string to execute RMAN
#
# The backup itself is in three separate pieces for manageability, and the fact that
# we want one last control file backup with an up-to-date repository AFTER everything
# else is finished. The CHECK LOGICAL opton is used to perform validation of the
# database on the way out. INCREMENTAL LEVEL 0 is used to pave the way for possible
# future incremental backups, it is equivalent to a full backup.
#
# It is important to verify the persistent settings. Other people can mess with
# these, so at minimum we should know what they are, and we should probably
# explicitly set them to known values here to override any outside changes.
#
# Adjust the retention policy as desired, and refer to discussion about recovery
# window vs. redundancy. The specification in the delete obsolete command overrides
# the persistent setting, but doesn't stop someone else from deleting outside this script,
# or Oracle from reclaiming space as necessary - this will go by the persistent setting.
#
# There is a lot of controversy over both the crosscheck and the delete obsolete.
# I maintain that the crosscheck backup is valid and necessary to identify missing files,
# and the crosscheck alone (without delete expired) does no harm. Without
# the crosscheck, REPORT NEED BACKUP would miss datafiles who's backup has
# gone missing, and remaining older good copies would be deleted as obsolete.
# However, crosscheck archivelog should NOT EVER be used in the script because
# it will silently allow the backup to proceed with missing archive logs! Similarly,
# DO NOT use SKIP INACCESSIBLE in the backup script.
#
# Delete obsolete is arguable, I like it to keep the FRA cleaned out so I can "see"
# how much free space there is. By deleting old backups that have past the retention
# policy it is remotely conceivable that we are loosing a slim "last resort" recovery
# position if all our "good" backups are corrupt or missing.
#
# The use of DELETE INPUT (and NOT delete ALL input) is the best way to manage
# archive logs. This will delete one copy of each archive log after it is backed up,
# and only of DataGuard does not still need it. Time based or manual methods can
# delete archive logs still required for gap resolution thus destroying a standby DB.
#
# FILESPERSET is also arguable, some say it should be 1 to speed up restore of
# a single file, the values here are a compromise to keep the number of individual
# backup set pieces manageable.
#
# One last note: this backup strategy is absolutely NOT appropriate for a data
# de-duplication device (eg. DataDomain). It requires an entirely different set
# of parameters, otherwise de-duplication will NOT occurr as expected.
#
CMD_STR="
rman target / nocatalog msglog $LOGFILE append << EOF
#
# Verify persistent settings
#
SHOW ALL;
#
# Crosscheck for missing files and delete obsolete FRA files.
#
ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK;
CROSSCHECK BACKUP DEVICE TYPE DISK;
HOST 'echo -e \"\n\nListing EXPIRED Backups...\n==========================\n\"';
LIST EXPIRED BACKUP;
HOST 'echo -e \"\n\nDeleting OBSOLETE Backups...\n============================\n\"';
DELETE NOPROMPT OBSOLETE $DISK_RETENTION_POLICY DEVICE TYPE DISK;
RELEASE CHANNEL;
#
# Perform the backup in three individual steps: database, archivelogs and controlfile
#
RUN {
#
# Step 1: Backup the database to the Flash Recovery Area
#
ALLOCATE CHANNEL ds00 DEVICE TYPE DISK MAXPIECESIZE 32G;
#ALLOCATE CHANNEL ds01 DEVICE TYPE DISK MAXPIECESIZE 32G;
#ALLOCATE CHANNEL ds02 DEVICE TYPE DISK MAXPIECESIZE 32G;
#ALLOCATE CHANNEL ds03 DEVICE TYPE DISK MAXPIECESIZE 32G;
# Backup the database according to the incremental level specification
BACKUP
 AS COMPRESSED BACKUPSET CHECK LOGICAL
 INCREMENTAL LEVEL 0
 TAG 'DATABASE_${BACKUP_TAG_SUFFIX}'
 FILESPERSET 5
 DATABASE;
# Although this may be redundant, ensure any archive logs written
# during the DB backup are archived (including RAC)
SQL 'ALTER SYSTEM ARCHIVE LOG CURRENT';
#
# Step 2: Backup the archive logs as a separate operation so
# the backup sets can have their own unique tags
#
BACKUP
 AS COMPRESSED BACKUPSET CHECK LOGICAL
 TAG 'ARCHIVELOG_${BACKUP_TAG_SUFFIX}'
 FILESPERSET 20
 ARCHIVELOG ALL
 DELETE INPUT;
#
# Step 3: Make one final copy of the control file to ensure all
# just completed backup information is included
#
BACKUP
 TAG 'CONTROLFILE_`date +%y%m%d_%H%M`'
CURRENT CONTROLFILE SPFILE;
RELEASE CHANNEL ds00;
#RELEASE CHANNEL ds01;
#RELEASE CHANNEL ds02;
#RELEASE CHANNEL ds03;
}
#
# Check to see if anything is unrecoverable
#
REPORT SCHEMA;
REPORT UNRECOVERABLE;
REPORT NEED BACKUP;
LIST BACKUP SUMMARY;
EOF
"
#
# Execute RMAN and capture the return code
#
echo -e "\n***\n*** The following is the RMAN backup command to be executed\n***\n" >> $LOGFILE
echo "$CMD_STR" >> $LOGFILE
echo -e "\n***\n*** The following is output of the RMAN backup command\n***\n" >> $LOGFILE
/bin/sh -c "$CMD_STR" >> $LOGFILE
CMD_STAT=$?
EXIT_STAT=$CMD_STAT
# Test the return code
if [ "$CMD_STAT" = "0" ]
then
LOGMSG="successfully"
else
LOGMSG="in error"
fi
# Log completion message
echo >> $LOGFILE
echo Recovery Manager ended $LOGMSG >> $LOGFILE
echo >> $LOGFILE
#
# Perform a separate manual backup of the control and spfile
# This is especially important if we are NOT using a recovery catalog so
# that there is an easy to find copy of the control file with RMAN repository.
# Also, display information about the FRA configuration, space utilization,
# control file location and finally the precious DBID if we have to do a full restore!
#
CMD_STR="
sqlplus / as sysdba >> $LOGFILE << EOF
ALTER DATABASE BACKUP CONTROLFILE TO TRACE;
ALTER DATABASE BACKUP CONTROLFILE TO TRACE AS '$ORACLE_HOME/dbs/controlfile_trace_$ORACLE_SID.backup' REUSE;
ALTER DATABASE BACKUP CONTROLFILE TO '$ORACLE_HOME/dbs/controlfile_$ORACLE_SID.backup' REUSE;
CREATE PFILE='$ORACLE_HOME/dbs/pfile_$ORACLE_SID.backup' FROM SPFILE;
SELECT * FROM v\\\$flash_recovery_area_usage;
SHOW PARAMETER recovery
SHOW PARAMETER control_file
SELECT dbid FROM v\\\$database;
EXIT
EOF
"
# Execute SQL*Plus command and capture return code
echo -e "\n***\n*** The following is the SQL command to be executed\n***\n" >> $LOGFILE
echo "$CMD_STR" >> $LOGFILE
echo -e "\n***\n*** The following is output of the SQL command\n***\n" >> $LOGFILE
/bin/sh -c "$CMD_STR" >> $LOGFILE
CMD_STAT=$?
# Test the return code
if [ "$CMD_STAT" = "0" ]
then
LOGMSG="successfully"
else
LOGMSG="in error"
EXIT_STAT=$CMD_STAT
fi
# Log completion message
echo >> $LOGFILE
echo Control File + SPfile manual backup ended $LOGMSG >> $LOGFILE
echo >> $LOGFILE
# --------------------------------------------------------------------------------
# Scan the log file for errors and report here
# --------------------------------------------------------------------------------
# This is where we should be sending an email to the DBA announcing the status
# of the backup job, and reporting any errors detected
# NOTE the following RMAN error message is expected behavour with DataGuard:
# RMAN-08137: WARNING: archive log not deleted as it is still needed
# This may trigger unnecessary error return codes from this script, however,
# If we simply ignore it, we could be missing a potentially serious condition if
# none of the archive logs are being deleted because of a gap problem
#
# If there are just a few RMAN-08137 errors, then ignore them
if [ `grep -c RMAN-08137 $LOGFILE` -gt $MAX_RMAN_08137_IGNORE ]
then
cat $LOGFILE > $TMPFILE
else
sed '/RMAN-08137/d' $LOGFILE > $TMPFILE
fi
# Scan the logfile for remaining errors
egrep -i "ORA-|RMAN-|TNS-|PLS-|PROT-|ERROR|WARNING|FAILED|'EXPIRED'" -B 3 -A 3 $TMPFILE > $ERRFILE
CMD_STAT=$?
# Produce the error summary with a header to make it visually obvious
echo >> $LOGFILE
echo >> $LOGFILE
echo "***********************************************************************************" >> $LOGFILE
echo Error summary follows >> $LOGFILE
echo "***********************************************************************************" >> $LOGFILE
echo >> $LOGFILE
# If the return code is 0 then egrep found something, log the result and set the return code
if [ "$CMD_STAT" = "0" ]
then
echo Errors detected in log file >> $LOGFILE
echo >> $LOGFILE
cat $ERRFILE >> $LOGFILE
EXIT_STAT=1
else
echo NO errors detected in log file, manual review suggested >> $LOGFILE
fi
#
# Set the final return code for exit
#
echo -e "\n***\n*** Backup script ended at `date`\n***\n" >> $LOGFILE
echo Exiting with return code $EXIT_STAT >> $LOGFILE
#
# Send an email with status of the backup
# If there were errors, they will be included in the body of the email
#
if [ "$EXIT_STAT" == "0" ]
then
SUBJECT="Oracle Backup SUCCEEDED on `hostname`"
else
SUBJECT="Oracle Backup FAILED on `hostname`"
fi
# Substitute your own email script command here
# /g01/scripts/your_sendmail_scipt_here.pl "$ERRFILE" "$FROM" "$SUBJECT" "$TO"
exit $EXIT_STAT
# Copyright (c) 2008, 2014 Caleb.com All Rights Reserved.

