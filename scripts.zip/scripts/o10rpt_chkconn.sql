-- filename: orarpt_chkconn.sql

col c_logfile new_value logfile
select name||'_'||machine||'_chkconn' c_logfile
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

spool /home/oracle/dbasql/temp/&&logfile..spo
set feed off head off

select to_char(sysdate, 'RRRRMMDD HH:MI:SS') from dual ;
select 'Connect: '||user||' \ '||instance_name||' \ '||host_name||' \ '||version from v$instance
union all
select 'Uptime : '||floor(xx)||'days '||floor((xx-floor(xx))*24)||'hours '||round(((xx-floor(xx 
)*24)-floor((xx-floor(xx)*24)))*60)||'minutes'||chr(10)||' ' "Database Uptime" 
from (select host_name,instance_name ,(sysdate-STARTUP_TIME) xx from v$instance)  ;

set feed on head on
spool off

