
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "RVIEW"."VW_KEYMAS_PT" ("CAT_ID", "REC_TYPE", "UNIQUEFIELD", "UNIQUEID", "REC_CAT", "ENAME", "CNAME", "EADDRESS", "CADDRESS", "ENAME_PAD", "CNAME_PAD", "EADDRESS_PAD", "CADDRESS_PAD", "SHAPE") AS 
  /*SELECT (CASE 
WHEN cat_abbr IN ('BBQ','CAMPSITE','HC','LHC','VC') OR mapfaci_type IN ('CAM') THEN 31 
WHEN cat_abbr IN ('LIBRARY','MUSEUM','PV') OR mapfaci_type IN ('SCU','SIG','SSR','VPT','3HV') THEN 32 
WHEN cat_abbr IN ('PARKS','RG','BC','BEACH','BMINC','BOWL','CHILD','CYCSITE','FITNESS','GOLF','GP','OHSP','PAA','PRS','SC','SG','SP','SQUASH','STADIUM','TC','TENNIS','WSC') OR mapfaci_type IN ('AMK','TNC','3UX','OSA','RCO') THEN 34 
WHEN cat_abbr IN ('OFACI') THEN 36 
WHEN mapfaci_type IN ('CHU','MON','MOS','RPS','SMY','SYN','TMP') THEN 37 
WHEN cat_abbr IN ('KG','KG_CCC') THEN 38 
WHEN cat_abbr IN ('AIDED_PRS','DSS_PRS','ESF_PRS','GOVT_PRS','IS_PRS','PRI_PRS') THEN 39 
WHEN cat_abbr IN ('AIDED_SES','CAPUT_SES','DSS_SES','ESF_SES','GOVT_SES','IS_SES','PRI_SES') THEN 40 
WHEN cat_abbr IN ('AIDED_SPS') OR mapfaci_type IN ('VTI') THEN 41 
WHEN cat_abbr IN ('ASFPS','UGC') THEN 42 
WHEN cat_abbr IN ('ILSP','JC') OR mapfaci_type IN ('LRE') THEN 43 
WHEN cat_abbr IN ('MSO') OR mapfaci_type IN ('DLO','LRY') THEN 44 
WHEN cat_abbr IN ('FSAD','OFSF') THEN 45 
WHEN mapfaci_type IN ('CMS','CST') THEN 46 
WHEN mapfaci_type IN ('ICA') THEN 47 
WHEN mapfaci_type IN ('JUD') THEN 48 
WHEN cat_abbr IN ('OFCE') OR mapfaci_type IN ('GOF') THEN 49 
WHEN cat_abbr IN ('POLICE','PRR') OR mapfaci_type IN ('PPT','PSN') THEN 50 
WHEN mapfaci_type IN ('CSD') THEN 51 
WHEN mapfaci_type IN ('BDC') THEN 52 
WHEN cat_abbr IN ('CLINIC','CLINIC_HEALTH') THEN 53 
WHEN cat_abbr IN ('HEERC', 'CMCTR') THEN 54 
WHEN cat_abbr IN ('HOSPITAL') OR mapfaci_type IN ('HOS','3AE') THEN 55 
WHEN cat_abbr IN ('RP') THEN 56 
WHEN cat_abbr IN ('CSSP') THEN 57 
WHEN cat_abbr IN ('CCSPP') THEN 58 
WHEN cat_abbr IN ('DO','MPO','PO','SPB') THEN 59 
WHEN cat_abbr IN ('CHCC','DOSO','LBA','PESC') THEN 60 
WHEN cat_abbr IN ('CSTEC','RRU','SSCEC') THEN 61 
WHEN cat_abbr IN ('ELDERLY','SCCO') THEN 62 
WHEN cat_abbr IN ('CCC','CH','EHS','MHCCC','NSCCP','OCCS','YOUTH') THEN 63 
WHEN cat_abbr IN ('MSS') THEN 64 
WHEN cat_abbr IN ('CAAB','CASD','CISU','CRDC','CRN','DAC','DSCPD','EETC','HMMH','HSMH','HSPH','HSPH_MH','HWH','HWH_SP','ICCMW','IRSC','IVRSC','IVTC','LSCH','MSC','PRC','RSCCC','RTC','SCCC','SHOS','SRCS','SW','TCSC') THEN 65 
WHEN cat_abbr IN ('CLEICS','DSWO','IFS','SS','SSAB','TAVAS') THEN 66 
WHEN cat_abbr IN ('BDR','BO','HQ','MR','ROPO','IRO') THEN 67 
WHEN cat_abbr IN ('CP') THEN 68 
WHEN cat_abbr IN ('AQMN','CSC','EERC','IAQ') THEN 69 
WHEN cat_abbr IN ('DO_NGO') THEN 72 
WHEN cat_abbr IN ('DCTC','DTC','LO','VEC') THEN 73 
WHEN mapfaci_type IN ('MTA','LRA','RSN') THEN 76 
WHEN mapfaci_type IN ('FER','FET') THEN 77 
WHEN mapfaci_type IN ('AIR','CBC','HLP') THEN 78 
WHEN mapfaci_type IN ('CPI','CPM','CPO','3CP','OSP','PAR','RGD') THEN 80 
WHEN mapfaci_type IN ('LPG','PFS') THEN 81 
WHEN cat_abbr IN ('GOVWIFI','WIFI') THEN 82 
WHEN cat_abbr IN ('LG','LHF','LHTL') OR mapfaci_type IN ('TAN','YHL') THEN 83 
WHEN mapfaci_type IN ('CEM','CRE','FUN') THEN 84 
WHEN mapfaci_type IN ('BAZ','CFS','CVS','MAL','MKT','SMK','WMT','3CC') THEN 85 
WHEN cat_abbr IN ('HKJCDIC','POS') OR mapfaci_type IN ('CCS','CTR','FLO','FLR','PAG','PIE','RCP','TOI','TTH','VOF') THEN 87 
END) AS cat_id, CAST('FACI' AS NVARCHAR2(10)) AS rec_type, 
(CASE WHEN add_id IS NULL THEN 'MSLINK' ELSE 'ADD_ID' END) AS uniquefield, 
CAST(CASE WHEN add_id IS NULL THEN mapfaci_mslink ELSE add_id END AS NVARCHAR2(20)) AS uniqueid, 
CAST(CASE WHEN cat_abbr IS NULL THEN mapfaci_type ELSE cat_abbr END AS NVARCHAR2(10)) AS rec_cat, 
mapfaci_ename AS ename, mapfaci_cname AS cname, mapfaci_eaddress AS eaddress, mapfaci_caddress AS caddress, 
UPPER(mapfaci_ename) AS ename_pad, UPPER(mapfaci_cname) AS cname_pad, UPPER(mapfaci_eaddress) AS eaddress_pad, UPPER(mapfaci_caddress) AS caddress_pad, shape FROM gih3_map_faci_name_point WHERE mapfaci_type NOT IN ('3DP','DM','NRA') OR cat_abbr NOT IN ('CTRY_PARK','MAR_PARK','MAR_RES') 
UNION ALL */
SELECT 3 AS cat_id, CAST('PLACE' AS NVARCHAR2(10)) AS rec_type, 'GEONAMEID' AS uniquefield, CAST(geonameid AS NVARCHAR2(20)) AS uniqueid, CAST(TYPE AS NVARCHAR2(10)) AS rec_cat, englishname AS ename, chinesename AS cname, NULL AS eaddress, NULL AS caddress, englishname_pad AS ename_pad, chinesename_pad AS cname_pad, NULL AS eaddress_pad, NULL AS caddress_pad, shape FROM b10k_geoname_point 
UNION ALL 
SELECT 31 AS cat_id, CAST('FACI' AS NVARCHAR2(10)) AS rec_type, 'POST_ID' AS uniquefield, CAST(post_id AS NVARCHAR2(20)) AS uniqueid, CAST('DP' AS NVARCHAR2(10)) AS rec_cat, 'Distance Post ' || post_id AS ename, '標距柱 ' || post_id AS cname, NULL AS eaddress, NULL AS caddress, UPPER('Distance Post ' || post_id) AS ename_pad, UPPER('標距柱 ' || post_id) AS cname_pad, NULL AS eaddress_pad, NULL AS caddress_pad, shape FROM afcd_dp_point 
UNION ALL 
SELECT 71 AS cat_id, CAST('FACI' AS NVARCHAR2(10)) AS rec_type, 'OVT_ID' AS uniquefield, CAST(ovt_id AS NVARCHAR2(20)) AS uniqueid, CAST('OVT' AS NVARCHAR2(10)) AS rec_cat, registration_no AS ename, registration_no AS cname, eaddress, caddress, registration_no AS ename_pad, registration_no AS cname_pad, eaddress_pad, caddress_pad, shape FROM lcsd_ovt_point 
UNION ALL 
SELECT 86 AS cat_id, CAST('UTIL' AS NVARCHAR2(10)) AS rec_type, 'UTILITYPOINTID' AS uniquefield, CAST(utilitypointid AS NVARCHAR2(20)) AS uniqueid, CAST(utilitypointtype AS NVARCHAR2(10)) AS rec_cat, utilitynumber AS ename, utilitynumber AS cname, NULL AS eaddress, NULL AS caddress, UPPER(utilitynumber) AS ename_pad, UPPER(utilitynumber) AS cname_pad, NULL AS eaddress_pad, NULL AS caddress_pad, shape FROM b1k_utilpoint_num_pt where utilitypointtype not in ('FWH','SWH','LPO') 
UNION ALL 
SELECT 88 AS cat_id, CAST('UTIL' AS NVARCHAR2(10)) AS rec_type, 'UTILITYPOINTID' AS uniquefield, CAST(utilitypointid AS NVARCHAR2(20)) AS uniqueid, CAST(utilitypointtype AS NVARCHAR2(10)) AS rec_cat, utilitynumber AS ename, utilitynumber AS cname, NULL AS eaddress, NULL AS caddress, UPPER(utilitynumber) AS ename_pad, UPPER(utilitynumber) AS cname_pad, NULL AS eaddress_pad, NULL AS caddress_pad, shape FROM b1k_utilpoint_num_pt where utilitypointtype in ('LPO') 
UNION ALL 
SELECT 89 AS cat_id, CAST('UTIL' AS NVARCHAR2(10)) AS rec_type, 'UTILITYPOINTID' AS uniquefield, CAST(utilitypointid AS NVARCHAR2(20)) AS uniqueid, CAST(utilitypointtype AS NVARCHAR2(10)) AS rec_cat, utilitynumber AS ename, utilitynumber AS cname, NULL AS eaddress, NULL AS caddress, UPPER(utilitynumber) AS ename_pad, UPPER(utilitynumber) AS cname_pad, NULL AS eaddress_pad, NULL AS caddress_pad, shape FROM b1k_utilpoint_num_pt where utilitypointtype in ('FWH','SWH') 
/*
TD dataset not yet have consent to be released
UNION ALL 
SELECT 80 AS cat_id, CAST('FACI' AS NVARCHAR2(10)) AS rec_type, 'OSP_ID' AS uniquefield, CAST(osp_id AS NVARCHAR2(20)) AS uniqueid, CAST('OSP' AS NVARCHAR2(10)) AS rec_cat, 'On-street parking space: ' || street_name_en AS ename, '路旁泊車位: ' || street_name_ch AS cname, address_en AS eaddress, address_ch AS caddress, UPPER('On-street parking space: ' || street_name_en) AS ename_pad, UPPER('路旁泊車位: ' || street_name_ch) AS cname_pad, UPPER(address_en) AS eaddress_pad, UPPER(address_ch) AS caddress_pad, shape FROM td_osp_point 
UNION ALL 
SELECT 80 AS cat_id, CAST('FACI' AS NVARCHAR2(10)) AS rec_type, 'OFFSP_ID' AS uniquefield, CAST(offsp_id AS NVARCHAR2(20)) AS uniqueid, CAST('OFFSP' AS NVARCHAR2(10)) AS rec_cat, build_name_en AS ename, build_name_ch AS cname, address_en AS eaddress, address_ch AS caddress, UPPER(build_name_en) AS ename_pad, UPPER(build_name_ch) AS cname_pad, UPPER(address_en) AS eaddress_pad, UPPER(address_ch) AS caddress_pad, shape FROM td_offsp_point 
*/;

CREATE OR REPLACE FORCE EDITIONABLE VIEW "RVIEW"."VW_KEYMAS_GM" ("CAT_ID", "REC_TYPE", "UNIQUEFIELD", "UNIQUEID", "REC_CAT", "ENAME", "CNAME", "EADDRESS", "CADDRESS", "ENAME_PAD", "CNAME_PAD", "EADDRESS_PAD", "CADDRESS_PAD", "ADL_SEARCH02_EN", "ADL_SEARCH02_CH", "FLD_SEARCH02_EN", "FLD_SEARCH02_CH", "EDISTRICT", "CDISTRICT", "EFACITYPE", "CFACITYPE", "SHAPE") AS 
  SELECT  cat_id, CAST('FACI' AS NVARCHAR2(10)) AS rec_type, 
'FACI_ID' AS uniquefield, FACI_ID AS uniqueid, FACI_TYPE AS rec_cat, 
ename, cname, eaddress, caddress, 
UPPER(ename) AS ename_pad, UPPER(cname) AS cname_pad, UPPER(eaddress) AS eaddress_pad, UPPER(caddress) AS caddress_pad, 
adl_search02_en, adl_search02_ch, fld_search02_en, fld_search02_ch, EDISTRICT, CDISTRICT, EFACITYPE, CFACITYPE, shape FROM vw_gm_faci_identify;
