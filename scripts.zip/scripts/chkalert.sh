set -x 
date
grep ORA- /data/oracle/TWXBOS/home/admin/bdump/alert_TWXBOS.log
ls -ltr /data/oracle/TWXBOS/home/admin/bdump/alert_TWXBOS.log
pwd

