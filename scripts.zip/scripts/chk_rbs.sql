-- Filename: chk_rbs.sql

-- spool C:\0Tasks\dbasql\chk_rbs.spo
spool chk_rbs.spo

set lines 100 doc off

set head off
select 'Database: '||name||' as at '||sysdate  from v$database; 
set head on

col owner for a10
col segment_name for a33
col seg_bytes for 99,999 head "Tot_Seg_Mb"
col rbs_bytes for 99,999 head "Max_Rbs_Mb"

prompt 
prompt << Tables size > RBS size >>
prompt 

select  dsg.owner, dsg.segment_name, dsg.bytes/1024/1024 seg_bytes, drs.mx_bytes/1024/1024  rbs_bytes
from dba_segments dsg, 
( select decode( sign(tab1.mx_bytes - tab2.mx_bytes),-1 , tab1.mx_bytes, tab2.mx_bytes ) mx_bytes
from 
( select SEGMENT_NAME, (INITIAL_EXTENT + (MAX_EXTENTS -1)*NEXT_EXTENT ) mx_bytes 
from dba_rollback_segs
where SEGMENT_NAME <>  'SYSTEM'
and STATUS = 'ONLINE'
and rownum <= 1  ) tab1,
( select tablespace_name , sum(BYTES) mx_bytes from dba_data_files
where tablespace_name = (
select TABLESPACE_NAME from dba_segments
where segment_type = 'ROLLBACK' 
and tablespace_name <> 'SYSTEM' 
and rownum <= 1  ) 
group by tablespace_name ) tab2 ) drs
where dsg.bytes/1024/1024 > drs.mx_bytes/1024/1024  
and owner not in ('SYSTEM','SYS')
and dsg.segment_type = 'TABLE' ;

prompt 
prompt << RBS Information >>
prompt 

col na  format a30 heading 'Rollback Name|Tablespace Name|Owner'
col nam format a30 heading 'Rollback Segment Name'
col sta format a9 heading 'Status'
col typ format a4 heading 'Type'
col sta_order format 9 noprint 
col K format 99,999,999 heading 'Size (K)'
col exts  format 9999 heading 'Used|Exts'
col maxe  format 9,999,999,999 heading 'Max|Exts'
col inite format 99,999 heading 'Initial|Ext (K)'
col mine  format 9,999 heading 'Min|Exts'
col nxte  format 99,999 heading 'Next|Exts (K)'
col flag  format a1 heading ' '
col optsize format 999,999,999 heading 'Optimal|Size'

-- select rpad(undo.name,20,' ')||rpad(ts.name,20,' ')||us.name na, 
select undo.name||' / '||ts.name||' / '||us.name na, 
       decode(undo.status$,1,'Invalid',2,'Avail', 3,'Online', 4,'Offline', 5,'Needs Recovery') sta,
       decode(undo.status$,1,4, 2,2, 3,1, 4,3, 5,5) sta_order,
       seg.blocks*ts.blocksize/1024 K, seg.minexts mine, seg.extents exts, seg.maxexts maxe,
	 seg.iniexts*ts.blocksize/1024 inite, seg.extsize * ts.blocksize/1024 nxte,
       decode(sign(seg.maxexts-seg.extents-5),-1,'*',' ') flag
  from sys.seg$ seg, sys.undo$ undo, sys.ts$ ts, sys.user$ us
 where seg.file# = undo.file#
   and seg.block# = undo.block#
   and ts.ts# = seg.ts#
   and seg.user# = us.user#
 -- order by 3,ts.name
 order by 1,ts.name ;


prompt 
prompt << RBS are being used >>
prompt 

col name     format a10
col usn      format 99        heading "ID"
col osuser   format a8
col username format a12
col SID      format 9999
col extents  format 9999      heading Ext
col optsize  format 99999     heading Opt
col hwmsize  format 99999999  heading HWM
col waits    format 9999      heading Waits
col shrinks  format 9999      heading Shk
col wraps    format 9999      heading Wrap

select r.usn, r.name, s.osuser, s.username,s.sid, x.extents, 
       x.optsize/1024 Optsize, x.hwmsize/1024 hwmsize, 
       x.waits, x.shrinks, x.wraps
 from sys.v_$rollstat X, sys.v_$rollname R, sys.v_$session S, sys.v_$transaction T
 where t.addr = s.taddr (+)
   and x.usn (+) = r.usn
   and t.xidusn (+) = r.usn
 order by r.name ;

spool off

-- prompt host write C:\0Tasks\dbasql\chk_rbs.spo
-- prompt 


doc
-- check creation date/time of rbs
select b.segment_name, a.ctime 
from dba_rollback_segs b, obj$ a 
where a.obj#=b.segment_id

select   
   substr(a.os_user_name,1,8)    "OS User" 
 , substr(a.oracle_username,1,8) "DB User" 
 , substr(b.owner,1,8)  "Schema" 
 , substr(b.object_name,1,20)    "Object Name" 
 , substr(b.object_type,1,10)    "Type" 
 , substr(c.segment_name,1,5)  "RBS" 
 , substr(d.used_urec,1,12)      "# of Records" 
from v$locked_object a, dba_objects b, dba_rollback_segs c, v$transaction d, v$session e 
where a.object_id =  b.object_id 
  and a.xidusn    =  c.segment_id 
  and a.xidusn    =  d.xidusn 
  and a.xidslot   =  d.xidslot 
  and d.addr      =  e.taddr 

set feed off 
set pause off 
col nm format a7 heading 'Name' trunc 
col ex format 999 headin 'NbrEx' 
col rs format a7 heading 'Size' 
col init format 999,999 heading 'Init' 
col next format 999,999 heading 'Next' 
col mi format 999 heading 'MinE' 
col ma format 999 heading 'MaxE' 
col op format 99,999,999 heading 'Opt size' 
col pct format 990 heading 'PctI' 
col st format a4 heading 'Stat' 
col sn format a15 heading 'Segm Name' 
col ts format a12 heading 'In TabSpace' 
col fn format a45 heading 'File containing header of rbs' 
col ow format a7  heading 'Ownr' 
 
prompt All Rollback Segments 
select decode(owner,'PUBLIC','Public','Private') ow, segment_name sn, 
       tablespace_name ts, name fn 
from sys.dba_rollback_segs d, v$datafile f 
where d.file_id = f.file#
order by 1,2,3 ; 
 
prompt 
prompt Online Rollback Segments: 
select 
   d.segment_name nm, s.extents ex,  (s.rssize/1024)||'K' rs, d.initial_extent init, d.next_extent next, 
   d.pct_increase pct, d.min_extents mi, d.max_extents ma, optsize op, 
   decode(d.status,'ONLINE','OnL','OFFLINE','OffL') st 
 from v$rollname n, v$rollstat s, sys.dba_rollback_segs d 
where n.usn = s.usn 
  and d.segment_name = n.name(+)

column rr heading 'RB Segment' format a18 
column us heading 'Username' format a15 
column os heading 'OS User' format a10 
column te heading 'Terminal' format a10 
  

SELECT  r.name rr, nvl(s.username,'no transaction') us, s.osuser os, s.terminal te 
  FROM  v$lock  l, v$session  s,v$rollname  r 
 WHERE  l.sid = s.sid(+) 
   AND  trunc(l.id1/65536) = r.usn 
   AND  l.type = 'TX' 
   AND  l.lmode = 6 
 ORDER BY   r.name 


prompt 
prompt << Total tables size > Total RBS size >>
prompt 

SELECT ddf.tablespace_name, SUM(ddf.bytes)
  FROM dba_data_files ddf, dba_segments ds
 WHERE ds.segment_type = 'ROLLBACK'
--   AND ds.segment_name = 'RBS_BIG'
   AND ds.segment_name <> ('SYSTEM')
   AND ddf.tablespace_name = ds.tablespace_name
 GROUP BY ddf.tablespace_name
HAVING SUM(ddf.bytes)	< 
	(SELECT MAX(dt.blocks * v.value)
         FROM dba_tables dt, v$parameter v
        WHERE v.name = 'db_block_size') ;




select byes from dba_segments
where owner = 'RESEARCH'
and segment_name = 'HFILE1'
/


select  dsg.owner, dsg.segment_name, dsg.bytes/1024/1024 seg_bytes, drs.mx_bytes/1024/1024  rbs_bytes
from dba_segments dsg, 
( select SEGMENT_NAME, (INITIAL_EXTENT + (MAX_EXTENTS -1)*NEXT_EXTENT ) mx_bytes 
from dba_rollback_segs
where SEGMENT_NAME <>  'SYSTEM'
and STATUS = 'ONLINE'
and rownum <= 1  ) drs
where dsg.bytes/1024/1024 > drs.mx_bytes/1024/1024  
and owner not in ('SYSTEM','SYS')
and dsg.segment_type = 'TABLE' ;

select  dsg.owner, dsg.segment_name, dsg.bytes/1024/1024 seg_bytes, drs.mx_bytes/1024/1024  rbs_bytes
from dba_segments dsg, 
( select decode( sign(tab1.mx_bytes - tab2.mx_bytes),-1 , tab1.mx_bytes, tab2.mx_bytes ) mx_bytes
from 
( select SEGMENT_NAME, (INITIAL_EXTENT + (MAX_EXTENTS -1)*NEXT_EXTENT ) mx_bytes 
from dba_rollback_segs
where SEGMENT_NAME <>  'SYSTEM'
and STATUS = 'ONLINE'
and rownum <= 1  ) tab1,
( select tablespace_name , sum(BYTES) mx_bytes from dba_data_files
where tablespace_name = (
select TABLESPACE_NAME from dba_segments
where segment_type = 'ROLLBACK' 
and tablespace_name <> 'SYSTEM' 
and rownum <= 1  ) 
group by tablespace_name ) tab2 ) drs
where dsg.bytes/1024/1024 > drs.mx_bytes/1024/1024  
and owner not in ('SYSTEM','SYS')
and dsg.segment_type = 'TABLE' ;

select decode( sign(tab1.mx_bytes - tab2.mx_bytes),-1 , tab1.mx_bytes, tab2.mx_bytes ) mx_bytes
from 
( select SEGMENT_NAME, (INITIAL_EXTENT + (MAX_EXTENTS -1)*NEXT_EXTENT ) mx_bytes 
from dba_rollback_segs
where SEGMENT_NAME <>  'SYSTEM'
and STATUS = 'ONLINE'
and rownum <= 1  ) tab1,
( select tablespace_name , sum(BYTES) mx_bytes from dba_data_files
where tablespace_name = (
select TABLESPACE_NAME from dba_segments
where segment_type = 'ROLLBACK' 
and tablespace_name <> 'SYSTEM' 
and rownum <= 1  ) 
group by tablespace_name ) tab2 ;

#

