#!/bin/sh
## Usage: orarpt_chkalert.sh  $SG   $ORACLE_HOME  $ORACLE_SID

SERVICE_GROUP=$1  ; export SERVICE_GROUP
ORACLE_HOME=$2    ; export ORACLE_HOME
ORACLE_SID=$3     ; export ORACLE_SID

################################################################################
# Script to check for errors in the alertlog file
# Filename: check_alertlog.ksh
#
#-----------------------------------------------------------------
#   Date          Who               Description
#  ------		-----             --------------------
#  
#
################################################################################

################################################################################
get_error_log_loc()
{
	ORACLE_ERRORLOG="";
	if [ -r $ERRORLOG_LOCATION_FILE ]; then
		if [ -r `cat $ERRORLOG_LOCATION_FILE` ]; then   
			ORACLE_ERRORLOG=`cat $ERRORLOG_LOCATION_FILE`;  
		fi
	fi
	if [ "$ORACLE_ERRORLOG" = "" ]; then
		echo "/$SERVICE_GROUP/export/oracle/u001/admin/$ORACLE_SID/bdump/alert_${ORACLE_SID}.log" > $ERRORLOG_LOCATION_FILE;
		ORACLE_ERRORLOG=`cat $ERRORLOG_LOCATION_FILE`;
	fi
}
################################################################################

################################################################################
get_old_timestamp()
{
	if [ -r $ERRORLOG_TIMESTAMP ]; then  
		OLD_TIMESTAMP="`cat $ERRORLOG_TIMESTAMP`";  
	else
		OLD_TIMESTAMP="";
	fi
}
################################################################################

################################################################################
get_current_timestamp()
{
	CURRENT_TIMESTAMP="`ls -l $ORACLE_ERRORLOG | awk '{print $6,$7,$8}'`";
}
################################################################################

################################################################################
get_old_tag()
{
	OLD_TAG="************* N O   T A G   F O U N D ***************";
	if [ -r $LAST_BLOCK_CHECKED ]; then
		OLD_TAG="`head -1 $LAST_BLOCK_CHECKED`";
	fi
}
################################################################################

################################################################################
check_new_lines()
{
	nawk -v error_msgs="$CHECKLIST" '\
BEGIN { 
	FS = " "; 
	line_counter = 0; 
	error_found = 0;
	no_error_msgs = split(error_msgs,error_msgs_array,"|");
}

{
	if ($0 ~ /^[A-Z][a-z][a-z] [A-Z][a-z][a-z] [ ,0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [19,20][0-9][0-9]/) { 
		if (error_found > 0) {
			for (counter = 0; counter < line_counter; counter++) {
				print block_line[counter];
			}
		}
		line_counter = 0;
		error_found = 0;
		block_line[line_counter++] = $0;
	}
	else {
		block_line[line_counter++] = $0;
	}

	for (msg_counter = 1; msg_counter <= no_error_msgs; msg_counter++) {
		if (match($0,error_msgs_array[msg_counter]) != 0) { error_found = 1; }
	}
}

END { 
	if (error_found > 0) {
		for (counter = 0; counter < line_counter; counter++) {
			print block_line[counter];
		}
	}
}' $TMP_NEW_LINES > $TMP_ERRORS;

}
################################################################################

################################################################################

## ORACLE_SID=$1
## ORACLE_HOME=/app/oracle/products/8.1.7
## TMP_DIR="$ORACLE_HOME/admin/$ORACLE_SID/log";
TMP_DIR="/$SERVICE_GROUP/export/oracle/u001/admin/${ORACLE_SID}/log"
TMP_ORACLE_HOME=`echo $ORACLE_HOME | sed 's/\//\\\\\\\\/g'`;
TMP_NEW_LINES="$TMP_DIR/new_lines_${ORACLE_SID}.tmp";
TMP_ERRORS="$TMP_DIR/errors_${ORACLE_SID}.tmp";
ERRORLOG_LOCATION_FILE="$TMP_DIR/errorlog_location_${ORACLE_SID}.tmp";
ERRORLOG_TIMESTAMP="$TMP_DIR/errorlog_timestamp_${ORACLE_SID}.tmp";
ERRORLOG_CHECKAREA="$TMP_DIR/errorlog_checkarea_${ORACLE_SID}.tmp";
LAST_BLOCK_CHECKED="$TMP_DIR/last_block_checked_${ORACLE_SID}.tmp";
CHECKLIST="Errors|ORA-|error";
## MAIL="/usr/bin/mail";
MAIL="/usr/bin/mailx";
ADMIN_EMAIL="samson.wk.cheung@db.com";

get_error_log_loc;
get_old_timestamp;
get_current_timestamp;
get_old_tag;

echo $OLD_TIMESTAMP;
echo $CURRENT_TIMESTAMP;
echo $CHECKLIST" to be tested";

if [ "$OLD_TIMESTAMP" != "$CURRENT_TIMESTAMP" ]; then
	
	TAG_LINE_NO=`grep -n "^[A-Z][a-z][a-z] [A-Z][a-z][a-z] [ ,0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [19,20][0-9][0-9]" $ORACLE_ERRORLOG | grep "$OLD_TAG" | awk -F":" '{ print $1; }' | tail -1`;
	TAG_LINE_NO=${TAG_LINE_NO:=1};

	if [ -r $LAST_BLOCK_CHECKED ]; then
		tail +$TAG_LINE_NO $ORACLE_ERRORLOG > $ERRORLOG_CHECKAREA;
		diff $LAST_BLOCK_CHECKED $ERRORLOG_CHECKAREA | sed "s/^> //" > $TMP_NEW_LINES;
		## rm $ERRORLOG_CHECKAREA;
	else
		echo "TEST1";
		echo $ORACLE_ERRORLOG;
		echo $TMP_NEW_LINES;
		/usr/bin/cp $ORACLE_ERRORLOG $TMP_NEW_LINES;
	fi

	if [ `wc -l $TMP_NEW_LINES | awk '{print $1}'` -gt 0 ]; then
		## check_new_lines;
		## STATUS=$?;  ## not used

		## if [ `wc -l $TMP_ERRORS | awk '{print $1}'` -gt 0 ]; then  ## orig
		## if [ `egrep 'ORA-|Errors|error' $TMP_NEW_LINES | wc -l | awk '{print $1}'` -gt 0 ]; then
		## if [ `egrep $CHECKLIST $TMP_NEW_LINES | wc -l | awk '{print $1}'` -gt 0 ]; then
		if [ `egrep $CHECKLIST $TMP_NEW_LINES | grep -v "Deadlock detected" | wc -l | awk '{print $1}'` -gt 0 ]; then
			## cat $TMP_NEW_LINES | $MAIL -s "alert_log_errors@${ORACLE_SID}@(`/usr/bin/hostname`)" $ADMIN_EMAIL;
			cat $TMP_NEW_LINES | $MAIL -r sl2.apho@db.com -s "alert_log_errors@${ORACLE_SID}@(`/usr/bin/hostname`)" $ADMIN_EMAIL;
			## rm $TMP_ERRORS;
		fi

		TAG_LINE_NO=`grep -n "^[A-Z][a-z][a-z] [A-Z][a-z][a-z] [ ,0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [19,20][0-9][0-9]" $TMP_NEW_LINES | awk -F":" '{ print $1; }' | tail -1`;

		tail +$TAG_LINE_NO $TMP_NEW_LINES > $LAST_BLOCK_CHECKED;
	else
		touch $LAST_BLOCK_CHECKED;
	fi

	echo "$CURRENT_TIMESTAMP" > $ERRORLOG_TIMESTAMP;
	## rm $TMP_NEW_LINES;
else
	touch $LAST_BLOCK_CHECKED;
fi
################################################################################


