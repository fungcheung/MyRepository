set feedback on
set pages 200 lines 200
column pre_owner format a20
column pre_name format a50
column pre_class format a20
column pre_object format a50

column SPW_OWNER format a20
column SPW_STOPLIST format a20
column SPW_TYPE format a20
column SPW_WORD format a20
column SPW_LANGUAGE format a20


prompt --- CTXSYS.CTX_PREFERENCES
select * from ctxsys.ctx_preferences;

prompt --- CTXSYS.CTX_STOPWORDS

select * from ctxsys.ctx_stopwords;


prompt To set DEFAULT_LEXER to CHINESE_VGRAM_LEXER, run %oracle_home%\ctx\admin\defaults\drdefzht.sql with CTXSYS login.


