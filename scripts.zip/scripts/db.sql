-- filename: db.sql
-- For 12c

set feed off head off

col PLATFORM_NAME format a50
col value format a30

set pages 1000
set lines 200

select 'Connect: '||user||' \ '||instance_name||' \ '||host_name||' \ '||version from v$instance
union all
select 'Uptime : '||floor(xx)||'days '||floor((xx-floor(xx))*24)||'hours '||round(((xx-floor(xx 
)*24)-floor((xx-floor(xx)*24)))*60)||'minutes'||chr(10)||' ' "Database Uptime" 
from (select host_name,instance_name ,(sysdate-STARTUP_TIME) xx from v$instance)  ;


set feed off head off
column status format a10
column logins format a10
column name format a20

select ' DBID : ' || DBID from v$database union all
select ' NAME : ' || NAME from v$database union all
select ' CREATED : ' || CREATED from v$database union all
select ' OPEN_MODE : ' || OPEN_MODE from v$database union all
select ' DATABASE_ROLE : ' || DATABASE_ROLE from v$database union all
select ' FORCE_LOGGING : ' || FORCE_LOGGING from v$database union all
select ' FLASHBACK_ON : ' || FLASHBACK_ON from v$database union all
select ' LOG_MODE : ' || LOG_MODE from v$database union all
select ' ARCHIVER : ' || ARCHIVER from v$instance union all 
select ' EDITION : ' || EDITION from v$instance union all
select ' SUPPLEMENTAL_LOG_DATA_FK : ' || SUPPLEMENTAL_LOG_DATA_FK from v$database union all
select ' SUPPLEMENTAL_LOG_DATA_ALL : ' || SUPPLEMENTAL_LOG_DATA_ALL from v$database union all
select ' DB_UNIQUE_NAME : ' || DB_UNIQUE_NAME from v$database union all
select ' SUPPLEMENTAL_LOG_DATA_MIN : ' || SUPPLEMENTAL_LOG_DATA_MIN from v$database union all
select ' SUPPLEMENTAL_LOG_DATA_PK : ' || SUPPLEMENTAL_LOG_DATA_PK from v$database union all
select ' SUPPLEMENTAL_LOG_DATA_UI : ' || SUPPLEMENTAL_LOG_DATA_UI from v$database union all
select ' PLATFORM_ID : ' || PLATFORM_ID from v$database union all
select ' PLATFORM_NAME : ' || PLATFORM_NAME from v$database union all
select ' CDB : ' || CDB from v$database union all 
select ' CON_ID : ' || CON_ID from v$database union all
select ' SUPPLEMENTAL_LOG_DATA_PL : ' || SUPPLEMENTAL_LOG_DATA_PL from v$database union all
select ' CON_DBID : ' || CON_DBID from v$database union all
select ' FS_FAILOVER_STATUS : ' || FS_FAILOVER_STATUS from v$database union all
select ' FS_FAILOVER_CURRENT_TARGET : ' || FS_FAILOVER_CURRENT_TARGET from v$database union all
select ' FS_FAILOVER_THRESHOLD : ' || FS_FAILOVER_THRESHOLD from v$database union all
select ' FS_FAILOVER_OBSERVER_PRESENT : ' || FS_FAILOVER_OBSERVER_PRESENT from v$database union all
select ' FS_FAILOVER_OBSERVER_HOST : ' || FS_FAILOVER_OBSERVER_HOST from v$database union all
select ' PENDING_ROLE_CHANGE_TASKS : ' || PENDING_ROLE_CHANGE_TASKS from v$database union all
select ' CONTROLFILE_CONVERTED : ' || CONTROLFILE_CONVERTED from v$database union all
select ' CURRENT_SCN : ' || CURRENT_SCN from v$database union all
select ' PRIMARY_DB_UNIQUE_NAME : ' || PRIMARY_DB_UNIQUE_NAME from v$database union all
select ' STANDBY_BECAME_PRIMARY_SCN : ' || STANDBY_BECAME_PRIMARY_SCN from v$database union all
select ' RESETLOGS_CHANGE# : ' || RESETLOGS_CHANGE# from v$database union all
select ' RESETLOGS_TIME : ' || RESETLOGS_TIME from v$database union all
select ' PRIOR_RESETLOGS_CHANGE# : ' || PRIOR_RESETLOGS_CHANGE# from v$database union all
select ' PRIOR_RESETLOGS_TIME : ' || PRIOR_RESETLOGS_TIME from v$database union all
select ' CHECKPOINT_CHANGE# : ' || CHECKPOINT_CHANGE# from v$database union all
select ' ARCHIVE_CHANGE# : ' || ARCHIVE_CHANGE# from v$database union all
select ' CONTROLFILE_TYPE : ' || CONTROLFILE_TYPE from v$database union all
select ' CONTROLFILE_CREATED : ' || CONTROLFILE_CREATED from v$database union all
select ' CONTROLFILE_SEQUENCE# : ' || CONTROLFILE_SEQUENCE# from v$database union all
select ' CONTROLFILE_CHANGE# : ' || CONTROLFILE_CHANGE# from v$database union all
select ' CONTROLFILE_TIME : ' || CONTROLFILE_TIME from v$database union all
select ' OPEN_RESETLOGS : ' || OPEN_RESETLOGS from v$database union all
select ' VERSION_TIME : ' || VERSION_TIME from v$database union all
select ' PROTECTION_MODE : ' || PROTECTION_MODE from v$database union all
select ' PROTECTION_LEVEL : ' || PROTECTION_LEVEL from v$database union all
select ' REMOTE_ARCHIVE : ' || REMOTE_ARCHIVE from v$database union all
select ' ACTIVATION# : ' || ACTIVATION# from v$database union all
select ' SWITCHOVER# : ' || SWITCHOVER# from v$database union all
select ' ARCHIVELOG_CHANGE# : ' || ARCHIVELOG_CHANGE# from v$database union all
select ' ARCHIVELOG_COMPRESSION : ' || ARCHIVELOG_COMPRESSION from v$database union all
select ' SWITCHOVER_STATUS : ' || SWITCHOVER_STATUS from v$database union all
select ' DATAGUARD_BROKER : ' || DATAGUARD_BROKER from v$database union all
select ' GUARD_STATUS : ' || GUARD_STATUS from v$database union all
select ' RECOVERY_TARGET_INCARNATION# : ' || RECOVERY_TARGET_INCARNATION# from v$database union all
select ' LAST_OPEN_INCARNATION# : ' || LAST_OPEN_INCARNATION# from v$database union all
select ' MIN_REQUIRED_CAPTURE_CHANGE# : ' || MIN_REQUIRED_CAPTURE_CHANGE# from v$database union all
select ' FORCE_FULL_DB_CACHING : ' || FORCE_FULL_DB_CACHING from v$database 
;

select ' ' from dual;

set feed off head on

set lines 200 pages 200
column parameter format a30
column name format a30


Prompt Database NLS parameters ....

select * from NLS_DATABASE_PARAMETERS
where parameter in (
'NLS_LANGUAGE',
'NLS_TERRITORY',
'NLS_CHARACTERSET',
'NLS_NCHAR_CHARACTERSET',
'NLS_DATE_FORMAT',
'NLS_SORT'
)
union
select name, value from v$parameter where name in 
('db_block_size'
,'compatible'
);

prompt
Prompt Current NLS parameters ....
column parameter format a50
column value format a50

select * from v$nls_parameters;



