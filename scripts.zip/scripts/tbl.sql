set linesize 188 pages 999

col segment_name format a30
col owner format a15
col segment_type format a15
col tablespace_name format a15

undef user1

prompt =========================================================================================================================================================
prompt Show tables and indexes of a user


break on owner

select owner, segment_name, segment_type, BYTES/1024/1024 Size_M ,tablespace_name from dba_segments 
where segment_name not like '%BIN$%' 
and owner=upper('&&user1') order by owner,segment_type desc,Size_M desc ;


select owner, table_name, index_name from dba_indexes where owner=upper('&&user1') order by 1,2,3;

