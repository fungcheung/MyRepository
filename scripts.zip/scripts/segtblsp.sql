column owner format a20
column tablespace_name format a30
column segment_name format a30
column segment_type format a20

undef user

prompt Count number of segments group by owner and tablespace (Exclude recyclebin objects)
select distinct owner, tablespace_name, count(*) from dba_segments where segment_name not like 'BIN$%' group by tablespace_name, owner order by owner;


prompt Find segments created in other tablespace (Exclude recyclebin objects)
select segment_name, segment_type, bytes,tablespace_name from dba_segments where segment_name not like 'BIN$%' and owner='&&user' and tablespace_name <> '&&user';

prompt SQL moves table segments back to user's default tablespace
select 'alter table ' || owner || '.' || segment_name || ' move tablespace ' || owner || ';' from dba_segments where segment_type='TABLE' and segment_name not like 'BIN$%' and owner='&&user' and tablespace_name <> '&&user';

prompt SQL moves index segments back to user's default tablespace
select 'alter index ' || owner || '.' || segment_name || ' rebuild tablespace ' || owner || ';' from dba_segments where segment_type='INDEX' and segment_name not like 'BIN$%' and owner='&&user' and tablespace_name <> '&&user';

undef user



