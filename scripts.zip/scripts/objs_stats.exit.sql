-- Filename: Objs_stats.sql

col username format a20
col Tab  format 99,990
col Ind  format 99990
col Syn  format 99990
col Vew  format 9990
col Seq  format 9990
col Prc  format 990
col Trg  format 990
col Pck  format 990
col Fun  format 990
col Dep  format 9990
set pages 50000 lines 111
break on sort_key skip 1 on username on report
compute sum of Tab on report
compute sum of Ind on report
compute sum of Syn on report
compute sum of Vew on report
compute sum of Seq on report
compute sum of Trg on report
compute sum of Fun on report
compute sum of Pck on report
compute sum of Prc on report
compute sum of Dep on report

prompt 
prompt << User Database Objects Statisticts >>
prompt 

select 
  username, 
  count(decode(O.type#, 2,O.obj#,'')) Tab, 
  count(decode(O.type#, 1,O.obj#,'')) Ind,
  count(decode(O.type#, 5,O.obj#,'')) Syn,   
  count(decode(O.type#, 4,O.obj#,'')) Vew,  
  count(decode(O.type#, 6,O.obj#,'')) Seq,  
  count(decode(O.type#, 7,O.obj#,'')) Prc,  
  count(decode(O.type#, 8,O.obj#,'')) Fun,  
  count(decode(O.type#, 9,O.obj#,'')) Pck,  
  count(decode(O.type#,12,O.obj#,'')) Trg,
  count(decode(O.type#,10,O.obj#,'')) Dep
from sys.obj$ O, sys.dba_users U
where U.user_id = O.owner# (+)
group by  username 
order by  username 
/

tti off

exit
