prompt =========================================================================================================================================================
prompt Show Wallet/Keystore

SET LINESIZE 200
COLUMN wrl_parameter FORMAT A50
SELECT * FROM v$encryption_wallet;

prompt =========================================================================================================================================================
prompt Show TDE Master encryption keys

SELECT con_id, key_id FROM v$encryption_keys;
