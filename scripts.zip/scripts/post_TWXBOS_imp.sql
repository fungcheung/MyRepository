--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--
-- filename: post_XBOS_imp.sql

set echo on  pages 999 lines 222
set head off feed off pages 0 lines 79 verify off echo off

select '  ALTER ' || 
  decode (o.type#,  4, 'VIEW ',      7, 'PROCEDURE ',  8, 'FUNCTION ' , 9, 'PACKAGE ' , 
                   11, 'PACKAGE ' , 12, 'TRIGGER ' ,  13, 'TYPE ' ,    14, 'TYPE ', ' ') || 
  '"' ||  u.name ||  '"."' || o.name  ||  '" COMPILE ' || 
  decode (o.type#, 9, 'SPECIFICATION', 11, 'BODY', 13, 'SPECIFICATION', 14, 'BODY', ' ') || ';'  as COMPILE 
from  sys.obj$  o, sys.user$ u 
where u.user# = o.owner# 
  and o.remoteowner is NULL 
  and o.status in (3,4,5,6)  
  and o.type# in (4, 7, 8, 9, 11, 12, 13, 14)   
  and u.name not in ('SYSTEM', 'SYS', 'CHEUSA')
order by o.obj#  

spool /tmp/compobjs.tmp
/
spool off
@@/tmp/compobjs.tmp

set head on feed on pages 999 lines 132 verify on echo on

exit
--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--///--

