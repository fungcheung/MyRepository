
column job_name format a30
column status format a20
column log_date format a40

prompt Show failed scheduler jobs
prompt ==================================================================================================
select job_name, status, error#, log_date from dba_scheduler_job_run_details
where status not like '%SUCCEED%' order by log_date desc ;


column task_name format a30
column execution_name format a20
column execution_start format a40
column execution_end format a40
column advisor_name format a20
column status format a20

prompt Show failed advisors jobs
prompt ==================================================================================================

select task_name, execution_name,execution_start,execution_end,advisor_name,status,status_message,error_message
from DBA_ADVISOR_EXECUTIONS where status not like '%COMPLETE%' order by execution_start desc ;

prompt Show failed autotasks
prompt ==================================================================================================

select job_error, job_start_time, job_status, job_name, job_info from dba_autotask_job_history
where job_status not like '%SUCCEED%' order by job_start_time desc;

