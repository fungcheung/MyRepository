-- fiilename: show_audit2.sql

undef username1

set pages 999 lines 111 head off feed off doc off

spool c:\temp\show_audit2.spo

select 
  'User: '||USERNAME||'( '||OS_USERNAME||' ~ '||TERMINAL||' ~ '||USERHOST||' )'||chr(10)||
  'Acts: '||PRIV_USED||' ~ '||ACTION_NAME||' ~ '||OWNER||'.'||OBJ_NAME||' ~ '||
  decode(substr(SES_ACTIONS,1,1) ,'S','ALTER Success/',  'F','ALTER Fail/',  'B','ALTER Both/','')||
  decode(substr(SES_ACTIONS,2,1) ,'S','AUDIT Success/',  'F','AUDIT Fail/',  'B','AUDIT Both/','')||
  decode(substr(SES_ACTIONS,3,1) ,'S','COMMENT Success/','F','COMMENT Fail/','B','COMMENT Both/','')||
  decode(substr(SES_ACTIONS,4,1) ,'S','DELETE Success/', 'F','DELETE Fail/', 'B','DELETE Both/','')||
  decode(substr(SES_ACTIONS,5,1) ,'S','GRANT Success/',  'F','GRANT Fail/',  'B','GRANT Both/','')||
  decode(substr(SES_ACTIONS,6,1) ,'S','INDEX Success/',  'F','INDEX Fail/',  'B','INDEX Both/','')||
  decode(substr(SES_ACTIONS,7,1) ,'S','INSERT Success/', 'F','INSERT Fail/', 'B','INSERT Both/','')||
  decode(substr(SES_ACTIONS,8,1) ,'S','LOCK Success/',   'F','LOCK Fail/',   'B','LOCK Both/','')||
  decode(substr(SES_ACTIONS,9,1) ,'S','RENAME Success/', 'F','RENAME Fail/', 'B','RENAME Both/','')||
  decode(substr(SES_ACTIONS,10,1),'S','SELECT Success/', 'F','SELECT Fail/', 'B','SELECT Both/','')||
  decode(substr(SES_ACTIONS,11,1),'S','UPDATE Success/', 'F','UPDATE Fail/', 'B','UPDATE Both/','')||
  decode(substr(SES_ACTIONS,12,1),'S','REFERENCES Success/','F','REFERENCES Fail/','B','REFERENCES Both','')||
  decode(substr(SES_ACTIONS,13,1),'S','EXECUTE Success/','F','EXECUTE Fail/','B','EXECUTE Both/','')||chr(10)||
  'Comt: '||COMMENT_TEXT||chr(10)|| 
  'Perd: '||to_char(TIMESTAMP,'DD-MON-YY HH24:MI:SS')||' ~~ '||to_char(LOGOFF_TIME,'DD-MON-YY HH24:MI:SS')
 from sys.dba_audit_trail 
where username like upper('%&&username1%')
order by TIMESTAMP, USERNAME ;

undef username1

set term on head on feed on
clear column

spool off

prompt
prompt host write c:\temp\show_audit2.spo
prompt

/*
select 
   'User: '||a.userid||' ( '||a.sessionid||' / '||a.terminal||' / '||a.userhost||' )'||chr(10)||
   b.name||' ( '||a.ses$actions||' / '||a.priv$used||' ) ' ||chr(10)|| a.comment$text || chr(10)||
   to_char(a.timestamp#,'DD-MON-YY:HH24:MI:SS')||' ~~ '||to_char(a.logoff$time,'DD-MON-YY:HH24:MI:SS') ||CHR(10)
from sys.aud$ a, sys.audit_actions b
where a.action# (+) = b.action 
  and a.userid like upper('%&&username1%')
order by a.timestamp#

-- Session summary (a string of 16 characters, one for each action type in the order 
ALTER, AUDIT, COMMENT, DELETE, GRANT, INDEX, INSERT, LOCK, RENAME, SELECT, UPDATE, REFERENCES, and EXECUTE. 
Positions 14, 15, and 16 are reserved for future use. The characters are: - for none, S for success, F for failure, and B for both) 

*/

