-- Filename: gen_obj_priv.sql
-- Arthur: James Cheung
-- Generate the priv granted to someone for an input object.

set head off term on verif off feed off lines 99 pages 999

undef object_name
undef owner

prompt This script generates the priv granted on an object
prompt no row can be input error or no priv granted

select 
  'grant '||PRIVILEGE||' on '||owner||'.'||TABLE_NAME||' to '||GRANTEE|| ' ' || decode(grantable,'YES','with grant option ',' ') ||
decode(HIERARCHY,'YES','with hierarchy optiion;',';')
from DBA_TAB_PRIVS  
where table_name=upper('&&object_name') and owner=upper('&&owner');


set feed on head on





