-- filename: db_mon.sql
-- author  : Samson Cheung

set head on verify off feedback off linesize 120 pagesize 999 
set echo off term off serverout on size 9999 timing off doc off

-- alter system set timed_statistics = true ;

break on today
col today noprint new_value _date
select substr(to_char(sysdate,'fmMonth DD, YYYY HH:MI:SS P.M.'),1,35) today
from dual ;

col namex noprint new_value _dbname
select name "namex"  from v$database ;

col blksize noprint new_vue _blksize
select to_number(value) "blksize"  from v$parameter
 where name = 'db_block_size' ;

col c_logfile new_value logfile
select user||'_'||name||'_'||machine||'_mon_'||to_char(sysdate,'rrrrmmdd') c_logfile
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

/*
select name||'_'||machine||'_mon_'||to_char(sysdate,'rrrrmmdd') c_logfile
  from v$database, v$session 
 where upper(program) like upper('%oracle%')
   and rownum = 1 
*/

spool c:\temp\&&logfile..spo

clear breaks
clear computes
set heading off

select '<< Usages Of Database for '||upper(name)||'_'||upper(machine)||' on '||sysdate||' >>'
from v$database, v$session
where rownum=1 and program like 'oracle%' ;
set heading on

select round(a.total_bytes/1048576) "Tatal Mb",
       a.no_of_files                "DB Files",
       round(b.free_bytes/1048576)  "Free Mb",
       round((a.total_bytes-b.free_bytes)/1048576) "Used Mb",
       b.fragments "Fragment",
       round((a.total_bytes-b.free_bytes)*100/a.total_bytes) "Used%%"
       -- , a.tablespace_count "# of Tblsp"
  from (select /*this is like dba_data_files */
               sum(ts.blocksize * f.blocks) total_bytes,
               count(distinct f.file#) no_of_files,
               count(distinct ts.ts#) tablespace_count
          from sys.file$ f, sys.ts$ ts 
         where f.ts# = ts.ts#
           and ts.online$ <> 3
           and ts.ts#<>0) a,
       (select /*this is like dba_free_space */
               sum(f.length * ts.blocksize) free_bytes,
               count(f.length) fragments,
               max(f.length * ts.blocksize) max_frag,
               max(f.length * ts.blocksize) min_frag
          from sys.fet$ f,sys.ts$ ts  
         where f.ts# = ts.ts#
           and f.ts#<> 0) b;

col log_reads  format 999,999,999,999
col phy_reads  format 999,999,999,999
col phy_writes format 999,999,999,999
col ratio      format 999.000000


prompt 
prompt << SGA Info >>

col "Mb"  for 999,999.99 head "SGA Mb"
col name  for a22 head "Para Name"
col value for a22 head "Para Value"

select sum(value)/1024/1024 "Mb" from v$sga ;

select name, value from v$parameter
where name in ('db_cache_size', 'db_block_size','db_block_buffers','shared_pool_size','log_buffer','java_pool_size')
order by 1 ;


prompt 
prompt << Database Hit Ratio >>

select round(100*(A.value + B.value - C.value) / (A.value + B.value),6) Ratio,
       A.value + B.value Log_Reads,
       C.value           Phy_Reads,
       D.value Phy_Writes,
decode(sign(100*(A.value + B.value - C.value) / (A.value + B.value) -85),-1,'Too low','') Msg
from   v$sysstat A, v$sysstat B, v$sysstat C, v$sysstat D
where  A.name = 'db block gets'
and    B.name = 'consistent gets'
and    C.name = 'physical reads'
and    D.name = 'physical writes' ;


DECLARE
      libcac number(10,2);
      rowcac number(10,2);
      bufcac number(10,2);
      redlog number(10,2);
      spsize number;
      blkbuf number;
      logbuf number;
BEGIN
select value into redlog from v$sysstat
where name = 'redo log space requests';

select 100*(sum(pins)-sum(reloads))/sum(pins) into libcac from v$librarycache;

select 100*(sum(gets)-sum(getmisses))/sum(gets) into rowcac from v$rowcache;

select 100*(cur.value + con.value - phys.value)/(cur.value + con.value) into bufcac
from v$sysstat cur,v$sysstat con,v$sysstat phys,v$statname ncu,v$statname nco,v$statname nph
where cur.statistic# = ncu.statistic#
	and ncu.name = 'db block gets'
        and con.statistic# = nco.statistic#
        and nco.name = 'consistent gets'
        and phys.statistic# = nph.statistic#
        and nph.name = 'physical reads';

select value into spsize  from v$parameter where name = 'shared_pool_size';
select value into blkbuf  from v$parameter where name = 'db_block_buffers';
select value into logbuf  from v$parameter where name = 'log_buffer';

dbms_output.put_line('>                   SGA CACHE STATISTICS');
dbms_output.put_line('>                   ********************');
dbms_output.put_line('>              SQL Cache Hit rate = '||libcac);
dbms_output.put_line('>             Dict Cache Hit rate = '||rowcac);
dbms_output.put_line('>           Buffer Cache Hit rate = '||bufcac);
dbms_output.put_line('>         Redo Log space requests = '||redlog);
dbms_output.put_line('> ');
dbms_output.put_line('>                     INIT.ORA SETTING');
dbms_output.put_line('>                     ****************');
dbms_output.put_line('>               Shared Pool Size = '||spsize||' Bytes');
dbms_output.put_line('>                DB Block Buffer = '||blkbuf||' Blocks');
dbms_output.put_line('>                    Log Buffer  = '||logbuf||' Bytes');
dbms_output.put_line('> ');
if
	libcac < 99  then dbms_output.put_line('*** HINT: Library Cache too low! Increase the Shared Pool Size.');
END IF;
if
	rowcac < 85  then dbms_output.put_line('*** HINT: Row Cache too low! Increase the Shared Pool Size.');
END IF;
if
	bufcac < 90  then dbms_output.put_line('*** HINT: Buffer Cache too low! Increase the DB Block Buffer value.');
END IF;
if
	redlog > 100 then dbms_output.put_line('*** HINT: Log Buffer value is rather low!');
END IF;
END;
/


prompt 
prompt << Usage of Tablespaces over 85% OR Free Extents < Required >>

column tablespace_name   format a20          heading "Tablespace Name" 
column file_name         format a40          heading "File|Name" 
column Size_M            format 9,999,999.99 heading "Allocated|MBytes"
column Free_M            format 9,999,999.99 heading "Free|MBytes"
column Used_M            format 9,999,999.99 heading "Used|MBytes"
column Used_P            format 999.99       heading "Used %%"
column frag_count        format 999,999      heading "No. of|Free Exts" 
column large_frag        format 99,999,999   heading "Largest|Exts (KB)"  
column small_frag        format 99,999,999   heading "Smallest|Exts (KB)" 
column initext           format 999,999      heading "Initial|Exts (KB)" 
column nxtreqext         format 999,999      heading "Next Reqd|Exts (KB)" 
column pctincrease       format 999          heading "%Inc" 

select a.tablespace_name, a.a1 "Size_M", a.a1-nvl(b.b1,0) "Used_M", 
nvl(b.b1,0) "Free_M" , (a.a1-nvl(b.b1,0))/a.a1*100 "Used_P", 
b2 frag_count, b3 large_frag, b4 small_frag,
nvl(c1,0) nxtreqext
from
(SELECT tablespace_name, sum(bytes/1024/1024) a1
   FROM dba_data_files
group BY tablespace_name) a,
(SELECT tablespace_name, 
        SUM(bytes/1024/1024) b1,
        count(*)             b2,
        max(bytes/1024)      b3,
        min(bytes/1024)      b4
   FROM dba_free_space
   GROUP BY tablespace_name) b,
(SELECT tablespace_name,  
        MAX(NEXT_EXTENT)/1024  c1 
   FROM DBA_SEGMENTS 
  GROUP BY tablespace_name) c
where a.tablespace_name = b.tablespace_name (+)
and  a.tablespace_name = c.tablespace_name
and  ( (a.a1-nvl(b.b1,0))/a.a1*100 > 85 or c.c1 > b.b3 )
order by 1  ;

set feed off

prompt
prompt << High Index B-Tree Level >>
prompt

select owner, blevel, COUNT(*)
from dba_indexes
where owner not in ('SYS','SYSTEM', 'ORACLE', 'OPS$ORACLE')
and blevel >=3
group BY owner, blevel ;

set head off

select 'alter index '||owner||'.'||index_name||' rebuild tablespace '||tablespace_name||' ; '
from dba_indexes
where owner not in ('SYS','SYSTEM', 'ORACLE', 'OPS$ORACLE')
and blevel >=3
order by 1 ;

select 'analyze index '||owner||'.'||index_name||' validate structure ; '
from dba_indexes
where owner not in ('SYS','SYSTEM', 'ORACLE', 'OPS$ORACLE')
and blevel >=3
order by 1 ;

select 
'SELECT i.owner, s.name "Index Name", i.blevel blevel, s.del_lf_rows "Deleted Leaf Rows", '||chr(10)||
'  s.lf_rows - s.del_lf_rows "Used LR", '||chr(10)||
'  to_char(s.del_lf_rows*100/decode(s.lf_rows, 0, 1, s.lf_rows),''990.9999'') "%Del LR", '||chr(10)||
'  to_char((s.lf_rows-s.distinct_keys)*100/decode(s.lf_rows,0,1,s.lf_rows),''990.9999'') "%Distinct" '||chr(10)||
'  FROM index_stats s, dba_indexes i WHERE i.index_name =  s.name AND i.owner = '''||owner||''' ; '||chr(10)
from dba_indexes
where owner not in ('SYS','SYSTEM', 'ORACLE', 'OPS$ORACLE')
and blevel >=3 and rownum = 1 ;

set head on

prompt
prompt << Critical Next Extents >>
prompt

column owner format a10      heading "Owner"
column a1 format a17         heading "TableSp"
column a2 format a33         heading "Segment Name"
column a3 format 99,999,999  heading "Free|Tblsp (Kb)"
column a4 format 999,999,999 heading "Max Free|Bytes (Kb)"
column a5 format 999,999     heading "Next|Exts (Kb)"
column a6 format 9,999.99    heading "Avail|Extents"
column a7 format a10         heading "Segt Type"
break on owner skip 1

select
--   b.owner, a.tablespace_name a1, b.segment_name a2, b.segment_type a7, 
--   a.sumbyte a3, a.maxbyte a4, b.nxtext a5, a.maxbyte/b.nxtext a6
   b.owner, a.tablespace_name a1, b.segment_type a7, count(*) "Cnt"
from
  ( select tablespace_name, max(bytes) maxbyte, sum(bytes) sumbyte
    from dba_free_space
    group by tablespace_name ) a,
  ( select owner, tablespace_name, segment_name, segment_type, 
           next_extent nxtext
    from dba_segments
    where owner not in ('SYS','SYSTEM') ) b
where a.tablespace_name = b.tablespace_name(+)
-- having a.maxbyte/b.nxtext < 5
and a.maxbyte/b.nxtext < 5
-- group by b.owner, a.maxbyte/b.nxtext, a.tablespace_name, b.segment_name,
--          b.segment_type, a.maxbyte, b.nxtext, a.sumbyte
-- order by b.owner, a.maxbyte/b.nxtext, a.tablespace_name, b.segment_name,
--          b.segment_type, a.maxbyte, b.nxtext, a.sumbyte
group by b.owner, a.tablespace_name, b.segment_type
order by b.owner, a.tablespace_name, b.segment_type ;

select
   -- b.owner, b.segment_type, b.nxtext/1024/1024, a.maxbyte/1024/1024, a.tablespace_name
   to_char(a.maxbyte/1024/1024,'9,999')||' Mb Free on '||a.tablespace_name||' '||
   to_char(b.nxtext/1024/1024,'9,999')||' Mb x 5(exts) from '||b.owner||'.'||b.segment_name
from
  ( select tablespace_name, max(bytes) maxbyte, sum(bytes) sumbyte
    from dba_free_space
    group by tablespace_name ) a,
  ( select owner, tablespace_name, segment_name, segment_type,
           next_extent nxtext
    from dba_segments
    where owner not in ('SYS','SYSTEM') ) b
where a.tablespace_name = b.tablespace_name(+)
and a.maxbyte/b.nxtext < 5
order by 1 ;

prompt 
prompt << Current Extents > 10 OR MaxExtents-Extents <= 5 >>

select owner, segment_type, tablespace_name, -- count(*) ,  extents, max_extents
  sum(decode(sign(10-extents),-1, 1, 0 ))  "Exts>10",  
  sum(decode(sign(max_extents-extents-5),-1, 1, 0 ))  "3Exts2Max"
from dba_segments
where ( extents > 10 or max_extents-extents < 5 )
and segment_type not in ('CACHE','ROLLBACK','TEMPORARY')
group by owner, segment_type, tablespace_name ;

set head off
select 
  'select owner, segment_type, segment_name, extents, bytes/1024/1024 "Mb" '||chr(10)||
  'from dba_segments '||chr(10)||
  'where extents >=10 '||chr(10)||
  'and owner not in (''SYS'',''SYSTEM'') '||chr(10)||
  'order by 1,2,3 ; '
from dual
where exists ( 
select 1 from dba_segments
where ( extents > 10 or max_extents-extents < 5 )
and segment_type not in ('CACHE','ROLLBACK','TEMPORARY')
group by owner, segment_type, tablespace_name );
set head on

prompt 
prompt << Tables Experiencing Chaining >>
prompt 
select owner, table_name, nvl(chain_cnt,0) "Chained Rows"
  from all_tables
 where owner not in ('SYS', 'SYSTEM')
   and nvl(chain_cnt,0) > 0
 order by owner, table_name;

prompt 
prompt << DB Block Buffer - User Hit Ratios >>
prompt 

col username for a20
col SID   for a20 
col machine  for a25
col ratio    for 990.99 head "Ratio%" 

create or replace view user_hit_ratios as
select username, osuser, v$session.sid, v$session.SERIAL#, 
       machine, process, status,
	 100*(consistent_gets + block_gets - physical_reads) /
	      (consistent_gets + block_gets) ratio
  from v$session, v$sess_io
 where v$session.sid = v$sess_io.sid
   and (consistent_gets + block_gets) > 0
   and username is not null ;

select username||'/'||osuser "username", sid||','||SERIAL# "SID",
       machine, process, status, ratio 
from user_hit_ratios
where ratio < 80
order by ratio ;

drop view user_hit_ratios ;

prompt  
prompt << Database Errors >>
prompt 

COLUMN owner	FORMAT a15
SELECT de.owner, de.name, de.type, count(*)
  FROM dba_errors	de, 	v$database	v
 WHERE v.name != 'ORACLE'
GROUP BY de.owner, de.name, de.type ;

prompt  
prompt << Listing all Invalid Objects >>

select owner, object_type, object_name, status 
  from all_objects
 where status = 'INVALID'
ORDER BY owner, object_type, object_name ;

doc
select 
   decode( OBJECT_TYPE, 'PACKAGE BODY', 
   'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body ;', 
   'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile ;' ) 
 from dba_objects 
where STATUS = 'INVALID' 
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW' ) 
order by OWNER, OBJECT_TYPE, OBJECT_NAME
#

select 
   decode( OBJECT_TYPE, 'PACKAGE BODY', 'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body ;', 
                        'UNDEFINED', 'ALTER MATERIALIZED VIEW ' || OWNER||'.'||OBJECT_NAME || ' compile ;', 
   'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile ;' ) 
 from dba_objects 
where STATUS = 'INVALID' 
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW', 'UNDEFINED') 
order by OWNER, OBJECT_TYPE, OBJECT_NAME; 

/* Removed since 8.1.6
select
    decode( OBJECT_TYPE, 'PACKAGE BODY',
    'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body ;',
    'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile ;' )
from
    dba_objects a,
    sys.order_object_by_dependency b
where A.OBJECT_ID = B.OBJECT_ID(+) 
  and STATUS = 'INVALID' 
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW' )
-- order by DLEVEL DESC, OBJECT_TYPE, OBJECT_NAME 
order by OWNER, OBJECT_TYPE, OBJECT_NAME 
*/


prompt  
prompt << Error with Materialized Views  >>

select owner, COMPILE_STATE, count(*) from dba_mviews
where COMPILE_STATE = 'ERROR'
group by owner, COMPILE_STATE ;


prompt  
prompt << System Tablespace as Default/Temporary Tablespace >>

-- select USERNAME, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE, PROFILE
--   from dba_users
--  order by 2,1 ;

select 'alter user '||username||chr(10)||
       'default tablespace TOOLS '||CHR(10)||
       'temporary tablespace TEMP ; '
from dba_users
where ( DEFAULT_TABLESPACE = 'SYSTEM' or TEMPORARY_TABLESPACE = 'SYSTEM' )
 and username not in ('SYSTEM','SYS') ;

prompt  
prompt << Without Temporary Tablespace >>

SELECT TABLESPACE_NAME, CONTENTS
  from dba_tablespaces
 where 0 = 
    ( select count(*) from dba_tablespaces
       where CONTENTS = 'TEMPORARY' ) ;


prompt  
prompt << Daily archive logfile count >>
prompt 


column ord     noprint
column date_   heading 'Date'         format A15
column nbr      heading '#Arch files'  format 999999999
column no_size heading 'Size Mb'      format 999999999
compute avg of no      on report
compute avg of no_size on report
break on report

select MAX(first_time) ord, to_char(first_time,'DD-MON-YYYY') date_, 
          count(recid) nbr, count(recid) *10 no_size
from v$log_history
group by to_char(first_time,'DD-MON-YYYY')
order by ord
/



doc
prompt  
prompt << Owner Objects >>
prompt 

col ow  format a18 heading 'Owner'
col ta  format 9,999 heading 'Tbl'
col ind format 9,999 heading 'Idx'
col sy  format 9,999 heading 'Syn'
col se  format 9,999 heading 'Seq'
col ve  format 9,999 heading 'Vw'
col clu format 9,999 heading 'Clu'
col dbl format 9,999 heading 'DbLk'
col pkg format 9,999 heading 'Pkgs'
col pkb format 9,999 heading 'PkgBdy'
col pro format 9,999 heading 'Proc'
col fn  format 9,999 heading 'Fun'
col trg format 9,999 heading 'Trg'

compute sum of ta on report
compute sum of ow on report
compute sum of sy on report
compute sum of se on report
compute sum of ind on report
compute sum of ve on report
compute sum of clu on report
compute sum of dbl on report
compute sum of ow on report
compute sum of pkg on report
compute sum of pkb on report
compute sum of pro on report
compute sum of fn  on report
compute sum of trg on report
break on report
set verify off
set feedback off
set heading on
select owner ow,
       sum(decode(object_type,'TABLE',1,0)) ta ,
       sum(decode(object_type,'INDEX',1,0)) ind ,
       sum(decode(object_type,'SYNONYM',1,0)) sy ,
       sum(decode(object_type,'SEQUENCE',1,0)) se ,
       sum(decode(object_type,'VIEW',1,0)) ve ,
       sum(decode(object_type,'CLUSTER',1,0)) clu,
       sum(decode(object_type,'DATABASE LINK',1,0)) dbl ,
       sum(decode(object_type,'PACKAGE',1,0)) pkg ,
       sum(decode(object_type,'PACKAGE BODY',1,0)) pkb ,
       sum(decode(object_type,'PROCEDURE',1,0)) pro,
       sum(decode(object_type,'FUNCTION',1,0)) fn,
       sum(decode(object_type,'TRIGGER',1,0)) trg
from dba_objects
group by owner ;
#

prompt  
prompt << Owner Objects' PCT_INCREASE <> 0 >>
prompt 

select owner, segment_type, count(*)
from dba_segments
where PCT_INCREASE <> 0
and owner not in ('SYSTEM','SYS')
group by owner, segment_type ;

prompt
prompt << Coalesce fragmented tablespaces >>

select 'alter tablespace '||tablespace_name ||' coalesce ;'
from dba_tablespaces
where tablespace_name <> 'SYSTEM'
order by 1
/


-- select 'alter tablespace '||ts.tablespace_name ||
--         ' coalesce      /* ' || to_char(percent_blocks_coalesced,'99.99') ||'  */ ;'
-- from dba_tablespaces ts,
--      dba_free_space_coalesced co
-- where ts.tablespace_name not like 'RBS%' 
-- and ts.tablespace_name not like 'SYS%'
-- and ts.tablespace_name <> 'TEMP' 
-- and co.tablespace_name=ts.tablespace_name 
-- and percent_blocks_coalesced<>100
-- order by percent_blocks_coalesced desc ;

prompt 
prompt << Objects in WRONG tablespace >>
prompt 

select owner "Tables in Idx Tblsp", tablespace_name, count(*)
  from dba_tables
 where owner not in ('SYSTEM','SYS')
   and tablespace_name in 
  ( select distinct tablespace_name
     -- from dba_indexes 
     from dba_segments
    where segment_type = 'INDEX'
      and owner not in ('SYSTEM','SYS') )
group by owner, tablespace_name ;

select owner "Indexes in Data Tblsp", tablespace_name, count(*)
  from dba_indexes
 where owner not in ('SYSTEM','SYS')
   and tablespace_name in 
  ( select distinct tablespace_name
     from dba_segments
    where segment_type = 'TABLE'
      and owner not in ('SYSTEM','SYS') )
group by owner, tablespace_name ;

prompt 
prompt << Rollback Segment Stats >>
prompt 

select 'Tran Table Consistent Read Rollbacks > 1% of Consistent Gets' aa,
       'Action: Create more Rollback Segments'
  from v$sysstat
 where decode (name,'transaction tables consistent read rollbacks',value) 
         * 100 / decode (name,'consistent gets',value) > 0.1
   and name in ('transaction tables consistent read rollbacks','consistent gets')
   and value > 0 ;

select 'Undo Records Applied > 10% of Consistent Changes' aa,
       'Action: Create more Rollback Segments'
  from v$sysstat
 where decode (name,'transaction tables consistent reads - undo records applied',value)
         * 100 / decode (name,'consistent changes',value) > 10  
   and name in ('transaction tables consistent reads - undo records applied', 'consistent changes')
   and value > 0 ;

select 'You have had a number of rollback segment waits. Try adding '|| sum(decode(waits,0,0,1))||chr(10)||
       'rollback segments to avoid rollback header contention. '
 from v$rollstat
having sum(decode(waits,0,0,1)) > 0;

SELECT 'If the ratio waits/gets > 5%,  add more rollback.'||chr(10)||
       'The average of waits/gets is '||
       to_char(round((sum(waits) / sum(gets)) * 100,2),'0.99')||'%'
FROM   v$rollstat
HAVING (sum(waits)>0) ;

doc
col segment_name    for  a11 head 'Segment'
col owner           for  a11 head 'Owner'
col tablespace_name for  a11 head 'Tblsp'
col status          for  a8 
col INITIAL_EXTENT  head 'InitX'
col NEXT_EXTENT     head 'NxtX'
col MIN_EXTENTS     head 'MinX'
col MAX_EXTENTS     head 'MaxX'

select segment_name, Owner, TABLESPACE_NAME, status,
INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS
from dba_rollback_segs
order by 1 ;

create table gh$rbs_stats as 
select n.name             name , r.hwmsize/1024   hwmsize,  
       r.optsize/1024   optimal, r.aveactive/1024 aveactive ,
       r.shrinks        Shrinks, r.aveshrink/1024 aveshrink ,
       r.rssize/1024    rssize , r.extents, r.gets,
       r.writes          writes, r.waits, r.xacts
from v$rollstat r, v$rollname n
where n.usn=r.usn ;

select name,rssize,optimal,hwmsize,shrinks,aveshrink,extents
  from gh$rbs_stats 
 order by 1;

column wait_pct heading "waits/writes %" format 999.99
column wait_get_pct heading "waits/gets %" format 999.99

select name,gets,writes,
       (waits/decode(writes,0,1,writes))*100 wait_pct,
       (waits/decode(gets,0,1,gets))*100 wait_get_pct 
  from gh$rbs_stats 
 order by 1;

drop table gh$rbs_stats;
#

prompt 
prompt ~~~~ END ~~~~


spool off

ttitle off
clear breaks
clear computes
set heading on
set termout on
set feedback on

prompt 
prompt host write c:\temp\&&logfile..spo
prompt 

-- alter system set d_statistics = false; 

/*

-- finding diff code % prod vs dev 
(select name,text 
    from user_source 
 MINUS
  select name,text from   
     user_source@dbprod)
UNION 
   (select name,text 
       from user_source@dbprod
   MINUS
    select name,text from user_source)


  # Show shared pool free space percentage.

  col percento format 990.00 head "Freespace %"

  SELECT f.pool, f.name, s.value, TO_CHAR((f.bytes/s.value)*100,'990.00')||' %' percento 
  FROM v$parameter s, v$sgastat f
  WHERE f.name='free memory' 
  AND f.pool='shared pool' 
  AND s.name='shared_pool_size'
union
  SELECT f.pool, f.name, s.value, TO_CHAR((f.bytes/s.value)*100,'990.00')||' %' percento 
  FROM v$parameter s, v$sgastat f
  WHERE f.name='free memory' 
  AND f.pool='large pool' 
  AND s.name='large_pool_size'

union
  SELECT f.pool, f.name, s.value, TO_CHAR((f.bytes/s.value)*100,'990.00')||' %' percento 
  FROM v$parameter s, v$sgastat f
  WHERE f.name='free memory' 
  AND f.pool='java pool' 
  AND s.name='java_pool_size';

*/

/*
Shared Pool Minimium Size Calculator

spool minshpool.lst
set numwidth 15
column shared_pool_size format 999,999,999
column sum_obj_size format 999,999,999
column sum_sql_size format 999,999,999
column sum_user_size format 999,999,999
column min_shared_pool format 999,999,999
select to_number(value) shared_pool_size, 
                         sum_obj_size,
                         sum_sql_size, 
                         sum_user_size, 
(sum_obj_size + sum_sql_size+sum_user_size)* 1.3 min_shared_pool
  from (select sum(sharable_mem) sum_obj_size 
          from v$db_object_cache),
               (select sum(sharable_mem) sum_sql_size
          from v$sqlarea),
               (select sum(250 * users_opening) sum_user_size
          from v$sqlarea), v$parameter
 where name = 'shared_pool_size';
spool off

*/

/*

Script to report SQL statements with high disk reads 


DEFINE blocks_read = 1000 (NUMBER)
COLUMN parsing_user_id  FORMAT 9999999     HEADING 'User Id'
COLUMN executions       FORMAT 9999        HEADING 'Exec'
COLUMN sorts            FORMAT 99999       HEADING 'Sorts'
COLUMN command_type     FORMAT 99999       HEADING 'CmdT'
COLUMN disk_reads       FORMAT 999,999,999 HEADING 'Block Reads'
COLUMN sql_text         FORMAT a40         HEADING 'Statement' WORD_WRAPPED
SET LINES 130
SELECT parsing_user_id, executions, sorts, command_type, disk_reads, sql_text
  FROM v$sqlarea
 WHERE disk_reads > &&blocks_read
 ORDER BY disk_reads
/

select sum(sharable_mem) from v$sqlarea;   
select sum(sharable_mem) from v$db_object_cache;   

SELECT        
S.SID, S.USERNAME, DISK_READS, SQL_TEXT      
FROM        V$SQLAREA, V$SESSION S      
WHERE        ADDRESS = S.SQL_ADDRESS      
-- and DISK_READS > nnnn        
ORDER BY        DISK_READS DESC


*/

