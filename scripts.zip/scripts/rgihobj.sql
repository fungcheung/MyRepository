-- Purpose: List rGIH database objects
-- Authur : James
-- Modified Date: 20171016
-- Version: 0.1

set lines 200
set pages 20000

alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

column owner format a10
column object_type format a30
column object_name format a30
column status format a10
column created format a20
column last_ddl_time format a30
column generated format a10
column ORACLE_MAINTAINED format a10



select owner, object_type, object_name, status, created, last_ddl_time,GENERATED,ORACLE_MAINTAINED  
from dba_objects where object_type not in 
(
'SYNONYM'
,'INDEX'
,'LOB'
,'SEQUENCE'
) 
and object_name not like 'S%_IDX$' 
and owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1,2,3
/

