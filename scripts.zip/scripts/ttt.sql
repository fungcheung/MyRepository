-- Purpose: List rGIH indexes
-- Authur : James
-- Modified Date: 20171019
-- Version: 0.1

set lines 200
set pages 50000


alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

column owner format a10
column table_owner format a10
column index_name format a30
column index_type format a30
column table_name format a30
column generated format a10
column column_position format 999
column column_name format a30



select table_owner, table_name, index_name, column_position,column_name     
from dba_ind_columns where (index_name not like 'BIN$%' and table_name not like 'S%_IDX$' and table_name not like 'SDE_LOGFILE%' and table_name not like '%_BAK' and column_name not in ('OBJECTID','SHAPE','OBJECTID_1','GLOBALID')) and  
table_owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
,'LIC'
 ) order by 1,2,3,4,5
/


/*


select 'drop index ' || table_owner || '.' || index_name || ';'    
from dba_indexes where (index_name like 'I%' or index_name like 'G%')  
and table_owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1
/



select owner, table_name, index_name, index_type, generated    
from dba_indexes where index_type not in 
(
'LOB'
,'DOMAIN'
,'IOT - TOP'
) 
and index_name like 'I%' 
and owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1,2,3
/



select table_owner, table_name, index_name, column_position,column_name     
from dba_ind_columns where (index_name like 'I%' or index_name like 'G%')  
and table_owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1,2,3,4,5
/

select table_owner, table_name, index_name, column_position,column_name     
from dba_ind_columns where (index_name not like 'I%' and index_name not like 'G%' and index_name not like 'BIN$%') and  
table_owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1,2,3,4,5
/



select 'drop index ' || table_owner || '.' || index_name || ';'    
from dba_indexes where (index_name like 'I%' or index_name like 'G%')  
and table_owner in 
(
'RMAPAPP'
,'RDATAAPP'
,'RUSER'
,'RVIEW'
,'RREAD'
,'RGIHAPP'
,'RDBSUPP'
 ) order by 1
/



*/
