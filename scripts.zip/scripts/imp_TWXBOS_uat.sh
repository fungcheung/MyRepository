#### Filename: imp_TWXBOS_uat.sh

ORACLE_SID=TWXBOS ; export ORACLE_SID   
ORACLE_HOME=/data/oracle/TWXBOS/product/10.2.0.3 ; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib ;  export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ; export PATH
NLS_LANG=AMERICAN_AMERICA.ZHT16BIG5 ; export NLS_LANG

####
date ; ls -ltr /data/oracle/TWXBOS/backup/expimp/TWXBOS_fullexp.dmp.Z

date ; ls -ltr /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_load.log
rm -f /tmp/imp_TWXBOS_uat.pipe
/usr/sbin/mknod /tmp/imp_TWXBOS_uat.pipe p
zcat /data/oracle/TWXBOS/backup/expimp/TWXBOS_fullexp.dmp.Z  > /tmp/imp_TWXBOS_uat.pipe  &
imp / file=/tmp/imp_TWXBOS_uat.pipe log=/data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_load.log \
grants=y buffer=33554432  ignore=y commit=y fromuser=xbosload touser=xbosload
rm -f /tmp/imp_TWXBOS_uat.pipe
date ; ls -ltr /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_load.log

####

date ; ls -ltr /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_prod.log
rm -f /tmp/imp_TWXBOS_uat.pipe
/usr/sbin/mknod /tmp/imp_TWXBOS_uat.pipe p
zcat /data/oracle/TWXBOS/backup/expimp/TWXBOS_fullexp.dmp.Z  > /tmp/imp_TWXBOS_uat.pipe  &
imp / file=/tmp/imp_TWXBOS_uat.pipe log=/data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_prod.log \
grants=y buffer=33554432  ignore=y commit=y fromuser=xbosprod touser=xbosprod
rm -f /tmp/imp_TWXBOS_uat.pipe
date ; ls -ltr /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS_prod.log

### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 
exit 0

