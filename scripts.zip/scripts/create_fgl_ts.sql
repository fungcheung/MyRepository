set echo on 
spool create_fgl_ts.spo

create tablespace foglight
datafile '/tpexbosdbp1/export/oracle/u003/XBOS/oradata/XBOS_foglight_01.dbf' size 25M
 EXTENT MANAGEMENT LOCAL UNIFORM SIZE 128K;

spool off
set echo off

