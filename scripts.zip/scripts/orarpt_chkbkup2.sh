#!/bin/ksh
## Filename: orarpt_chkbkup.sh
## Usage: ./orarpt_chkbkup.sh

ORACLE_HOME=/data/oracle/product/9.2.0.4  
export ORACLE_HOME

TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN

ADMIN=samson.wk.cheung@db.com 
export ADMIN

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

echo '--------------------------------------------------------------------------------' > /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log

rm  /home/oracle/dbasql/backup_history/*

scp -p tpeeqxbosp1b:/tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log  /home/oracle/dbasql/backup_history/XBOS_PRD_backup.log
scp -p tpeeqxbosu1:/tpexbosdbp1/export/oracle/u004/XBOSTW/backup/logs/backup.log /home/oracle/dbasql/backup_history/XBOSTW_UAT_backup.log
scp -p tpeeqxbosu1:/tpexbosdbd1/export/oracle/u004/D_XBOSTW/backup/logs/backup.log  /home/oracle/dbasql/backup_history/D_XBOSTW_DEV_backup.log
scp -p tpeeqxbosb1:/tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log  /home/oracle/dbasql/backup_history/XBOS_BCP_backup.log

scp -p hkgeqappb3:/hkgaradbp1/export/oracle/u004/DBXHKB/backup/logs/backup.log  /home/oracle/dbasql/backup_history/DBXHKB_BCP_backup.log
scp -p hkgeqappu2a:/hkgaradbp1/export/oracle/u004/DBXHKU/backup/logs/backup.log  /home/oracle/dbasql/backup_history/DBXHKU_UAT_backup.log
scp -p hkgeqappp3:/hkgaradbp1/export/oracle/u004/DBXHKP/backup/logs/backup.log  /home/oracle/dbasql/backup_history/DBXHKP_PRD_backup.log

scp -p hkgeqappp3:/hkgr2dbp1/export/oracle/u004/R2HKP/backup/logs/backup.log  /home/oracle/dbasql/backup_history/R2HKP_PRD_backup.log
scp -p hkgeqappu2a:/hkgr2dbp1/export/oracle/u004/R2HKU/backup/logs/backup.log  /home/oracle/dbasql/backup_history/R2HKU_UAT_backup.log

scp -p hkgapfidbu1:/hkgapfidbp1/export/oracle/u004/HKAPFI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/HKAPFI_UAT_backup.log
scp -p hkgeqappd2:/hkgapfidbp1/export/oracle/u004/HKAPFI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/HKAPFI_DEV_backup.log
scp -p hkgeqdbu1b:/hkgapfidbp1/export/oracle/u004/HKAPFI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/HKAPFI_UAT_backup.log
scp -p hkgeqdbp2a:/hkgapfidbp1/export/oracle/u004/HKAPFI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/HKAPFI_PRD_backup.log

scp -p hkgepcdbu1:/hkgepcdbp1/export/oracle/u004/EPCHK/backup/logs/backup.log /home/oracle/dbasql/backup_history/EPCHK_UAT_backup.log
scp -p hkgeqappb1:/hkgepcdbp1/export/oracle/u004/EPCHK/backup/logs/backup.log /home/oracle/dbasql/backup_history/EPCHK_BCP_backup.log
scp -p hkgeqappd2:/hkgepcdbp1/export/oracle/u004/EPCHK/backup/logs/backup.log  /home/oracle/dbasql/backup_history/EPCHK_DEV_backup.log
scp -p hkgepcdbp1:/hkgepcdbp1/export/oracle/u004/EPCHK/backup/logs/backup.log  /home/oracle/dbasql/backup_history/EPCHK_PRD_backup.log

scp -p hkgeqappd1:/hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log  /home/oracle/dbasql/backup_history/research_DEV_backup.log
scp -p hkgresdbu1:/hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log /home/oracle/dbasql/backup_history/research_UAT_backup.log
scp -p hkgresdbp1:/hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log /home/oracle/dbasql/backup_history/research_PRD_backup.log
## scp -p hkgeqappb1:/hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log  /home/oracle/dbasql/backup_history/research_BCP_backup.log

scp -p hkgeqappd1:/hkgresdbp1/export/oracle/u004/ACEDEV/backup/logs/backup.log  /home/oracle/dbasql/backup_history/ACEDEV_DEV_backup.log
scp -p hkgresdbu1:/hkgresdbp1/export/oracle/u004/ACEUAT/backup/logs/backup.log   /home/oracle/dbasql/backup_history/ACEUAT_UAT_backup.log
scp -p hkgresdbp1:/hkgresdbp1/export/oracle/u004/ACE/backup/logs/backup.log   /home/oracle/dbasql/backup_history/ACE_PRD_backup.log
## scp -p hkgeqappb1:/hkgresdbp1/export/oracle/u004/ACE/backup/logs/backup.log  /home/oracle/dbasql/backup_history/ACE_BCP_backup.log

scp -p hkgeqappu2a:/hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log  /home/oracle/dbasql/backup_history/GEL_UAT_backup.log
scp -p hkgeqappb3:/hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log  /home/oracle/dbasql/backup_history/GEL_BCP_backup.log
scp -p hkgeqdbp1a:/hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log  /home/oracle/dbasql/backup_history/GEL_PRD_backup.log

scp -p hkgarddbu1:/hkgarddbp1/export/oracle/u004/ARDMAU3/backup/logs/backup.log  /home/oracle/dbasql/backup_history/ARDMAU3_UAT_backup.log
scp -p hkgarddbp1:/hkgarddbp1/export/oracle/u004/ARDMAU3/backup/logs/backup.log  /home/oracle/dbasql/backup_history/ARDMAU3_PRD_backup.log

scp -p hkgeqappb1:/hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/TSI_BCP_backup.log
scp -p hkgeqappd1:/hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/TSI_DEV_backup.log
scp -p hkgtsidbu1:/hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/TSI_UAT_backup.log
scp -p hkgtsidbp1:/hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log  /home/oracle/dbasql/backup_history/TSI_PRD_backup.log

scp -p hkgeqappb1:/hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log  /home/oracle/dbasql/backup_history/FCCE_BCP_backup.log
scp -p hkgeqappd1:/hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log  /home/oracle/dbasql/backup_history/FCCE_DEV_backup.log
scp -p hkgfccedbu1:/hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log  /home/oracle/dbasql/backup_history/FCCE_UAT_backup.log
scp -p hkgfccedbp1:/hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log  /home/oracle/dbasql/backup_history/FCCE_PRD_backup.log

echo '--------------------------------------------------------------------------------' > /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log
echo 'Start ....'  > /home/oracle/dbasql/backup_history/Oracle_backup.log
for ii in `ls -1 /home/oracle/dbasql/backup_history/*log` ; do
  echo .... >> /home/oracle/dbasql/backup_history/Oracle_backup.log
  echo $ii .... >> /home/oracle/dbasql/backup_history/Oracle_backup.log
  tail -1 $ii  >> /home/oracle/dbasql/backup_history/Oracle_backup.log
done
echo 'End   ....'  > /home/oracle/dbasql/backup_history/Oracle_backup.log
echo '--------------------------------------------------------------------------------' > /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log

if [ -f /home/oracle/dbasql/backup_history/Oracle_backup.log ] ; then
     /usr/bin/cat /home/oracle/dbasql/backup_history/Oracle_backup.log | /usr/bin/mailx  -s "Backup Report - `date '+%y%m%d'`"  $ADMIN
fi

exit 0
