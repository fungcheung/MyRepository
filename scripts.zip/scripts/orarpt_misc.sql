-- 
-- Filename: orarpt_misc.sql
--

set echo on verify off feedback off pages  0 lines  132 recsep off

-- Analyze objects
select 'analyze '||segment_type||' '||owner||'.'||segment_name||' '||
   decode(sign(10485760 - bytes),1,'compute statistics;','estimate statistics;') 
 from sys.dba_segments
where owner not in ('SYSTEM', 'SYS')
  and segment_type = 'TABLE'
order by owner, segment_name

spool /tmp/analyzal.tmp
/
spool  off
spool /tmp/analyzal.out
set term on
@/tmp/analyzal.tmp
spool off

-- Compile objects
set head off feed off
select 
   decode( OBJECT_TYPE, 'PACKAGE BODY', 'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body ;', 
                        'UNDEFINED', 'ALTER MATERIALIZED VIEW ' || OWNER||'.'||OBJECT_NAME || ' compile ;', 
   'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile ;' ) 
 from dba_objects 
where STATUS = 'INVALID' 
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW', 'UNDEFINED') 
order by OWNER, OBJECT_TYPE, OBJECT_NAME

spool /tmp/comp_objs.tmp
/
spool  off
spool /tmp/comp_objs.out
set term on
@/tmp/comp_objs.tmp
spool off

-- Coalesce tablespaces
select 'alter tablespace '||tablespace_name||' coalesce ;'
from dba_tablespaces
where tablespace_name not in ('TEMP', 'SYSTEM')
and tablespace_name not like ('%UNDO%')
order by 1

spool /tmp/coalesce.tmp
/
spool  off
spool /tmp/coalesce.out
set term on
@/tmp/coalesce.tmp
spool off


