set pages 200
set lines 200

prompt #####################################################################################
prompt # Redo log information
prompt #####################################################################################



col STATUS format a10
col MEMBER format a60
col IS_RECOVERY_DEST_FILE format a25

select * from sys.v$log order by thread#;

select group#,status,type,member,IS_RECOVERY_DEST_FILE,con_id from sys.v$logfile order by type,group#;


prompt #####################################################################################
prompt # Standby Redo log information
prompt #####################################################################################

select group#,thread#,bytes, used, archived, status,con_id_to_con_name(con_id) con_name from sys.v$standby_log order by group#;
