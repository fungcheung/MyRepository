
cd $ORACLE_HOME

rm  ./JRE 
ln -s ./jre/1.1.8  ./JRE 

rm ./bin/runInstaller 
ln -s ./oui/bin/runInstaller.sh	 ./bin/runInstaller 

rm ./ctx/lib/libctxx9.so 
ln -s ./lib/libctxx9.so  ./ctx/lib/libctxx9.so 

rm ./jdk/jre/lib/sparc/libjvm.so 
ln -s ./jdk/jre/lib/sparc/client/libjvm.so  ./jdk/jre/lib/sparc/libjvm.so 

rm ./jre/1.1.8/bin/javakey 
ln -s ./jre/1.1.8/bin/.java_wrapper  ./jre/1.1.8/bin/javakey 

rm ./jre/1.1.8/bin/jre 
ln -s ./jre/1.1.8/bin/.java_wrapper  ./jre/1.1.8/bin/jre 

rm ./jre/1.1.8/bin/rmiregistry 
ln -s ./jre/1.1.8/bin/.java_wrapper  ./jre/1.1.8/bin/rmiregistry 

rm ./jre/1.3.1/bin/Policytool 
ln -s ./jre/1.3.1/bin/.java_wrapper  ./jre/1.3.1/bin/Policytool 

rm ./jre/1.3.1/bin/java 
ln -s ./jre/1.3.1/bin/.java_wrapper  ./jre/1.3.1/bin/java 

rm ./jre/1.3.1/bin/keytool 
ln -s ./jre/1.3.1/bin/.java_wrapper  ./jre/1.3.1/bin/keytool 

rm ./jre/1.3.1/bin/rmid 
ln -s ./jre/1.3.1/bin/.java_wrapper  ./jre/1.3.1/bin/rmid 

rm ./jre/1.3.1/bin/rmiregistry 
ln -s ./jre/1.3.1/bin/.java_wrapper  ./jre/1.3.1/bin/rmiregistry 

rm ./jre/1.3.1/bin/tnameserv 
ln -s ./jre/1.3.1/bin/.java_wrapper  ./jre/1.3.1/bin/tnameserv 

rm ./lib/libnavhoa.a 
ln -s ./lib32/libnavhoa.a  ./lib/libnavhoa.a 

rm ./lib32/ldflags 
ln -s ./lib/ldflags  ./lib32/ldflags 

