set verify off
set head off

@gen_views.sql fehdapp FEHD_OVITRAP_ADMIN
@gen_views.sql fehdapp FEHD_OVITRAP_POINT
@gen_views.sql fehdapp FEHD_OVITRAP_INDEX
@gen_views.sql fehdapp FEHD_OVITRAP_MOI
@gen_views.sql fehdapp FEHD_OVITRAP_POLY
@gen_views.sql fehdapp FEHD_OVITRAP_RESULT
@gen_views.sql fehdapp FEHD_DENGUE_RESULT_PT


