prompt ##############################################################################
prompt # Generate table and index ddl. Enter owner and table name.
prompt ##############################################################################


set pages 9999
set lines 200
set long 99990
select 'select dbms_metadata.get_ddl(' || '''' || OBJECT_TYPE || '''' || ',' ||  '''' || object_name || '''' || ',' ||  '''' || owner || '''' || ') from dual;'
from dba_objects where (object_type = 'TABLE' or object_type ='VIEW') and 
owner = upper('&owner') and
object_name = upper('&object')
/


select 'select dbms_metadata.get_ddl(' || '''' || 'INDEX' || '''' || ',' ||  '''' || index_name || '''' || ',' ||  '''' || owner || '''' || ') from dual;'
from dba_indexes where 
table_name = upper('&object') and
owner = upper('&owner')
/




