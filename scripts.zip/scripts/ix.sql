undef 1
clear all
set pages 9999
set lines 222
break on index_name
col COLUMN_NAME for a33
col COLUMN_POSITION head 'Pos' for 999
col INDEX_OWNER for a11

select INDEX_OWNER, table_name, index_name, COLUMN_POSITION, column_name
-- from user_ind_columns
from dba_ind_columns
where table_name like upper('&&1%')
order by 1,2,3,4
/

