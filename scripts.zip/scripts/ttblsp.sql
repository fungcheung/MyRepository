select a.tablespace_name, a.bytes_used/1024/1024, a.bytes_free/1024/1024, b.file_name from v$temp_space_header a, 
dba_temp_files b where a.file_id = b.file_id;
