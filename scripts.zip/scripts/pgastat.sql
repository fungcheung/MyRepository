-- set markup html on spool on 
-- spool pgastat.html
-- set head off
set pages 200 lines 200
select 'Note: Total pga inuse should be less than the PGA_AGGREGATE_TARGET' from dual;
-- set head on
column value format 999999999999999
column name format a50

select * from v$pgastat;
-- spool off
-- exit;
