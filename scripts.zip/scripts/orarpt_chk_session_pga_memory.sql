-- 
-- Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_chk_session_pga_memory.sql
-- 

set head off verify off feedback off linesize 111 pagesize 999 
set echo off term off serverout on size 9999 timing off doc off

col c_logfile new_value logfile
select name||'_'||machine||'_chk_session_pga_memory' c_logfile
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

spool /home/oracle/dbasql/&&logfile..spo

prompt Report Start

select '<< '||name||'_'||machine||'_chk_session_pga_memory'||' >> '
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

-- prompt << Session PGA Memory >>

set head on 
alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ;
select sysdate from dual ;

select sum(bytes)/1024/1024 mb 
 from (select bytes from v$sgastat 
        union 
       select value bytes 
         from v$sesstat s, v$statname n 
        where n.STATISTIC# = s.STATISTIC# 
          and n.name = 'session pga memory' ); 

prompt
prompt Report End
spool off


