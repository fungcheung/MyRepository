#!/bin/ksh
## Filename: orarpt_chksession_pga_memory.sh
## Usage: ./orarpt_chksession_pga_memory.sh  

ORACLE_HOME=/data/oracle/product/9.2.0.4  
export ORACLE_HOME

TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN

ADMIN=samson.wk.cheung@db.com 
export ADMIN

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

ORACLE_SID=IRPS_DEV
export ORACLE_SID

$ORACLE_HOME/bin/sqlplus chowke/chowk999@IRPS_DEV <<EOM
@/home/oracle/dbasql/orarpt_chk_session_pga_memory.sql
EOM

ls -l   /home/oracle/dbasql/IRPS_shacmirpsp2_chk_session_pga_memory.spo
/usr/bin/cat /home/oracle/dbasql/IRPS_shacmirpsp2_chk_session_pga_memory.spo >> /home/oracle/dbasql/ORARPT_CHKSESSION_PGA_MEMORY.log

if [ -f /home/oracle/dbasql/ORARPT_CHKSESSION_PGA_MEMORY.log ] ; then
   ## /usr/bin/cat /home/oracle/dbasql/ORARPT_CHKSESSION_PGA_MEMORY.log | /usr/bin/mailx  -s "Warning Report - `date '+%y%m%d'`" $ADMIN
   echo ......
   ## /usr/bin/cat /home/oracle/dbasql/ORARPT_CHKSESSION_PGA_MEMORY.log | /usr/bin/mailx  -s "PGA MEMORY Report - `date '+%y%m%d'`" $ADMIN 

fi

exit 0
