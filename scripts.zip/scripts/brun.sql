set lines 200 pages 200 head off
-- select name, value, isdefault, description from v$parameter where name = 'processes';
show parameter db_block_size