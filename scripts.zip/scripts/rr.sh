#!/bin/sh 

$ORACLE_HOME/bin/sqlplus "/ as sysdba" << EOF
alter system switch logfile;
alter system archive log current;
EOF

