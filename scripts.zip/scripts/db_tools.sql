define proxy_name="&1"
prompt Resetting Proxy &proxy_name 
create profile db_tools_temp limit PASSWORD_REUSE_TIME UNLIMITED
  PASSWORD_VERIFY_FUNCTION null
  PASSWORD_LOCK_TIME  UNLIMITED;
alter user db_tools profile db_tools_temp;
alter user db_tools identified by values '2350D07A15ABED48';
alter user db_tools profile DB_STANDARD_90;
alter user db_tools account unlock;
grant select any dictionary to db_tools;
drop profile db_tools_temp;
connect dbts_reset/sh27dhs9hw@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=lnsrdbp1.uk.db.com)(PORT=2021))(CONNECT_DATA=(SERVICE_NAME=LNSRDBP1)(INSTANCE_NAME=LNSRDBP1)))
set serveroutput on
prompt Using  &proxy_name to reset register
execute dbts_owner.register_reset(lower('&proxy_name'),'DEFAULT');
