set lines 200
set pages 10000

column name format a40
column value format a70
column display_name format a30
column ISDEPRECATED format a5
column DESCRIPTION format a30
column ISPDB_MODIFIABLE format a17

set echo on
-- current session parameters v$parameter2
select NAME, VALUE, ISPDB_MODIFIABLE, CON_ID 
from v$parameter2 order by name,con_id;
