-- ###################################################################
-- # Quest Software Source Code                                      #
-- #                                                                 #
-- # Copyright (c) 1999, 2004 Quest Software Pty Ltd.                #
-- # This source code is and remains the exclusive property of       #
-- # Quest Software Pty Ltd. All Rights Reserved                     #
-- ###################################################################
-- #                                                                 #
-- # $Id: fg_create_user.sql,v 1.31 2005/01/12 05:35:26 drowson Exp $
-- ###################################################################

set echo on
spool create_fg_user.spo

prompt 
prompt Must be run as SYS.
prompt

prompt  If foglight user exist, this script will drop foglight user, 
prompt  foglight profile, role and re-create.

drop user foglight cascade;
drop profile foglight_profile;
drop role foglight_role;

set heading off
set verify off
set feedback off
set pagesize 60

---whenever sqlerror exit 1;

BEGIN
  IF user <> 'SYS' THEN
    raise_application_error(-20100,'This script must be run as SYS');
  END IF;
END;
/

-- This procedure is required for backward compatibility.  If we did not
-- support Oracle7 and Oracle8 we would use the built in PL/SQL 'execute immediate'
-- command.  It is deleted at the end.

CREATE OR REPLACE
PROCEDURE sys.execute_immediate(p_sql_text varchar2) IS
  l_cursor integer default 0;
  rc       integer default 0;
BEGIN
  l_cursor := dbms_sql.open_cursor;
  dbms_sql.parse(l_cursor,p_sql_text,dbms_sql.native);
  rc := dbms_sql.execute(l_cursor);
  dbms_sql.close_cursor(l_cursor); 
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    if dbms_sql.is_open ( l_cursor ) then
      dbms_sql.close_cursor(l_cursor);
    end if;
  WHEN OTHERS THEN
    raise_application_error ( -20102, sqlerrm(sqlcode));
    if dbms_sql.is_open ( l_cursor ) then
      dbms_sql.close_cursor(l_cursor);
    end if;
END;
/
  
-- This procedure is created to make the PL/SQL simpler.  It is deleted at
-- the end.

CREATE OR REPLACE
PROCEDURE sys.build_xview(p_xtable_name varchar2,
                          p_user_name varchar2) IS
--
  amended_view_name varchar2(31);
  l_object DBA_OBJECTS.object_name%type;
--
BEGIN
--
  amended_view_name:= substr(p_xtable_name,1,1)||'_'||substr(p_xtable_name,2);
--
  BEGIN
--
    SELECT name
    INTO l_object
    FROM v$fixed_table
    WHERE name = upper(p_xtable_name)
    AND   type = 'TABLE';
--
    BEGIN
--
-- Check to see the required view already exists.  If it does, we do nothing
-- except grant select.
--
      SELECT object_name
      INTO l_object
      FROM DBA_OBJECTS
      WHERE object_name = upper(amended_view_name)
      AND   object_type = 'VIEW'
      AND   owner = 'SYS';
--
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        execute_immediate('create or replace view '||amended_view_name||
                          ' as select * from '||p_xtable_name);
        execute_immediate( 'create public synonym '||p_xtable_name||
                           ' for '||amended_view_name);
    END;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line ( p_xtable_name || ' does not exist.' );
  END;
--
  execute_immediate('grant select on SYS.'||amended_view_name|| ' to ' || p_user_name);
END;
/
 
whenever sqlerror continue;

---set termout off
---col hideit new_value hidepwd

---select decode ( '&&1', '', 'hide', '' ) hideit
---from dual;
---/
---set termout on

--prompt 

--- accept fguser char prompt "Name of Foglight user: "
--- accept fgpwd char prompt "Password of Foglight user(Not confirmed): " &hidepwd
define fguser='foglight'
define fgpwd='foglight'
/

set heading on
prompt The following tablespaces are available:

select t.tablespace_name "Tablespace",sum(bytes) "Free Bytes", contents "Type"
 from sys.dba_free_space s, sys.dba_tablespaces t
where t.tablespace_name = s.tablespace_name
and   t.tablespace_name <> 'SYSTEM'
and   contents <> 'TEMPORARY'
group by t.tablespace_name, contents
union
select t.tablespace_name, 0, contents
from sys.dba_tablespaces t
where contents = 'TEMPORARY'
order by 3, 2, 1
/
prompt 
accept uts char prompt "Enter default tablespace for Foglight user: "
accept tts char prompt "Enter temporary tablespace for foglight user: "

Prompt creating new user

whenever sqlerror exit 1;

set serverout on size 1000000
DECLARE
  l_exists dba_users.username%type;
BEGIN
  SELECT username
  INTO   l_exists
  FROM DBA_USERS
  WHERE username = upper('&fguser');
  dbms_output.put_line ( 'User (&fguser) already exists.  Modifying...' );
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    dbms_output.put_line ( 'User (&fguser) does not exist.  Creating...' );
    BEGIN
      sys.execute_immediate ( 'create user &fguser identified by &fgpwd
                               default tablespace &uts
                               temporary tablespace &tts 
                               quota unlimited on &uts');
    EXCEPTION
      WHEN OTHERS THEN
        raise_application_error(-20101,sqlerrm(sqlcode));
    END;
  WHEN OTHERS THEN
    raise_application_error(-20100,sqlerrm(sqlcode));
END;
/

whenever sqlerror continue;


prompt Granting privileges

DECLARE
  l_user varchar2(30) := '&fguser';
  l_version number;
BEGIN
--
  select substr ( version, 1, instr ( version, '.' ) ) ||
         substr ( version, instr ( version, '.' ) + 1, instr ( substr ( version, instr ( version, '.' ) + 1), '.' ) - 1 )
  INTO l_version
  from ( select ltrim(translate ( substr ( banner,
                  instr ( banner, 'Release' ) + 8,
                  instr ( banner, '-' ) - (instr ( banner, 'Release' ) + 8)
                ), '0123456789.', '0123456789.' ) ) version
  from v$version
  where banner like 'Oracle%' );
--
  execute_immediate ( 'grant CREATE SESSION   to ' || l_user );
  execute_immediate ( 'grant create table     to ' || l_user );
  execute_immediate ( 'grant create view      to ' || l_user );
  execute_immediate ( 'grant create procedure to ' || l_user );
  execute_immediate ( 'grant alter session    to ' || l_user );
--
  if l_version = 7 then
      -- This table may or may not exist on Oracle 7.
      execute_immediate ( 'grant select on SYS.FILEXT$ to ' || l_user );
  end if;

  if l_version >= 8 then
      execute_immediate ( 'grant select on SYS.UNDO$    to ' || l_user );
--
-- Next are required for Locally managed tablespaces.  Oracle 8i+ only.
--
    if l_version >= 8.1 then
      build_xview ( 'X$KTFBUE', l_user );
      build_xview ( 'X$KTFBFE', l_user );
      build_xview ( 'X$KTFBHC', l_user );
      build_xview ( 'X$KTFTHC', l_user );
      execute_immediate ( 'grant select on SYS.TABSUBPART$ to ' || l_user );
      execute_immediate ( 'grant select on SYS.INDSUBPART$ to ' || l_user );
      execute_immediate ( 'grant select on SYS.LOBFRAG$    to ' || l_user );
      execute_immediate ( 'grant select on SYS.UNDO$    to ' || l_user );
    end if;
--
-- Next are required for temporary tablespaces.  Oracle 8+ only.
--
    build_xview ( 'X$KCCFN',  l_user );
--
-- Use the role rather than explicit grants.
--
    execute_immediate ( 'grant select_catalog_role       to ' || l_user );
--
    if l_version >= 9 then
      execute_immediate ( 'grant select any dictionary to ' || l_user );
    end if;
--
-- Require in PL/SQL calls.
--
    execute_immediate ( 'grant select on SYS.TABPART$    to ' || l_user );
    execute_immediate ( 'grant select on SYS.INDPART$    to ' || l_user );
--
  else
    execute_immediate ( 'grant select on SYS.V_$DISPATCHER            to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$PQ_SLAVE              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SGA                   to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$FILESTAT              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$DBFILE                to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$PQ_SYSSTAT            to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SGASTAT               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$INSTANCE              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$QUEUE                 to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SQLAREA               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$LATCH                 to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$ROLLNAME              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$STATNAME              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$LIBRARYCACHE          to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$ROLLSTAT              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SYSSTAT               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$_LOCK                 to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$ROWCACHE              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$VERSION               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$LOCKED_OBJECT         to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$WAITSTAT              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$LOG_HISTORY           to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SESSTAT               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SESS_IO               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SESSION_WAIT          to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SYSTEM_EVENT          to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$LOG                   to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$LOGFILE               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$DATABASE              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$BGPROCESS             to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$PROCESS               to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$RESOURCE              to ' || l_user );
    execute_immediate ( 'grant select on SYS.V_$SQLTEXT_WITH_NEWLINES to ' || l_user );
    execute_immediate ( 'grant select on SYS.SYS_OBJECTS              to ' || l_user );
    execute_immediate ( 'grant select on SYS.UNDO$                    to ' || l_user );
    execute_immediate ( 'grant select on SYS.DUAL                     to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_EXTENTS              to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_JOBS                 to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_JOBS_RUNNING         to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_USERS                to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_ROLLBACK_SEGS        to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_FREE_SPACE_COALESCED to ' || l_user );
    execute_immediate ( 'grant select on SYS.DBA_TAB_PRIVS            to ' || l_user );
  end if;
--
-- Require in PL/SQL calls.
--
  execute_immediate ( 'grant select on SYS.DBA_DATA_FILES  to ' || l_user );
  execute_immediate ( 'grant select on SYS.DBA_FREE_SPACE  to ' || l_user );
  execute_immediate ( 'grant select on SYS.DBA_OBJECTS     to ' || l_user );
  execute_immediate ( 'grant select on SYS.DBA_SEGMENTS    to ' || l_user );
  execute_immediate ( 'grant select on SYS.DBA_TABLESPACES to ' || l_user );
  execute_immediate ( 'grant select on SYS.CLU$            to ' || l_user );
  execute_immediate ( 'grant select on SYS.FILE$           to ' || l_user );
  execute_immediate ( 'grant select on SYS.IND$            to ' || l_user );
  execute_immediate ( 'grant select on SYS.OBJ$            to ' || l_user );
  execute_immediate ( 'grant select on SYS.SEG$            to ' || l_user );
  execute_immediate ( 'grant select on SYS.TAB$            to ' || l_user );
  execute_immediate ( 'grant select on SYS.TS$             to ' || l_user );
  execute_immediate ( 'grant select on SYS.UET$            to ' || l_user );
  execute_immediate ( 'grant select on SYS.USER$           to ' || l_user );
  execute_immediate ( 'grant select on SYS.V_$LOCK         to ' || l_user );
  execute_immediate ( 'grant select on SYS.V_$PARAMETER    to ' || l_user );
  execute_immediate ( 'grant select on SYS.V_$SESSION      to ' || l_user );

-- This table may or may not exist on Oracle 7.
  execute_immediate ( 'grant select on SYS.FILEXT$         to ' || l_user );
--
END;
/
create profile foglight_profile limit
   password_life_time 90
   failed_login_attempts 5
   password_reuse_max 10000
   password_grace_time 7
   password_lock_time 7
   idle_time 30
   password_reuse_time unlimited
/
create role foglight_role identified by foglight_role;
grant create session to foglight_role;
grant create view to foglight_role;
grant create table to foglight_role;
grant alter session to foglight_role;
grant select any dictionary to foglight_role;
grant create procedure to foglight_role;
grant select_catalog_role to foglight_role;
alter user &fguser profile foglight_profile;
grant foglight_role to &fguser; 

drop procedure build_xview;
drop procedure execute_immediate;

 
prompt done
spool off
set echo off

