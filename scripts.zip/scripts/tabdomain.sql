prompt Enter the table name to show its domains

set pages 200 lines 200
column Table_name format a60		
column Domain format a60		

SELECT
  sde.gdb_items_vw.Name as Table_name, Domain.Name as Domain 
FROM (
	(
		-- Get the domain item's UUID.
		SELECT GDB_ITEMS_VW.UUID AS UUID, GDB_ITEMS_VW.Name as Name 
		FROM sde.gdb_items_vw INNER JOIN sde.gdb_itemtypes
			ON sde.gdb_items_vw.Type = sde.gdb_itemtypes.UUID
		WHERE	sde.gdb_items_vw.Name in (
SELECT gdb_items_vw.Name AS NAME
		FROM sde.gdb_items_vw INNER JOIN sde.gdb_itemtypes
			ON sde.gdb_items_vw.Type = sde.gdb_itemtypes.UUID
		WHERE	sde.gdb_itemtypes.Name IN ('Coded Value Domain','Range Domain'))
		AND
			sde.gdb_itemtypes.Name IN ('Coded Value Domain','Range Domain')
    	) Domain
	-- Find the relationships with the domain as the DestinationID.
	INNER JOIN sde.gdb_itemrelationships
		ON Domain.UUID = sde.gdb_itemrelationships.DestID
) 
-- Find the names of the origin items in the relationships.
INNER JOIN sde.gdb_items_vw
	ON sde.gdb_items_vw.UUID = sde.gdb_itemrelationships.OriginID and lower(sde.gdb_items_vw.Name) like lower('%&&1%') order by 1,2;
