#!/bin/ksh
## Filename: mig_TWXBOS.sh

echo `date` Scp-ing  .......
date ; ls -ltr /home/oracle/backup/expimp/XBOS_fullexp.dmp.Z

### last night copy
## /usr/bin/scp -p  tpexbosdbp1:/tpexbosdbp1/export/oracle/u004/XBOS/backup/export/XBOS_fullexp.dmp.Z \
##                             /home/oracle/backup/expimp/XBOS_fullexp.dmp.Z

date ; ls -ltr /home/oracle/backup/expimp/XBOS_fullexp.dmp.Z

ORACLE_SID=TWXBOS ; export ORACLE_SID   
ORACLE_HOME=/data/oracle/TWXBOS/product/10.2.0.3 ; export ORACLE_HOME
LD_LIBRARY_PATH=$ORACLE_HOME/lib ;  export LD_LIBRARY_PATH
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ; export PATH
NLS_LANG=AMERICAN_AMERICA.ZHT16BIG5 ; export NLS_LANG

$ORACLE_HOME/bin/sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
create spfile from pfile ;
startup
EOF

echo `date` Pre_import  .......
$ORACLE_HOME/bin/sqlplus / @/data/oracle/TWXBOS/home/dbasql/pre_TWXBOS_imp.sql > /data/oracle/TWXBOS/home/dbasql/pre_TWXBOS_imp.log 2>&1

echo `date` WIP_import  .......
date   >  /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS.log 2>&1
/data/oracle/TWXBOS/home/dbasql/imp_TWXBOS.sh  >> /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS.log 2>&1
date  >>  /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS.log 2>&1

echo `date` Post_import  .......
$ORACLE_HOME/bin/sqlplus / @/data/oracle/TWXBOS/home/dbasql/post_TWXBOS_imp.sql > /data/oracle/TWXBOS/home/dbasql/post_TWXBOS_imp.log 2>&1

echo `date` Mailing  .......
cat /data/oracle/TWXBOS/home/dbasql/imp_TWXBOS.log | uuencode TWXBOS_import.log | /usr/bin/mailx -r sl2.apho@db.com -s "Import Finished ${ORACLE_SID}@`hostname`" samson.wk.cheung@db.com

$ORACLE_HOME/bin/sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
startup
EOF

echo Completed `date`
#
