
--
-- Generate rGIH WDB views based on existing table structure under RGIHAPP schema
--
set pages 200 lines 500
SELECT 'create or replace view RVIEW.VW_' || case table_name 
when 'BATCH_STEP_EXECUTION_CONTEXT' then 'BATCH_STEP_EXEC_CONTEXT' 
when 'RLT_APPMEG_MAP_LAYER_CATEGORY' then 'RLT_APPMEG_MAP_LAYER_CAT' 
when 'RLT_APPMGT_MAP_SERVICE_ACCESS' then 'RLT_APPMGT_MAP_SERV_ACCESS' 
when 'TBL_APPMGT_SESSION_ATTRIBUTES' then 'TBL_APPMGT_SESS_ATTRIBUTES' 
else table_name end || ' as select ' ||
       LISTAGG(column_name, ',') WITHIN GROUP (ORDER BY column_id) || ' from RGIHAPP.' || table_name || ';'
FROM dba_tab_columns 
where owner='RGIHAPP' and table_name not like 'BIN$%'
GROUP BY table_name;



