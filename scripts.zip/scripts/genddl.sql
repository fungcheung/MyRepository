set pages 2000 lines 200
col object_name format a50
col owner format a30
col object_type format a30

set pagesize 0
set long 90000
set feedback off
set echo off
set verify off

exec DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'STORAGE',false);
exec DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'SEGMENT_ATTRIBUTES',false);


select  dbms_metadata.GET_DDL(object_type,object_name,owner) from dba_objects
where object_name like upper('%&name%') and object_type in ('TABLE','VIEW','INDEX','SEQUENCE') order by object_name;
