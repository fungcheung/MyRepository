select prop_name,char_prop_value from SDE.SERVER_CONFIG where prop_name='AUTH_KEY';

exit;
