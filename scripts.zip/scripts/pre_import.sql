

-- filename: /hkgresdbp1/export/oracle/u001/admin/ACE/adhoc/pre_import.sql 
set echo on pages 999 lines 222

drop user ACE            cascade ;
drop user ACELOAD        cascade ;
drop user ACELOADER      cascade ;
drop user ACEOUT         cascade ;
drop user ACEREPORTER    cascade ;
drop user ACEWEB         cascade ;
drop user AUS_USER       cascade ;
drop user BBGTERM        cascade ;
drop user HNK_ACEADMIN   cascade ;
drop user IBCP           cascade ;
drop user OPS$ACELOAD    cascade ;
drop user OPS$RAWLMA     cascade ;
drop user OPS$TSANGM     cascade ;
drop user OPS$WONGLE     cascade ;
drop user RAWLMA         cascade ;
drop user READONLY       cascade ;
drop user REPORTER       cascade ;
drop user TSANGM         cascade ;
drop user WCWW           cascade ;
drop user WEB            cascade ;
drop user WONGLE         cascade ;
drop user MIS            cascade ;
drop user MISCMSWEB      cascade ;
drop user MISREPORTER    cascade ;
drop user MISWEB         cascade ;

drop user AURORA$ORB$UNAUTHENTICATED   cascade ;
drop user EXP                     cascade ;
drop user MOSHEA                  cascade ;
drop user QUANT                   cascade ;
drop user TRACESVR                cascade ;


alter tablespace ACERAW_IDX coalesce ;
alter tablespace ACERAW_TAB coalesce ;
alter tablespace ACERPT_IDX coalesce ;
alter tablespace ACERPT_TAB coalesce ;
alter tablespace ACETMP_IND coalesce ;
alter tablespace ACETMP_TAB coalesce ;
alter tablespace MISRAW_IDX coalesce ;
alter tablespace MISRAW_TAB coalesce ;
alter tablespace MISRPT_IDX coalesce ;
alter tablespace MISRPT_TAB coalesce ;
alter tablespace RBS coalesce ;
alter tablespace SYSTEM coalesce ;
alter tablespace TEMP coalesce ;
alter tablespace TOOLS coalesce ;

create user ACE
identified by ACE123
default tablespace ACERPT_TAB
temporary tablespace TEMP
quota unlimited on ACERPT_TAB
quota unlimited on ACERPT_IDX
quota unlimited on ACETMP_IND
quota unlimited on ACERAW_TAB
quota unlimited on ACERAW_IDX
quota unlimited on ACETMP_TAB
/

grant CONNECT to ace ;

exit

