-- Filename: get_dbfiles.sql


@db

set echo off lines 88 pages 999
col name for a55
col member for a55

select '-- Controlfiles: ' from dual
union all
select name from v$controlfile
union all
select '-- Datafiles: ' from dual
union all
select name from v$datafile
union all
select '-- Tempfiles: ' from dual
union all
select name from v$tempfile
union all
select '-- Redo Logfiles: ' from dual
union all
select member from v$logfile
union all
select '-- Archive Logfiles: ' from dual
union all
select value from v$parameter
where name like '%log_archive_dest%'
and name not like '%log_archive_dest_stat%'
and value is not null
/

set echo off

