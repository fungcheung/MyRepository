-- fiilename: root.sql


alter session set container=cdb$root;

show con_name;


