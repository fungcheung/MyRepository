CREATE OR REPLACE TRIGGER logon_check after logon on database
declare
        logonip varchar2(50);
        logonhost varchar2(50);
        logonuser varchar2(50);
        logonosuser varchar2(50);

begin
        select sys_context('userenv','host') into logonhost from dual;
        select sys_context('userenv','ip_address') into logonip from dual;
        select sys_context('userenv','session_user') into logonuser from dual;
        select sys_context('userenv','os_user') into logonosuser from dual;
	if logonip is null
	then
        	logonip:=UTL_INADDR.get_host_address(logonhost);
	end if;

        if logonuser = 'STPDEV4'
        then
	        if logonip <> '10.153.206.221' and logonip <>'127.0.0.1'
       		then
                	raise_application_error (-20001,'Access restricted from this IP address: '||logonip||', host: '||logonhost);
        	end if;

	        if (logonosuser <> 'stpdev4') and (logonosuser <> 'HBSTPD1')
        	then
                	raise_application_error (-20001,'Access restricted for this OS user');
        	end if;
        end if;
exception
	        when others then
                raise_application_error(-20003, substr(SQLERRM,1,500));
end;
/

