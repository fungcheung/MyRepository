prompt Enter parameter
show parameter &p