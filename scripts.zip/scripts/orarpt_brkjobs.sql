-- 
-- Filename: orarpt_brkjobs.sql
-- 

clear column
set lines 222 pages 999

alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ; 
select sysdate from dual ;

-- Check broken jobs
select  job||decode(broken,'Y','-Broken  ','')||log_user||' '||what||' '||failures
from dba_jobs
where (broken='Y' or failures >0)
order by 1 ; 

exit

