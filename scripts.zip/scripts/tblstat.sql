set linesize 200 pages 999

col owner format a20
col segname format a15
col table_name format a20
col tablespace_name format a10

prompt =========================================================================================================================================================
prompt Enter table name

select t.owner, t.table_name, t.tablespace_name, t.status, t.num_rows, s.bytes/1024/1024 Size_M,  t.chain_cnt, t.last_analyzed, t.monitoring, t.compression, t.initial_extent, t.next_extent, s.extents, t.max_extents
from dba_tables t, dba_segments s
where t.owner = s.owner and
t.table_name = s.segment_name and
s.segment_type='TABLE' and
t.table_name = upper('&table')
;


prompt =========================================================================================================================================================
prompt Enter schema name

select t.owner, t.table_name, t.tablespace_name, t.status, t.num_rows, s.bytes/1024/1024 Size_M,  t.chain_cnt, t.last_analyzed, t.monitoring, t.compression, s.extents, t.max_extents
from dba_tables t, dba_segments s
where t.owner = s.owner and
t.table_name = s.segment_name and
s.segment_type='TABLE' and
t.owner = upper('&owner')
order by Size_M
;

