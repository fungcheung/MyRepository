prompt
prompt show how to investigate database hang
prompt


prompt 1. sqlplus -prelim / as sysdba
prompt 2. sql> oradebug setmypid
prompt 3. sql> oradebug hanganalyze 12
prompt 4. investigate the newly generated dump file in user dump dest. Look for such as "waiting for" keywords.
prompt




