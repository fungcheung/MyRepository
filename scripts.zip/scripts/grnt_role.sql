-- fiilename: grnt_role.sql

col GRANTOR  for a22
col GRANTEE  for a22 
col TABLE_SCHEMA  for a11 head 'Owner'
col TABLE_NAME for a33 head 'Objs'
col PRIVILEGE for a9 head 'Privs'
col GRANTABLE for a11 

undef 1

select * from dba_role_privs
where GRANTEE like upper('%&&1%')
or GRANTED_ROLE like upper('%&&1%') ;

undef 1

