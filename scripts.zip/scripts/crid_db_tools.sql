rem Must be run as sysdba

set pages 999 lines 99 feed on head on echo off term on
spool db_tools.spo

rem Note that these functions and profiles are not CREATE OR REPLACE 
rem so that they do not replace any existing ones

select object_name from dba_objects where object_name = 'PWD_VERIFY_FUNCTION' ;

CREATE   FUNCTION PWD_VERIFY_FUNCTION
        ( p_username     IN varchar2,
          p_new_password IN varchar2,
          P_old_password IN varchar2
        )
RETURN boolean
IS
/*
    ############################################################################
    # Module      : PWD_VERIFY_FUNCTION
    # Author      : Martin Jones
    # Date        : 5th April 2004
    #
    # Description : This function is used to verify the complexity of the user
    #               supplied password.
    ############################################################################
    #
    # CHANGE HISTORY
    # ==============
    # DATE          WHO     COMMENTS
    #===========================================================================
    # 05/04/2004    jonemj  New script.
    #===========================================================================
    # 09/11/2004    carman  Cleanup format and rename variables for script
    #                       inclusion in 'DMG' installation process.
    #===========================================================================
    # 12/11/2004    carman  Fix 'NULL' password parameter check.
    #===========================================================================
    ############################################################################
*/
   password_length      integer;
   password_difference  integer;
   has_digit            boolean;
   has_char             boolean;
   has_punct            boolean;

   digitarray           varchar2(20);
   punctarray           varchar2(25);
   chararray            varchar2(52);

BEGIN

   digitarray := '0123456789';
   chararray  := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   punctarray := '!"#$%&()''*+,-/:;<=>?_';

--Check if the old or new password is NULL
IF p_new_password is NULL THEN
   raise_application_error(-20001,' New Password can not be NULL');
END IF;

--Check if the password is same as the username
IF p_new_password = p_username THEN
   raise_application_error(-20002,' Password can not be same as username');
END IF;

--Check for the minimum length of the new password
IF length(p_new_password) < 8 THEN
   raise_application_error(-20003,' Password length less than 8');
END IF;

--Check if the password is too simple. A dictionary of words may be
--maintained and a check may be made so as not to allow the words
--that are too simple for the password.
IF NLS_LOWER(p_new_password) IN ('welcome', 'database', 'account', 'user',
                           'password', 'oracle', 'computer', 'abcd') THEN
   raise_application_error(-20004, ' Password too simple');
END IF;

--Check if the password contains at least one digit, one alpabetic character
-- and one punctuation mark.
--
has_digit       := FALSE;
has_char        := FALSE;
has_punct       := FALSE; 
password_length := length(p_new_password);

--1. Check at least one digit in passsword
FOR i IN 1..length(digitarray) LOOP
  FOR j IN 1..password_length LOOP
    IF substr(p_new_password,j,1) = substr(digitarray,i,1) THEN
       has_digit:=TRUE;
       GOTO findchar;
    END IF;
  END LOOP;
END LOOP;

--2. Check at least one alphabetic character in password
<<findchar>> 
FOR i IN 1..length(chararray) LOOP
  FOR j IN 1..password_length LOOP
    IF substr(p_new_password,j,1) = substr(chararray,i,1) THEN
       has_char:=TRUE;
       GOTO findpunct;
    END IF;
  END LOOP;
END LOOP;

--3. Check at least one punctuation character in password
<<findpunct>> 
FOR i IN 1..length(punctarray) LOOP  
  FOR j IN 1..password_length LOOP  
    IF substr(p_new_password,j,1) = substr(punctarray,i,1) THEN 
       has_punct:=TRUE; 
       GOTO endproc; 
    END IF; 
  END LOOP; 
END LOOP; 

<<endproc>>
IF has_digit = FALSE
or has_char  = FALSE
or has_punct = FALSE THEN
   raise_application_error(-20005, 'Password should contain at least one digit, one alphabetic and one punctuation character');
END IF;

--Check if the new password differs from the old password by at least
-- 3 characters
IF length(p_new_password) < length(p_old_password) THEN
   password_difference := length(p_old_password) - length(p_new_password);
   password_length     := length(p_new_password);
ELSE
   password_difference := length(p_new_password) - length(p_old_password);
   password_length     := length(p_old_password);
END IF;

IF abs(password_difference) < 3 THEN
   password_difference := abs(password_difference);
   FOR i IN 1..password_length LOOP
     IF ASCII(substr(p_new_password,i,1)) != ASCII(substr(p_old_password,i,1))
        THEN
        password_difference := password_difference + 1;
     END IF;
   END LOOP;
   IF password_difference < 3 THEN
      raise_application_error(-20006, 'Password should differ by at least 3 characters');
   END IF;
END IF;

--Everything is fine so return TRUE
RETURN(TRUE);
END;
/

select object_name from dba_objects where object_name = 'PWD_VERIFY_FUNCTION' ;
select distinct PROFILE from dba_profiles ;


create profile db_standard_90
    LIMIT IDLE_TIME                     UNLIMITED
          COMPOSITE_LIMIT               UNLIMITED
          CONNECT_TIME                  UNLIMITED
          CPU_PER_CALL                  UNLIMITED
          CPU_PER_SESSION               UNLIMITED
          LOGICAL_READS_PER_CALL        UNLIMITED
          LOGICAL_READS_PER_SESSION     UNLIMITED
          PASSWORD_REUSE_TIME           UNLIMITED
          PRIVATE_SGA                   UNLIMITED
          SESSIONS_PER_USER             UNLIMITED
          FAILED_LOGIN_ATTEMPTS         UNLIMITED
          PASSWORD_GRACE_TIME           7
          PASSWORD_LIFE_TIME            90
          PASSWORD_LOCK_TIME            UNLIMITED   
          PASSWORD_REUSE_MAX            12
          PASSWORD_VERIFY_FUNCTION      PWD_VERIFY_FUNCTION;

create profile db_standard_30
    LIMIT IDLE_TIME                     UNLIMITED
          COMPOSITE_LIMIT               UNLIMITED
          CONNECT_TIME                  UNLIMITED
          CPU_PER_CALL                  UNLIMITED
          CPU_PER_SESSION               UNLIMITED
          LOGICAL_READS_PER_CALL        UNLIMITED
          LOGICAL_READS_PER_SESSION     UNLIMITED
          PASSWORD_REUSE_TIME           UNLIMITED
          PRIVATE_SGA                   UNLIMITED
          SESSIONS_PER_USER             UNLIMITED
          FAILED_LOGIN_ATTEMPTS         UNLIMITED
          PASSWORD_GRACE_TIME           7
          PASSWORD_LIFE_TIME            30
          PASSWORD_LOCK_TIME            UNLIMITED   
          PASSWORD_REUSE_MAX            12
          PASSWORD_VERIFY_FUNCTION      PWD_VERIFY_FUNCTION;

CREATE PROFILE DEFAULT_APPLICATION_PROFILE
    LIMIT IDLE_TIME                     60
          COMPOSITE_LIMIT               UNLIMITED
          CONNECT_TIME                  UNLIMITED
          CPU_PER_CALL                  UNLIMITED
          CPU_PER_SESSION               UNLIMITED
          LOGICAL_READS_PER_CALL        UNLIMITED
          LOGICAL_READS_PER_SESSION     UNLIMITED
          PASSWORD_REUSE_TIME           UNLIMITED
          PRIVATE_SGA                   UNLIMITED
          SESSIONS_PER_USER             3
          FAILED_LOGIN_ATTEMPTS         3
          PASSWORD_GRACE_TIME           7
          PASSWORD_LIFE_TIME            90
          PASSWORD_LOCK_TIME            UNLIMITED
          PASSWORD_REUSE_MAX            12
          PASSWORD_VERIFY_FUNCTION      PWD_VERIFY_FUNCTION;


select distinct PROFILE from dba_profiles ;
select username from dba_users where username ='db_tools' ;

select tablespace_name from dba_tablespaces order by 1 ;

create user db_tools identified by values '2350D07A15ABED48'
default tablespace &default_ts temporary tablespace &temp_ts;

rem     profile  db_standard_90;
grant create session  to db_tools;
grant restricted session to db_tools;
grant select any table  to db_tools;
grant select any dictionary  to db_tools;

spool off

