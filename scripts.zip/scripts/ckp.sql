-- Check keep pool usage
prompt Check keep pool usage
select obj.owner, obj.object_name, obj.object_type,
    count(buf.block#) as cached_blocks,
    tab.blocks as total_blocks,
    tab.buffer_pool as Cache
from v$bh buf
inner join dba_objects obj
    on buf.objd = obj.data_object_id
inner join dba_tables tab
    on tab.owner = obj.owner
    and tab.table_name = obj.object_name
    and obj.object_type in ('TABLE','INDEX')
where buf.class# = 1
and buf.status != 'free'
and obj.owner in ('RMAPAPP','RDATAAPP','RVIEW')
and obj.object_type in ('TABLE','INDEX')
and tab.buffer_pool = 'KEEP'
group by obj.owner, obj.object_name, obj.object_type,
    tab.blocks, tab.buffer_pool
/   

prompt Estimated keep pool total size in bytes (1.5 times)
select (sum(s.bytes)*1.5) from   dba_segments s where    s.buffer_pool = 'KEEP'; 

