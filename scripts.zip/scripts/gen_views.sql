
--
-- Generate view based on existing table structure of input owner and table name
--
-- prompt Enter owner and table name to generate its view

set pages 200 lines 500
SELECT 'create or replace view VW_' || case table_name 
when 'BATCH_STEP_EXECUTION_CONTEXT' then 'BATCH_STEP_EXEC_CONTEXT' 
when 'RLT_APPMEG_MAP_LAYER_CATEGORY' then 'RLT_APPMEG_MAP_LAYER_CAT' 
when 'RLT_APPMGT_MAP_SERVICE_ACCESS' then 'RLT_APPMGT_MAP_SERV_ACCESS' 
when 'TBL_APPMGT_SESSION_ATTRIBUTES' then 'TBL_APPMGT_SESS_ATTRIBUTES' 
else table_name end || ' as select ' ||
       LISTAGG(column_name, ',') WITHIN GROUP (ORDER BY column_id) || ' from ' || table_name || ';'
FROM dba_tab_columns 
where owner=upper('&&1') and table_name not like 'BIN$%' and lower(table_name) = lower('&2') 
GROUP BY table_name;



