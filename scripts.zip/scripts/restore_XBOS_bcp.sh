#!/bin/ksh
## Filename: restore_XBOS_bcp.sh

export ORACLE_BASE=/tpexbosdbp1/export/oracle/u001/
export ORACLE_HOME=/tpexbosdbp1/export/oracle/product/9.2.0.4
export PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/ucb:$PATH
export ORACLE_SID=XBOS
export ORA_NLS33=$ORACLE_HOME/ocommon/nls/admin/data
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/product/jlib
export ORA_ADMIN=$ORACLE_HOME/admin
export TNS_ADMIN=$ORACLE_HOME/network/admin
export NLS_LANG=AMERICAN_AMERICA.ZHT16BIG5

export PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle:/tpexbosdbp1/infra/cron/bin


date ; 'Scp-ing backup files .....'
date ; ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/*
date ; rm    /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/*
date ; ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/*
date ; /usr/bin/scp -p  tpexbosdbp1:/tpexbosdbp1/export/oracle/u004/XBOS/backup/database/*  /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/
date ; ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/*

date ; echo 'Shutting down XBOS  database .....'
ORACLE_SID=XBOS ; export ORACLE_SID
ORACLE_HOME=/tpexbosdbp1/export/oracle/product/9.2.0.4 ; export ORACLE_HOME
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ;
export PATH

sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
EOF

date ; echo 'Uncompressing datafiles ..... ' 
cat /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/restore.ksh | grep -v exit > /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/restore2.ksh 

date ; echo 'tail -f /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/restore2.out'
ksh /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/restore2.ksh  > /tpexbosdbp1/export/oracle/u004/XBOS/backup/database/restore2.out

date ; echo 'Recovering database ..... ' 
ORACLE_SID=XBOS ; export ORACLE_SID
sqlplus "/as sysdba"  << EOF
shutdown immediate ;
startup mount ;
SET AUTORECOVERY ON ;
recover database using backup controlfile until cancel ;
alter database open resetlogs  ;

alter tablespace temp1 add tempfile '/tpexbosdbp1/export/oracle/u002/XBOS/oradata/XBOS_temp02.dbf' reuse ;
alter tablespace temp1 tempfile online ;

exit
EOF

date ; echo 'Complete ..... ' 

exit 0

