spool housekeep157gih.log


purge tablespace eric user eric;
purge tablespace wivina user wivina;
purge tablespace clement user clement;
purge tablespace conny user conny;
purge tablespace mandy user mandy;
purge tablespace kam user kam;
purge tablespace frankie user frankie;
purge tablespace eric2 user eric2;
purge tablespace herman user herman;
purge tablespace mandy1 user mandy1;
purge tablespace lands user lands;
purge tablespace cliff user cliff;
purge tablespace dias user dias;
purge tablespace adm user frankie;
purge tablespace adm user eric;
purge tablespace lic user eric;


alter user eric account lock;
alter user wivina account lock;
alter user clement account lock;
alter user conny account lock;
alter user mandy account lock;
alter user kam account lock;
alter user frankie account lock;
alter user eric2 account lock;
alter user herman account lock;
alter user mandy1 account lock;
alter user lands account lock;
alter user cliff account lock;
alter user dias account lock;
alter user govhk_read account lock;



alter tablespace eric offline;
alter tablespace wivina offline;
alter tablespace clement offline;
alter tablespace conny offline;
alter tablespace mandy offline;
alter tablespace kam offline;
alter tablespace frankie offline;
alter tablespace eric2 offline;
alter tablespace herman offline;
alter tablespace mandy1 offline;
alter tablespace lands offline;
alter tablespace cliff offline;
alter tablespace dias offline;


spool off

