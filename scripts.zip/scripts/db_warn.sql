-- filename: db_warn.sql

set head off verify off feedback off linesize 111 pagesize 999 
set echo off term off serverout on size 9999 timing off doc off

spool /tmp/db_warn.out

prompt Report Start

-- prompt << Database Hit Ratio >>

select 
   to_char(round(100*(A.value + B.value - C.value) / (A.value + B.value),6), '99.99')||' Hit Ratio'
from   v$sysstat A, v$sysstat B, v$sysstat C, v$sysstat D
where  A.name = 'db block gets'
and    B.name = 'consistent gets'
and    C.name = 'physical reads'
and    D.name = 'physical writes' 
and round(100*(A.value + B.value - C.value) / (A.value + B.value),6)  <80 ;

-- prompt << Usage of Tablespaces over 85% >

select 
to_char((a.a1-nvl(b.b1,0))/a.a1*100, '99.99')||'% used on '||a.tablespace_name
from
(SELECT tablespace_name, sum(bytes/1024/1024) a1
   FROM dba_data_files
group BY tablespace_name) a,
(SELECT tablespace_name, 
        SUM(bytes/1024/1024) b1,
        count(*)             b2,
        max(bytes/1024)      b3,
        min(bytes/1024)      b4
   FROM dba_free_space
   GROUP BY tablespace_name) b,
(SELECT tablespace_name,  
        MAX(NEXT_EXTENT)/1024  c1 
   FROM DBA_SEGMENTS 
  GROUP BY tablespace_name) c
where a.tablespace_name = b.tablespace_name (+)
and  a.tablespace_name = c.tablespace_name
and  ( (a.a1-nvl(b.b1,0))/a.a1*100 > 85 or c.c1 > b.b3 )
order by 1  ;

-- prompt << Critical Next Extents >>

select
   -- b.owner, b.segment_type, b.nxtext/1024/1024, a.maxbyte/1024/1024, a.tablespace_name
   to_char(a.maxbyte/1024/1024,'9,999')||' Mb Free on '||a.tablespace_name||' < '||
   to_char(b.nxtext/1024/1024,'9,999')||' Mb x 5(exts) from '||b.owner||'.'||b.segment_name
from
  ( select tablespace_name, max(bytes) maxbyte, sum(bytes) sumbyte
    from dba_free_space
    group by tablespace_name ) a,
  ( select owner, tablespace_name, segment_name, segment_type, 
           next_extent nxtext
    from dba_segments
    where owner not in ('SYS','SYSTEM') ) b
where a.tablespace_name = b.tablespace_name(+)
and a.maxbyte/b.nxtext < 5 
order by 1 ;

-- prompt << Avaliable Extents <= 5 >>

select 
  sum(decode(sign(max_extents-extents-5),-1, 1, 0 ))||' FreeExt2Max of '||owner||' on '||tablespace_name
from dba_segments
where ( max_extents-extents < 5 )
and segment_type not in ('CACHE','ROLLBACK','TEMPORARY')
group by owner, segment_type, tablespace_name ;

-- prompt << Password expiry date >>

select 
to_char(abs(EXPIRY_DATE - sysdate), '999')||' days for '||username||' to expire. '
from dba_users
where abs(EXPIRY_DATE - sysdate) <= 14 ;

prompt
prompt Report End
spool off


