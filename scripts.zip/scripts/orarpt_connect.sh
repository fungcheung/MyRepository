#!/bin/ksh
## Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_connect.sh
## Usage: ./orarpt_connect.sh  $SG  $ORACLE_HOME  $ORA_SID

SERVICE_GROUP=$1  ; export SERVICE_GROUP
ORACLE_HOME=$2    ; export ORACLE_HOME
ORACLE_SID=$3     ; export ORACLE_SID

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

ADMIN=samson.wk.cheung@db.com
export ADMIN

OUT_FILE=/tmp/orarpt_connect_${ORACLE_SID}.out
export OUT_FILE

$ORACLE_HOME/bin/sqlplus / << EOF > $OUT_FILE
select name from v\$database ;
select to_char(sysdate, 'RRRRMMDD HH:MI:SS') from dual ;
EOF

if [  `/usr/bin/grep 'ORA-' $OUT_FILE | /usr/bin/wc -l` -ge 1 ] ; then
      echo "${ORACLE_SID}@`hostname` connection Err" | /usr/bin/mailx -s "${ORACLE_SID}@`hostname` connection Err" $ADMIN
      ## /usr/bin/ssh -l ptmon hkfindb1 qpage unixsa "${ORACLE_SID}@`hostname` connection Err"
      ## /apps/qpage/bin/qpage -s hkgincorep2 unixsa "${ORACLE_SID}@`hostname` connection Err"
fi

exit 0

