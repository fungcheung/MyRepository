Prompt Check what objects are occupying the max extents in a datafile.
prompt The object(s) can then be re-built and then the datafile can be shrinked.
prompt

set pages 200 lines 200

column OWNER format a20
column segment_name format a40
column segment_type format a20


select *
from (
select owner, segment_name,
segment_type, block_id
from dba_extents
where file_id =
(select file_id
from dba_data_files
where file_name = &FILE )
order by block_id desc
) 
where rownum <= 5;

