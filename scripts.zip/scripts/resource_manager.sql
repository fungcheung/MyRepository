set linesize 188 pages 999

prompt =========================================================================================================================================================
prompt The resource_manager_plan parameter shows database resource manager whether on/off. Default is off.
show parameter resource_manager_plan
prompt

prompt =========================================================================================================================================================
prompt Viewing the Currently Active Plans
SELECT NAME, IS_TOP_PLAN FROM V$RSRC_PLAN;


prompt =========================================================================================================================================================
prompt Viewing plan directives, about resource allocations
prompt "Enter plan directive name"
select * from DBA_RSRC_PLAN_DIRECTIVES where plan='&1' ;


prompt =========================================================================================================================================================
prompt Viewing Defined Plan Schema Information
SELECT PLAN,STATUS,COMMENTS FROM DBA_RSRC_PLANS;


prompt =========================================================================================================================================================
prompt Consumer Groups Granted to Users or Roles
SELECT * FROM DBA_RSRC_CONSUMER_GROUP_PRIVS;


prompt =========================================================================================================================================================
prompt consumer groups that are currently assigned to sessions
SELECT SID,SERIAL#,USERNAME,RESOURCE_CONSUMER_GROUP FROM V$SESSION;

prompt =========================================================================================================================================================
prompt Notes:
prompt Operating-system resource control should not be used concurrently with the Database Resource Manager


prompt Refer "Using the Database Resource Manager" in admin guide for details


