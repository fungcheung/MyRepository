#!/bin/ksh
## Filename: orarpt_chkbkup.sh
## Usage: ./orarpt_chkbkup.sh

ORACLE_HOME=/data/oracle/product/9.2.0.4  
export ORACLE_HOME

TNS_ADMIN=$ORACLE_HOME/network/admin
export TNS_ADMIN

ADMIN=samson.wk.cheung@db.com 
export ADMIN

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

/usr/bin/rm /home/oracle/dbasql/temp/*
echo '--------------------------------------------------------------------------------' > /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log

## /usr/bin/cat /home/oracle/dbasql/sginfo.lst | /usr/bin/grep -v '^#'  | while read LINE
## do
## 
##     SGHOST=`echo $LINE | /usr/bin/awk '{print $1}' ` ; export SGHOST
##     SGPATH=`echo $LINE | /usr/bin/awk '{print $2}' ` ; export SGPATH
##     SGSID=`echo $LINE  | /usr/bin/awk '{print $3}' ` ; export SGSID
## 
##     echo '----------' ${SGSID}_${SGHOST}  >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log
##     echo '--------------------------------------------------------------------------------' >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log

##     ## ssh -n ${SGHOST} 'ls -l /${SGPATH}/export/oracle/u004/${SGSID}/backup/logs/backup.log' >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1
##     ## ssh -n ${SGHOST} 'tail  /${SGPATH}/export/oracle/u004/${SGSID}/backup/logs/backup.log' >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1
## 
##     echo '--------------------------------------------------------------------------------' >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log
## 
## done

echo hkgeqappb1  >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log
ssh -n hkgeqappb1 "ls -l /hkgresdbp1/export/oracle/u004/ACE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "tail  /hkgresdbp1/export/oracle/u004/ACE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "ls -l /hkgresdbp1/export/oracle/u004/ACEDEV/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "tail  /hkgresdbp1/export/oracle/u004/ACEDEV/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbp1 "ls -l /hkgresdbp1/export/oracle/u004/ACE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbp1 "tail  /hkgresdbp1/export/oracle/u004/ACE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbu1 "ls -l /hkgresdbp1/export/oracle/u004/ACEUAT/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbu1 "tail  /hkgresdbp1/export/oracle/u004/ACEUAT/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgarddbp1 "ls -l /hkgarddbp1/export/oracle/u004/ARDMAU3/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgarddbp1 "tail  /hkgarddbp1/export/oracle/u004/ARDMAU3/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgarddbu1 "ls -l /hkgarddbp1/export/oracle/u004/ARDMAU3/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgarddbu1 "tail  /hkgarddbp1/export/oracle/u004/ARDMAU3/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgaradbb1 "ls -l /hkgaradbp1/export/oracle/u004/DBXHKB/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgaradbb1 "tail  /hkgaradbp1/export/oracle/u004/DBXHKB/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgaradbp1 "ls -l /hkgaradbp1/export/oracle/u004/DBXHKP/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgaradbp1 "tail  /hkgaradbp1/export/oracle/u004/DBXHKP/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappu2a "ls -l /hkgaradbp1/export/oracle/u004/DBXHKU/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappu2a "tail  /hkgaradbp1/export/oracle/u004/DBXHKU/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "ls -l /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "tail  /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd2 "ls -l /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd2 "tail  /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgepcdbp1 "ls -l /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgepcdbp1 "tail  /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgepcdbu1 "ls -l /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgepcdbu1 "tail  /hkgepcdbp1/export/oracle/u004/ECPHK/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "ls -l /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "tail  /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "ls -l /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "tail  /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgfccedbp1 "ls -l /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgfccedbp1 "tail  /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgfccedbu1 "ls -l /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgfccedbu1 "tail  /hkgfccedbp1/export/oracle/u004/FCCE/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkggeldbb1 "ls -l /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkggeldbb1 "tail  /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd2 "ls -l /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd2 "tail  /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkggeldbp1 "ls -l /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkggeldbp1 "tail  /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkggeldbu1 "ls -l /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkggeldbu1 "tail  /hkggeldbp1/export/oracle/u004/GEL/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "ls -l /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "tail  /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "ls -l /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "tail  /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbp1 "ls -l /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbp1 "tail  /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbu1 "ls -l /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgresdbu1 "tail  /hkgresdbp1/export/oracle/u004/research/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "ls -l /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappb1 "tail  /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "ls -l /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgeqappd1 "tail  /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgtsidbp1 "ls -l /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgtsidbp1 "tail  /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgtsidbu1 "ls -l /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n hkgtsidbu1 "tail  /hkgtsidbp1/export/oracle/u004/TSI/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpeeqxbosb1 "ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpeeqxbosb1 "tail  /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpeeqxbosd1 "ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpeeqxbosd1 "tail  /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpexbosdbp1 "ls -l /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpexbosdbp1 "tail  /tpexbosdbp1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
ssh -n tpexbosdbu1 "ls -l /tpexbosdbu1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 
echo tpexbosdbu1 >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log
ssh -n tpexbosdbu1 "tail  /tpexbosdbu1/export/oracle/u004/XBOS/backup/logs/backup.log" >> /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log 2>&1 

if [ -f /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log ] ; then
    /usr/bin/cat /home/oracle/dbasql/temp/ORARPT_CHKBKUP.log | /usr/bin/mailx -r sl2.apho@db.com -s "Backup Report - `date '+%y%m%d'`" $ADMIN
fi

exit 0

