#!/bin/ksh
## Filename: restore_TWXBOS_bcp.sh

export ORACLE_BASE=/data/oracle/TWXBOS/home
export ORACLE_HOME=/data/oracle/TWXBOS/product/10.2.0.3
export PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/ucb:$PATH
export ORACLE_SID=TWXBOS
export ORA_NLS33=$ORACLE_HOME/ocommon/nls/admin/data
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/product/jlib
export ORA_ADMIN=$ORACLE_HOME/admin
export TNS_ADMIN=$ORACLE_HOME/network/admin
export NLS_LANG=AMERICAN_AMERICA.ZHT16BIG5

export PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle

date ; 'Scp-ing backup files .....'
date ; ls -l /data/oracle/TWXBOS/backup/database/*
date ; rm    /data/oracle/TWXBOS/backup/database/*
date ; ls -l /data/oracle/TWXBOS/backup/database/*
date ; /usr/bin/scp -p  xbosdbp2:/data/oracle/TWXBOS/backup/database/*  /data/oracle/TWXBOS/backup/database/
date ; ls -l /data/oracle/TWXBOS/backup/database/*

date ; echo 'Shutting down TWXBOS  database .....'
ORACLE_SID=TWXBOS ; export ORACLE_SID
ORACLE_HOME=/data/oracle/TWXBOS/product/10.2.0.3 ; export ORACLE_HOME

PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ;
export PATH

sqlplus "/ as sysdba" << EOF
select name from v\$database ;
shutdown immediate ;
EOF

date ; echo 'Uncompressing datafiles ..... '
date ; ls -l /data/oracle/TWXBOS/backup/database/restore.ksh 
date ; cat /data/oracle/TWXBOS/backup/database/restore.ksh | sed '1,/^exit/s/exit//' >  /data/oracle/TWXBOS/backup/database/restore2.ksh
date ; ls -l /data/oracle/TWXBOS/backup/database/restore2.ksh

date ; echo 'tail -f /data/oracle/TWXBOS/backup/database/restore2.out'
ksh /data/oracle/TWXBOS/backup/database/restore2.ksh  > /data/oracle/TWXBOS/backup/database/restore2.out

date ; echo 'Recovering database ..... '
ORACLE_SID=TWXBOS ; export ORACLE_SID
sqlplus "/as sysdba"  << EOF
shutdown immediate ;
startup mount ;
SET AUTORECOVERY ON ;
recover database using backup controlfile until cancel ;
alter database open resetlogs  ;

-- ALTER TABLESPACE TEMP  ADD TEMPFILE '/data/oracle/TWXBOS/data02/TWXBOS_temp02.dbf'  SIZE 1025M REUSE AUTOEXTEND OFF;
-- ALTER TABLESPACE TEMP  ADD TEMPFILE '/data/oracle/TWXBOS/data02/TWXBOS_temp01.dbf'  SIZE 1025M REUSE AUTOEXTEND OFF;
-- ALTER TABLESPACE TEMP1 ADD TEMPFILE '/data/oracle/TWXBOS/data01/TWXBOS_temp03.dbf'  SIZE 1025M REUSE AUTOEXTEND OFF;

alter tablespace temp  tempfile online ;
alter tablespace temp1 tempfile online ;

exit
EOF

date ; echo 'Complete ..... '

exit 0
