l
alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ;
