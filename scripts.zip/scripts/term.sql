set timing on
set termout off

select * from test_data;

exit


