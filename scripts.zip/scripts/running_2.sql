-- Filename: running.sql

alter session set optimizer_features_enable='9.2.0';

set linesize 200
column sql_text format a90 wrap
column username format a12 wrap
column sid format 9999
column module format a12
break on sid skip 1

prompt #################################################################################################################
prompt << Jobs Running >>
prompt #################################################################################################################

col sess format 99    heading 'Ses' 
col jid  format 99999 heading 'Id' 
col subu format a10   heading 'Submitter'     trunc 
col secd format a10   heading 'Security'      trunc 
col proc format a20   heading 'Job'           word_wrapped 
col lsd  format a5    heading 'Last|Ok|Date'  
col lst  format a5    heading 'Last|Ok|Time' 
col nrd  format a5    heading 'This|Run|Date' 
col nrt  format a5    heading 'This|Run|Time' 
col fail format 99    heading 'Err' 
 
select 
  djr.sid                        sess, 
  djr.job                        jid, 
  dj.log_user                    subu, 
  dj.priv_user                   secd, 
  dj.what                        proc, 
  to_char(djr.last_date,'MM/DD') lsd, 
  substr(djr.last_sec,1,5)       lst, 
  to_char(djr.this_date,'MM/DD') nrd, 
  substr(djr.this_sec,1,5)       nrt, 
  djr.failures                   fail 
from 
  sys.dba_jobs dj, 
  sys.dba_jobs_running djr 
where 
  djr.job = dj.job  ;

prompt << SQLs Summary >>

SELECT b.username username, b.osuser osuser, a.spid, b.sid sid, b.serial# serial#, 
       b.status status, c.sql_text SQL
  FROM v$process a, v$session b, v$sqltext c
 WHERE b.paddr = a.addr
   AND c.address = b.sql_address
   AND b.osuser not in ('oracle')
 ORDER BY b.username, b.osuser, b.sid, a.spid, b.status desc, c.piece ;

prompt << SQLs Running >>

select /* running.sql */  sid,username,FIRST_LOAD_TIME, SHARABLE_MEM, PERSISTENT_MEM, 
      RUNTIME_MEM, EXECUTIONS, LOADS, PARSE_CALLS , DISK_READS Disk, ROWS_PROCESSED , 
      s.lockwait,s.status ,q.module,sql_text
 FROM v$session s, v$sqlarea q
WHERE s.sql_hash_value = q.hash_value
  AND s.sql_address = q.address
  and s.username is not null
  and substr(sql_text,8,17)<>'/* running.sql */'
  and ( s.status <> 'INACTIVE' or s.program='OraPgm') ;


set linesize 150
column username format a12
column program format a15
col sql_text for a70
break on username

select to_char(b.logon_time,'mmddyy hh24:mi') "logon",substr(b.username,1,10) "username",b.sid,
b.osuser, b.status,
a.sql_text from V$SQLTEXT a,V$SESSION b where a.address=b.sql_address 
and b.username is not null order by logon_time, sid,piece;



column spid     format 999999 heading UnixPid
column sid      format 999    heading SessId
column serial#  format 999999 heading Ser#
column username format a13    heading OracleUser truncated
column osuser   format a13    heading OS_User
column terminal format a15    heading Terminal
column program  format a44    heading Program
column logon    format a17
column idle     format a9
column sql_text format a80

prompt -----------------------------------------------------------------------------------
prompt << Inactive session details with last SQL>>
prompt -----------------------------------------------------------------------------------

select 
   pro.spid, ses.osuser, ses.username, ses.sid, ses.serial#,
   status, to_char(logon_time,'dd-mm-yy hh:mi:ss') "Logon",
   floor(last_call_et/3600)||':'||floor(mod(last_call_et,3600)/60)||':'||mod(mod(last_call_et,3600),60) "IDLE", ses.terminal, ses.program, sql.sql_text last_sql
from v$session ses, v$process pro, v$sqlarea sql
where ses.status = 'INACTIVE' and
ses.paddr = pro.addr and ses.prev_sql_addr = sql.address and ses.prev_HASH_VALUE = sql.HASH_VALUE
order by  ses.username, ses.osuser, ses.sid, pro.spid ;


clear break 
ttitle off

