#!/bin/ksh
#
# This program stops the Oracle sqlnet V2 listener.
#
# How to run:			lsnrstop.sh <LISTENER_NAME> <ORACLE_HOME>
#
# Program File:			lsnrstop.sh 
# Program File Location:	${ORACLE_HOME/bin
# Program File Owner:		oracle ID (generally)
# Program File Group:		dba group
# Program File Permission:	750
#
CheckStatus() {
if [ x${PASS} = x ]
then
STATUS=`ps -ef|grep -i "LISTENER_${LISTENER_NAME} "|grep -v grep|wc -l|sed 's/^ *//'`
if test ${STATUS} -ne 1
then
echo "Error: Listener for ${LISTENER_NAME} is NOT running." |tee -a $LOGFILE
exit 1;
fi
else
${ORACLE_HOME}/bin/lsnrctl <<!
set current_listener listener_${LISTENER_NAME}
set password ${PASS}
status
!
if test ${STATUS} -ne 1
then
echo "Error: Listener for ${LISTENER_NAME} is NOT running." |tee -a $LOGFILE
exit 1;
fi
fi

}

StopListener() {

if [ x$PASS = x ]
then
${ORACLE_HOME}/bin/lsnrctl stop LISTENER_${LISTENER_NAME} >> $LOGFILE
else    
${ORACLE_HOME}/bin/lsnrctl <<!
set current_listener listener_${LISTENER_NAME}
set password ${PASS}
stop
!
fi
echo "End Date: `date`" >> $LOGFILE

}

GetPassword() {
cfgfile=${ORACLE_HOME}/network/admin/listener.ora
PASS=`cat $cfgfile | grep -v "^[ \t]*#" | grep -i "PASSWORDS_LISTENER_${LISTENER_NAME} " | \
      cut -d '#' -f1 | cut -d '=' -f2 | awk '{print $1}'`
}

main() {
GetPassword
CheckStatus
StopListener
}

if test $# -ne 2
then
  echo "usage: $0 <LISTENER_NAME> <ORACLE_HOME>"
  exit 1
else
 unset TNS_ADMIN
  LISTENER_NAME=$1
  ORACLE_HOME=$2
  LOGFILE=/tmp/lisstop${LISTENER_NAME}.log.$$
  export LISTENER_NAME ORACLE_HOME LOGFILE
  echo "========================================================================" > $LOGFILE
  echo "Start Date: `date`" >> $LOGFILE
  echo "Stopping Listener for ${LISTENER_NAME} ....."|tee -a  $LOGFILE
  main
fi
