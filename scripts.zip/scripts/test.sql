insert into a values('發動');
