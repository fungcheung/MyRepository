
set heading on feed off                                                           
set pages 200 lines 200

-- alter session set optimizer_features_enable='9.2.0';
alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

col "Tablespace"          for a22
col "Used MB"             for 9,999,999.99
col "Free MB"             for 9,999,999.99
col "Total MB"            for 9,999,999.99
col extendable_free_space for 9,999,999.99
col "Pct. Free"           for 999,999.99
col "maxspace"            for 999,999.99
set linesize 112

select df.tablespace_name "Tablespace",
totalusedspace "Used MB",
(df.totalspace - tu.totalusedspace) "Free MB",
df.totalspace "Total MB",
round(100 * ( (df.totalspace - tu.totalusedspace)/ df.totalspace),2)
"Pct. Free"
from
(select tablespace_name,
round(sum(bytes) / 1048576) TotalSpace
from dba_data_files
group by tablespace_name) df,
(select round(sum(bytes)/(1024*1024)) totalusedspace, tablespace_name
from dba_segments
group by tablespace_name) tu
where df.tablespace_name = tu.tablespace_name;

select df.tablespace_name "Tablespace",
nvl(totalusedspace,0) "Used MB",
(df.totalspace - nvl(tu.totalusedspace,0)) "Free MB",
df.totalspace "Total MB",
round(100 * ( (df.totalspace - nvl(tu.totalusedspace,0))/ df.totalspace),2)
"Pct. Free",
nvl(fs.free_space,0) extendable_free_space
, round(maxspace,2) maxspace
from
(select tablespace_name,
round(sum(bytes) / 1048576) TotalSpace
, sum(maxbytes)/1024/1024 maxspace
from dba_data_files
group by tablespace_name) df,
(select round(sum(bytes)/(1024*1024)) totalusedspace, tablespace_name
from dba_segments
group by tablespace_name) tu
,
(
select tablespace_name, round(sum(bytes)/1024/1024 ,2) as free_space
       from dba_free_space
       group by tablespace_name
) fs
where df.tablespace_name = tu.tablespace_name(+)
AND df.tablespace_name = fs.tablespace_name(+)
ORDER BY "Pct. Free";


set pages 200 lines 200
column file_name format a50
select TABLESPACE_NAME, FILE_NAME, ceil(BYTES/1024/1024), ceil(MAXBYTES/1024/1024), AUTOEXTENSIBLE from dba_data_files
union
select TABLESPACE_NAME, FILE_NAME, ceil(BYTES/1024/1024), ceil(MAXBYTES/1024/1024), AUTOEXTENSIBLE from dba_temp_files
order by 1,2,5;




