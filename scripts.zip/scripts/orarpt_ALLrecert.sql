-- 
-- Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_ALLrecert.sql
-- 

set head off verify off feedback off linesize 111 pagesize 999 
set echo off term off serverout on size 9999 timing off doc off

col c_logfile new_value logfile
select name||'_'||machine||'_ALLrecert' c_logfile
  from v$session, v$database
 where upper(program) like upper('%oracle%')
   and rownum = 1 ;

spool /home/oracle/dbasql/temp/&&logfile..spo


set head off
select rpad('-- SID: '||name,88,' --') from v$database ;
set head on 

col username for a22
col Status   for a22
col Nature   for a22
col role1    for a11
col role2    for a11

select USERNAME,
decode(ACCOUNT_STATUS, 'OPEN', 'Keep', ACCOUNT_STATUS) "Status",
decode(USERNAME, 'CHEUSA', 'ID IES/DBA',
                 'CHOWKE', 'ID IES/DBA',
                 'OPS$ORACLE', 'ID IES/Monitoring',
                 'AUDTASK', 'ID IES/Monitoring',
                 'AUD_OWNER', 'ID IES/Monitoring',
                 'DBA_MON', 'ID IES/Monitoring',
                 'DB_TOOLS', 'ID IES/Monitoring',
                 'FOGLIGHT', 'ID IES/Monitoring',
                 'HIDS_AUDITOR', 'ID IES/Monitoring',
                 'DBSNMP', 'ID System',
                 'OUTLN', 'ID System',
                 'WMSYS', 'ID System',
                 'SYS', 'ID System',
                 'SYSTEM','ID System', 'ID Apps' )  as "Nature",
decode(USERNAME, 'CHEUSA', 'DBA_role',
                 'CHOWKE', 'DBA_role', 
                 'SYS',    'DBA_role', 
                 'SYSTEM', 'DBA_role', ' ' )  as Role1, 
decode(USERNAME, 'CHEUSA', 'DBA_role',
                 'CHOWKE', 'DBA_role', 
                 'SYS',    'DBA_role', 
                 'SYSTEM', 'DBA_role', ' ' )  as Role2
from dba_users
order by 1 ;

spool off


