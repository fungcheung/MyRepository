#!/bin/sh

$ORACLE_HOME/bin/sqlplus / << EOF > /tmp/oo.out
select name from v\$database ;
select to_char(sysdate, 'RRRRMMDD HH:MI:SS') from dual ;
EOF

