WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK

delete from a;

insert into a (a) values('jordan');

commit;

exit

