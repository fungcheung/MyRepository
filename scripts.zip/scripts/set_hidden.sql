--
-- How to set and reset hidden parameter in Oracle
--

Prompt How to set and reset hidden parameter in Oracle
prompt 

prompt alter system set "_kghdsidx_count"=1 scope=spfile;

prompt alter system set "_cursor_stats_enabled"=false scope=spfile;

prompt alter system set "_optim_peek_user_binds"=false scope=spfile;


prompt alter system reset "_kghdsidx_count" scope=spfile;

prompt alter system reset "_cursor_stats_enabled" scope=spfile;

prompt alter system reset "_optim_peek_user_binds" scope=spfile;




