/*
Filename: compile_objs.sql
Desp: Generating dynamic SQL to used to recompile 'INVALID' objects in the DB
*/

=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=

execute DBMS_UTILITY.COMPILE_SCHEMA (upper('&1')) ;
execute DBMS_UTILITY.COMPILE_SCHEMA (upper('EPCPROD')) ;

execute dbms_utility.compile_schema('MIS', true); 
execute dbms_utility.compile_schema('EPCPROD', true); 

=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=
:: version_??

select 'execute dbms_utility.compile_schema('''||owner||''');'
from dba_segments
where owner not in ('SYSTEM', 'SYS')
group by owner ;

=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=
:: 20040220

select '  ALTER ' || 
  decode (o.type#,  4, 'VIEW ',      7, 'PROCEDURE ',  8, 'FUNCTION ' , 9, 'PACKAGE ' , 
                   11, 'PACKAGE ' , 12, 'TRIGGER ' ,  13, 'TYPE ' ,    14, 'TYPE ', ' ') || 
  '"' ||  u.name ||  '"."' || o.name  ||  '" COMPILE ' || 
  decode (o.type#, 9, 'SPECIFICATION', 11, 'BODY', 13, 'SPECIFICATION', 14, 'BODY', ' ') || ';'  as COMPILE 
from  sys.obj$  o, sys.user$ u 
where u.user# = o.owner# 
  and o.remoteowner is NULL 
  and o.status in (3,4,5,6)                     -- 3: possible syntax error 
  and o.type# in (4, 7, 8, 9, 11, 12, 13, 14)   
  -- and u.name = 'WRITE_YOUR_SCHEMA_HERE'         -- your schema 
  and u.name not in ('SYSTEM', 'SYS', 'CHEUSA')
order by o.obj#  ;


=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=
=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=
:: version_1   ?? order_object_by_dependency ??

select max(level), object_id from public_dependency 
connect by object_id = prior referenced_object_id 
group by object_id; 

set head off feed off pages 0 lines 79 verify off echo off

select
    decode( OBJECT_TYPE, 'PACKAGE BODY',
    'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body;',
    'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile;' )
from
    dba_objects a,
    sys.order_object_by_dependency b
where A.OBJECT_ID = B.OBJECT_ID(+) 
  and STATUS = 'INVALID' 
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW' )
order by DLEVEL DESC, OBJECT_TYPE, OBJECT_NAME ;

set head on feed on pages 999 lines 132 verify on echo on

=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=

SET ECHO ON

BEGIN
   IF USER != 'REG'
   THEN
      execute DBMS_UTILITY.COMPILE_SCHEMA (upper('&1')) ;
   END IF;
END;
/

@$SQL/compile_all
@$SQL/compile_all

SET PAGESIZE 60

SELECT COUNT(*)
  FROM user_errors;

SET ECHO OFF

=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=

