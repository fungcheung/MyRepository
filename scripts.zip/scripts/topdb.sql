-- fiilename: topdb.sql


alter session set container=&1;

show con_name;


