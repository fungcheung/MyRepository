-- gen_coldbackup.sql

-- define 3 = &backup_directory
-- define 4 = &instance_name

define 3 = /export/oracle/u002/backup
define 4 = ACEUAT

Set Heading Off Verify Off  FeedBack Off LineSize 132 PageSize 1000 termout off

clear breaks
clear computes

spool c:\temp\cold_backup.sh

select 'set -x' from dual ;

select 'sqlplus "/as sysdba"  < _EOD ' from dual;
select 'Shutdown immediate' from dual ;
select 'Startup restrict' from dual ;
select 'Shutdown Normal' from dual ;
select 'spool cold_backup.sh' from dual ;
select '_EOD' from dual ;

select 'set -x' from dual ;

select 'date' from dual ;
/* Data Files */
Select 'gzip  < ' || File_Name || ' >  &&3'||'/' || SubStr(File_Name, InStr(File_Name, '/', -1)+1)||'.gz ' 
From Sys.DBA_Data_Files
/

select 'date' from dual ;
/* Redo Log Files */
Select 'gzip  < ' || Member||' >  &&3'||'/'||SubStr(Member, InStr(Member, '/', -1)+1)||'.gz ' 
From V$LogFile
/

select 'date' from dual ;
/* Control Files */
Select 'gzip < '||name  ||' >  &&3'||'/'||SubStr(name, InStr(name, '/', -1)+1)||'.gz ' 
From V$controlfile
/

select 'date' from dual ;
/* Init and Config Files */
Select 'gzip < $ORACLE_HOME/dbs/init&&4'||'.ora   > &&3'||'/init&&4'||'.ora.gz '  From Dual;
Select 'gzip < $ORACLE_HOME/dbs/config&&4'||'.ora > &&3'||'/config&&4'||'.ora.gz '  From Dual;

select 'date' from dual ;
Select 'spool off' From Dual;

Select 'Startup' From Dual;
Select 'Exit' from dual;
Spool Off
Spool Off


ttitle off
clear breaks
clear computes
set heading on
set termout on
set feedback on

prompt 
prompt host write c:\temp\cold_backup.sh
prompt 

