--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--
-- filename: pre_TWXBOS_imp.sql
--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--

set echo on  pages 999 lines 222
set echo off head off pages 0 feed off
select 
'drop user  ' || username || ' cascade ;'
from dba_users
where username not in ('SYS', 'SYSTEM', 'CHEUSA', 'CHOWKE', 'OPS$ORACLE', 'OUTLN' )

spool /tmp/drpobj_TWXBOS.tmp
/
spool off
@/tmp/drpobj_TWXBOS.tmp

--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--

set echo off head off pages 0 feed off
select 
'alter tablespace ' || tablespace_name || ' coalesce ;'
from dba_tablespaces
where tablespace_name not in ('SYSTEM')

spool /tmp/coaltsp_TWXBOS.tmp
/
spool off
@/tmp/coaltsp_TWXBOS.tmp

--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--

create user XBOSPROD   
identified by login123
default tablespace XBOS_TAB     
temporary tablespace TEMP       
quota unlimited on XBOS_IDX     
quota unlimited on XBOS_TAB     
/    

grant SELECT ANY DICTIONARY to xbosprod ;
grant CREATE TABLE to xbosprod ;

grant READ on SYS.DATA_DIR to XBOSPROD ; 
grant WRITE on SYS.DATA_DIR to XBOSPROD ;

--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--

create user XBOSLOAD       
identified by login123
default tablespace XBOS_TAB
temporary tablespace TEMP  
quota unlimited on XBOS_TAB
quota unlimited on XBOS_IDX
/

grant XBOSLOAD_ROLE to xbosload ;        

grant EXECUTE on XBOSPROD.PROC_BLOCK_CMATCH_TO_HIS to XBOSLOAD ;       
grant EXECUTE on XBOSPROD.PROC_BLOCK_COMBINE_TO_HIS to XBOSLOAD ;      
grant EXECUTE on XBOSPROD.PROC_BLOCK_CONFIRM to XBOSLOAD ;             
grant EXECUTE on XBOSPROD.PROC_BLOCK_SINGLE_TO_HIS to XBOSLOAD ;       
grant EXECUTE on XBOSPROD.PROC_BLOCK_SMATCH_TO_HIS to XBOSLOAD ;       
grant EXECUTE on XBOSPROD.PROC_BLOCK_STOCK_TO_HIS to XBOSLOAD ;        
grant EXECUTE on XBOSPROD.PROC_BLOCK_TRANSFER to XBOSLOAD ;            
grant EXECUTE on XBOSPROD.PROC_KB96104_L11 to XBOSLOAD ; 
grant EXECUTE on XBOSPROD.PROC_KB96105_L12 to XBOSLOAD ; 
grant EXECUTE on XBOSPROD.PROC_KB96106_L51 to XBOSLOAD ; 
grant EXECUTE on XBOSPROD.PROC_KB96106_L52 to XBOSLOAD ; 
grant EXECUTE on XBOSPROD.PROC_KB96107_L55 to XBOSLOAD ; 
grant EXECUTE on XBOSPROD.PROC_KB96107_L56 to XBOSLOAD ; 
grant EXECUTE on XBOSPROD.PROC_L01 to XBOSLOAD ;   
grant EXECUTE on XBOSPROD.PROC_L15L16 to XBOSLOAD ;
grant EXECUTE on XBOSPROD.PROC_L17L18 to XBOSLOAD ;
grant EXECUTE on XBOSPROD.PROC_L50 to XBOSLOAD ;   
grant EXECUTE on XBOSPROD.PROC_L61L62 to XBOSLOAD ;
grant READ on SYS.DATA_DIR to XBOSLOAD ; 
grant READ on SYS.DATA_DIR to XBOSLOAD ; 
grant WRITE on SYS.DATA_DIR to XBOSLOAD ;
grant WRITE on SYS.DATA_DIR to XBOSLOAD ;

exit
--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--
--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--//--
