select name from v$database ;
alter user CHOWKE profile default ;
alter user CHEUSA profile default ;

alter user CHOWKE identified by login123 ;
alter user CHEUSA identified by login123 ;

alter user CHOWKE identified by wongk000 ;
alter user CHEUSA identified by lawon000 ;

alter user CHOWKE profile PASSWORD_PROFILE_DBA ;
alter user CHEUSA profile PASSWORD_PROFILE_DBA ;

-- Foglight
-- alter user FOGLIGHT profile default ;
-- alter user FOGLIGHT identified by sininfog999 ;
-- alter user FOGLIGHT account unlock ;
-- alter user FOGLIGHT profile foglight_profile;


-- Arcsight
-- alter user hids_auditor identified by Gq0PkGoWnpyy ;

