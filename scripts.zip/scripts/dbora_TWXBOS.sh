#!/bin/sh
# Shell script for starting/stopping Oracle databases
# on machine shutdown/reboot
#
ORA_HOME=/data/oracle/TWXBOS/product/10.2.0.3 ; export ORA_HOME
ORA_OWNER=oracle ; export ORA_OWNER

if [ ! -f /etc/init.d/database/dbstart_TWXBOS.sh ]
then
  echo "Oracle startup in dbora script: cannot start"
  exit
fi

case "$1" in
'start')
# Start up Oracle databases
  su $ORA_OWNER -c '. /home/oracle/.profile ; /etc/init.d/database/dbstart_TWXBOS.sh '
  sleep 3
  su $ORA_OWNER -c ". /home/oracle/.profile ; $ORA_HOME/bin/lsnrctl start LISTENER_TWXBOS"

;;
'stop')
# Stop Oracle databases
  su $ORA_OWNER -c '. /home/oracle/.profile ; /etc/init.d/database/dbshut_TWXBOS.sh '
  echo "Oracle DB going down on `date`" >> /var/tmp/db-down.log
  sleep 3
  su $ORA_OWNER -c ". /home/oracle/.profile ; $ORA_HOME/bin/lsnrctl stop LISTENER_TWXBOS"
;;
esac

exit 0
