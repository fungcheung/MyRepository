set doc off 

prompt 
prompt << Tables Experiencing Chaining  >>
prompt 

select owner, table_name, nvl(chain_cnt,0) "Chained Rows"
  from all_tables
 where owner not in ('SYS', 'SYSTEM')
   and nvl(chain_cnt,0) > 0
 order by owner, table_name
/

select 'Chained or Migrated Rows ='|| value
  from v$sysstat
 where name = 'table fetch continued row'
/


doc
:: Chaining Solution
1.Create an intermediate table with the same columns as the existing table to hold the migrated and chained rows: 

     CREATE TABLE int_order_hist AS 
     SELECT * FROM order_hist
      WHERE ROWID IN
       (SELECT HEAD_ROWID FROM CHAINED_ROWS
         WHERE TABLE_NAME = 'ORDER_HIST');

2.Delete the migrated and chained rows from the existing table: 

     DELETE FROM order_hist
     WHERE ROWID IN
      (SELECT HEAD_ROWID FROM CHAINED_ROWS
        WHERE TABLE_NAME = 'ORDER_HIST');

3.Insert the rows of the intermediate table into the existing table: 

     INSERT INTO order_hist
     SELECT * FROM int_order_hist;

4.Drop the intermediate table: 

     DROP TABLE int_order_history;
#

