#!/bin/ksh
##Filename: db_tune.sh

ORACLE_SID=ACEUAT ; export ORACLE_SID   
ORACLE_HOME=/export/oracle/products/8.1.7 ; export ORACLE_HOME
NLS_LANG=AMERICAN  ; export NLS_LANG 
PATH=$ORACLE_HOME/bin:/usr/ccs/bin:/usr/bin:/etc:/usr/openwin/bin:/usr/local/bin:/usr/sbin:/usr/ucb:/sbin:/var/opt/oracle ; export PATH
LD_LIBRARY_PATH=$ORACLE_HOME/lib ; export LD_LIBRARY_PATH

## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## 

echo `date` Statistics collecing .......
$ORACLE_HOME/bin/sqlplus / @/home/oracle/dbasql/db_tune.sql > /home/oracle/dbasql/db_tune.log 2>&1
mv /home/oracle/dbasql/db_tune.spo  /home/oracle/dbasql/db_tune_`date '+%y%m%d%H%M'`.spo

## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## -- ## 

