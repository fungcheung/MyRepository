-- fiilename: freespace.sql

clear col

col mxbytes format 999,999.099

select tablespace_name, max(bytes/1024/1024) mxbytes
from dba_free_space
group by tablespace_name ;

clear col
