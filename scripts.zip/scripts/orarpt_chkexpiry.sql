set serverout off
--set term off

set lines 111
set pagesize 9999
set heading off
set feedback off

column username format a15 heading "Username"
column account_status format a20 heading "Account Status"
column profile format a20 heading "Profile"
column exp_date format a20 heading "Expiry Date"

--spool /home/oracle/dbasql/temp/orarpt_chkexpiry.spo

prompt Username        Account Status       Profile              Expiry Date
prompt --------------- -------------------- -------------------- --------------------

select username,account_status,profile,to_char(expiry_date,'YYYY/MM/DD HH24:MI:SS') exp_date from dba_users order by 1, 3
/
--spool off
