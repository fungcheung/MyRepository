set pages 200 line 200
set time on
set timing on
set sqlprompt  "_user'@'_connect_identifier:SQL> "
column owner format a15
column name format a30
column type format a15
column object_name format a30
column segment_name format a30
column table_name format a30
column column_name format a30
column object_type format a30
