-- fiilename: datafile.sql

clear col
set lines 333 pages 300

-- alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ;
alter session set nls_date_format = 'dd-mm-yyyy hh24:mi:ss' ;

col MB        format 999,999,999
col name        format a20
col open_time         format a50
col file_name         format a100
col AUTOEXTENSIBLE         format a15

select a.con_id, a.name, b.file_name, b.bytes/1024/1024 MB, online_status status, AUTOEXTENSIBLE from v$pdbs a, cdb_data_files b 
where a.con_id = b.con_id order by a.con_id, MB desc;

prompt 

clear col
