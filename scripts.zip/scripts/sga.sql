set lines 200
set pages 200


column COMPONENT format a25
column PARAMETER format a25

prompt Memory info (11g only)
prompt =================================================================================================
select component, current_size, min_size, max_size, USER_SPECIFIED_SIZE, OPER_COUNT,LAST_OPER_MODE, LAST_OPER_TIME from v$memory_dynamic_components; 

prompt Previous Resize Ops (11g only)
prompt =================================================================================================
select
OPER_TYPE,OPER_MODE,PARAMETER,INITIAL_SIZE, FINAL_SIZE, STATUS, START_TIME,END_TIME 
from v$memory_resize_ops order by START_TIME desc;

prompt Current Resize Ops (11g only)
prompt =================================================================================================
select * from v$memory_current_resize_ops;



prompt SGA info
prompt =================================================================================================
select * from v$sgainfo; 

prompt SGA free memory
prompt =================================================================================================

select pool,sum(bytes)/1024/1024 MB from v$sgastat group by pool;

select * from v$sgastat where lower(name) like '%free memory%';

select * from (
select pool, name, bytes/1024/1024 MB from v$sgastat order by bytes desc) where rownum < 20;




