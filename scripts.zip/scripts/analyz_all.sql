/*
The following SQL lists how many tables are analyzed and how many aren't. 
*/

column owner format a16
column "Chained Rows" format 99,999
column table_name format a26
column analyzed   format a16
-- ttitle 'Tables that Are Analyzed (Summary by Owner)'

select owner, 
  sum(decode(nvl(num_rows,9999), 9999,0,1)) "Tables Analyzed",
  sum(decode(nvl(num_rows,9999), 9999,1,0)) "Tables Not Analyzed"
from  all_tables
where owner not in ('SYS', 'SYSTEM')
group by owner
/

select utc.table_name, utc.last_analyzed, count(*)
from user_tab_columns utc, user_tables ut
where utc.table_name = ut.table_name
group by utc.table_name, utc.last_analyzed
/

set pages  0
set lines  132
set term   off
set recsep off


select 'analyze '||segment_type||' '||owner||'.'||segment_name||' '||
       decode(sign(10485760 - bytes),1,'compute statistics;','estimate statistics;') 
  from sys.dba_segments
 where owner not in ( 'SYS', 'SYSTEM')
   -- and owner in ($ANALYZE_SCHEMAS)
   and segment_type in ('CLUSTER', 'TABLE', 'INDEX')
 order by owner, segment_name
/

select 'analyze index '||owner||'.'||index_name||' validate structure;'
  from dba_indexes 
 where owner not in ( 'SYS', 'SYSTEM')
/

SELECT name "INDEX NAME",
blocks * 4096 "BYTES ALLOCATED",
btree_space "BYTES UTILIZED",
(btree_space / (block*4096)) * 100 "PERCENT USED"
FROM index_stats;



doc
-- Using DBMS Package --
select 'execute dbms_utility.analyze_schema('''||owner||''''||', '||'''estimate'''||');'
from dba_segments
where owner not in ('SYSTEM', 'SYS')
group by owner
/

select 'execute dbms_utility.analyze_schema('''||owner||''''||', '||'''compute'''||');'
from dba_segments
where owner not in ('SYSTEM', 'SYS')
group by owner
/

-- execute dbms_utility.analyze_schema('LICP', 'compute');
-- dbms_ddl.analyze_object() ; ????
-- dbm_job.submit('...', 'DBMS_UTIL.ANALYZE_SCHEMA(xxxx), '....'); 

-- For BIG tables --
select 
   'analyze table '||owner||'.'||table_name||' '||
   decode(sign(10485760 - initial_extent),1,'compute statistics', 'estimate statistics')|| 
   decode(instr(table_name||',', 'CTCS_PRODUCT,'),0,'',' FOR ALL INDEXED COLUMNS')||';'
from  sys.dba_tables
where owner = upper('&owner')
  and table_name not in ('CTCS_REPORTALARM')
/

select 'analyze table &&owner..CTCS_REPORTALARM '||chr(10)||
'compute statistics for all indexed columns size 20;'
from sys.dual
/

#



execute dbms_utility.analyze_schema('KAYR', 'estimate');
execute dbms_utility.analyze_schema('RESEARCH', 'estimate');

