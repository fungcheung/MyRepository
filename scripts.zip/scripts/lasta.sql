--
-- filename: lasta.sql
--

set lines 222 pages 999

col TABLE_OWNER for a11
col TABLE_NAME  for a33
col INDEX_NAME  for a33
col COLUMN_NAME for a33

break on report skip 1

undef 1 

select owner, table_name, to_char(LAST_ANALYZED, 'dd-mm-yyyy hh24:mi:ss')
from dba_tables
where OWNER = upper('&&1') 
order by LAST_ANALYZED, table_name;
/

/*
select owner, to_char(LAST_ANALYZED, 'dd-mm-yyyy hh24:mi:ss')
from dba_tab_columns
where OWNER = upper('&&1') 
group by owner, LAST_ANALYZED
;
*/


undef 1 
