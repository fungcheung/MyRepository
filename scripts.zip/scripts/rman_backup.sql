prompt ##############################################################################
prompt # Show RMAN backup history
prompt ##############################################################################

alter session set nls_date_format = 'dd-mm-rrrr hh24:mi:ss' ; 

set pages 9999
set lines 200
set long 99990
select input_type, start_time, end_time, status, INPUT_BYTES/1024/1024/1024 as INPUT_GB, OUTPUT_BYTES/1024/1024/1024 as OUTPUT_GB, COMPRESSION_RATIO from v$rman_backup_job_details
/







