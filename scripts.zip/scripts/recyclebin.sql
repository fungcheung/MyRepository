prompt -- Show space usage(num of blocks) of recyclebin 

select sum(space) blocks, owner from dba_recyclebin group by owner order by 1;
select sum(space) Total from dba_recyclebin;


prompt -- To reclaim space, execute below sqls
prompt purge dba_recyclebin; (all recyclebins)
prompt purge tablespace <tablespace> user <user>; (purge recyclebin objects in <tablespace> of <user>) 

-- exec dbms_stats.gather_schema_stats('SYS');
-- exec dbms_stats.gather_database_stats(gather_sys=>TRUE);
-- exec dbms_stats.gather_dictionary_stats;
-- exec dbms_stats.gather_fixed_objects_stats;
