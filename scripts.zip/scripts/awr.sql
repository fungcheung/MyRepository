prompt ##############################################################################
prompt # How to generate AWR report using %oracle_home%\rdbms\admin or Oracle package
prompt ##############################################################################

prompt Using awrrpt.sql
prompt %oracle_home%\rdbms\admin\awrrpt.sql


prompt Using Oracle package
prompt select output from table(dbms_workload_repository.AWR_REPORT_HTML(:dbid,:inst_num,:bid,:eid,8));


prompt AWR setting
select * from dba_hist_wr_control;

prompt Example: Keep 60 days(86400 mins) and generate awr every 60 mins
prompt exec DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(86400,60);

prompt Example: Disable AWR snapshot collection.
prompt EXECUTE DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(interval =>  0); 

col BEGIN_INTERVAL_TIME format a40

prompt Snapshot information
select dbid, instance_number, snap_id, BEGIN_INTERVAL_TIME,snap_level,error_count from dba_hist_snapshot order by snap_id;


