-- filename: /hkgresdbp1/export/oracle/u001/admin/ACE/adhoc/post_import.sql 

set echo on pages 999 lines 222

-- revoke connect from ace ;
-- grant unlimited tablespace to ace ;

drop user OPS$ACELOAD cascade ;
drop user OPS$CHUNGJ  cascade ;
drop user OPS$PURSCH  cascade ;
drop user OPS$RAWLMA  cascade ;
drop user OPS$TSANGM  cascade ;
drop user OPS$WONGLE  cascade ;

execute dbms_utility.compile_schema('ACE');

exit

