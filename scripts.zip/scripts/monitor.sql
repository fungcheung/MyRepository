-- 
-- Filename: monitor.sql
-- 

set pages 999 lines 111 feed on head on echo off term on

clear column
SPOOL monitor.spo

prompt 
prompt << Usage of Tablespaces over 85% OR Free Extents < Required >>

column tablespace_name   format a15          heading "Tablespace Name" 
column file_name         format a40          heading "File|Name" 
column Size_M            format 9,999,999.99 heading "Allocated|MBytes"
column Free_M            format 9,999,999.99 heading "Free|MBytes"
column Used_M            format 9,999,999.99 heading "Used|MBytes"
column Used_P            format 99.99        heading "Used %%"
column frag_count        format 999,999      heading "No. of|Free Exts" 
column large_frag        format 99,999,999   heading "Largest|Exts (KB)"  
column small_frag        format 99,999,999   heading "Smallest|Exts (KB)" 
column initext           format 999,999      heading "Initial|Exts (KB)" 
column nxtreqext         format 999,999      heading "Next Reqd|Exts (KB)" 
column pctincrease       format 999          heading "%Inc" 

select a.tablespace_name, a.a1 "Size_M", a.a1-nvl(b.b1,0) "Used_M", 
nvl(b.b1,0) "Free_M" , (a.a1-nvl(b.b1,0))/a.a1*100 "Used_P", 
b2 frag_count, b3 large_frag, b4 small_frag,
nvl(c1,0) nxtreqext
from
(SELECT tablespace_name, sum(bytes/1024/1024) a1
   FROM dba_data_files
group BY tablespace_name) a,
(SELECT tablespace_name, 
        SUM(bytes/1024/1024) b1,
        count(*)             b2,
        max(bytes/1024)      b3,
        min(bytes/1024)      b4
   FROM dba_free_space
   GROUP BY tablespace_name) b,
(SELECT tablespace_name,  
        MAX(NEXT_EXTENT)/1024  c1 
   FROM DBA_SEGMENTS 
  GROUP BY tablespace_name) c
where a.tablespace_name = b.tablespace_name (+)
and  a.tablespace_name = c.tablespace_name
and  ( (a.a1-nvl(b.b1,0))/a.a1*100 > 85 or c.c1 > b.b3 )
order by 1  ;

prompt
prompt << Critical Next Extents >>

column owner format a10      heading "Owner"
column a1 format a17         heading "TableSp"
column a2 format a33         heading "Segment Name"
column a3 format 99,999,999  heading "Free|Tblsp (Kb)"
column a4 format 999,999,999 heading "Max Free|Bytes (Kb)"
column a5 format 999,999     heading "Next|Exts (Kb)"
column a6 format 9,999.99    heading "Avail|Extents"
column a7 format a10         heading "Segt Type"
break on owner skip 1

select
   b.owner, a.tablespace_name a1, b.segment_type a7, count(*) "Cnt"
from
  ( select tablespace_name, max(bytes) maxbyte, sum(bytes) sumbyte
    from dba_free_space
    group by tablespace_name ) a,
  ( select owner, tablespace_name, segment_name, segment_type, 
           next_extent nxtext
    from dba_segments
    where owner not in ('SYS','SYSTEM') ) b
where a.tablespace_name = b.tablespace_name(+)
and a.maxbyte/b.nxtext < 5
group by b.owner, a.tablespace_name, b.segment_type
order by b.owner, a.tablespace_name, b.segment_type ;

prompt 
prompt << Current Extents > 5 OR MaxExtents-Extents <= 5 >>

select owner, segment_type, tablespace_name, -- count(*) ,  extents, max_extents
  sum(decode(sign(100-extents),-1, 1, 0 ))  "Exts>100",  
  sum(decode(sign(max_extents-extents-5),-1, 1, 0 ))  "3Exts2Max"
from dba_segments
where ( extents > 100 or max_extents-extents < 5 )
and segment_type not in ('CACHE','ROLLBACK','TEMPORARY')
group by owner, segment_type, tablespace_name ;

prompt  
prompt << Listing all Invalid Objects >>

select owner, object_type, object_name, status 
  from all_objects
 where status = 'INVALID'
ORDER BY owner, object_type, object_name ;

select 
   decode( OBJECT_TYPE, 'PACKAGE BODY', 
   'alter package ' || OWNER||'.'||OBJECT_NAME || ' compile body;', 
   'alter ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' compile;' ) 
 from dba_objects 
where STATUS = 'INVALID' 
  and OBJECT_TYPE in ( 'PACKAGE BODY', 'PACKAGE', 'FUNCTION', 'PROCEDURE', 'TRIGGER', 'VIEW' ) 
order by OWNER, OBJECT_TYPE, OBJECT_NAME; 

prompt  
prompt << System Tablespace as Default/Temporary Tablespace >>

select 'alter user '||username||chr(10)||
       'default tablespace TOOLS '||CHR(10)||
       'temporary tablespace TEMP ; '
from dba_users
where ( DEFAULT_TABLESPACE = 'SYSTEM' or TEMPORARY_TABLESPACE = 'SYSTEM' )
 and username not in ('SYSTEM','SYS') ;

prompt  
prompt << Without Temporary Tablespace >>

SELECT TABLESPACE_NAME, CONTENTS
  from dba_tablespaces
 where 0 = ( select count(*) from dba_tablespaces
              where CONTENTS = 'TEMPORARY' ) ;

prompt
prompt << Coalesce fragmented tablespaces >>

select 'alter tablespace '||ts.tablespace_name ||
        ' coalesce      /* ' || to_char(percent_blocks_coalesced,'99.99') ||'  */ ;'
from dba_tablespaces ts,
     dba_free_space_coalesced co
where ts.tablespace_name not like 'RBS%' 
and ts.tablespace_name not like 'SYS%'
and ts.tablespace_name <> 'TEMP' 
and co.tablespace_name=ts.tablespace_name 
and percent_blocks_coalesced<>100
order by percent_blocks_coalesced desc ;

SET LINES 132 feed off

-- THIS SCRIPT MONITOR THE NUMBER OF TIMES ITEM IN THE
-- LIBRARY CACHE WAS EXECUTED ('PINS') & THE NUMBER OF
-- TIMES AN ITEM HAS TO BE REPARSED OR RELOADED DUE TO
-- IT BEING AGED FROM THE LIBRARY CACHE ('RELOADES').

PROMPT
PROMPT << LIBRARY CAHCE MONITOR >>

SELECT 
  SUM(RELOADS) " TOTAL LIBRARY CACHE MISSES ",
  SUM(PINS) " TOTAL LIBRARY CACHE HITS ",
  SUM(RELOADS) / SUM(PINS) * 100 "RATIO%% RELOADS TO PINS"
FROM V$LIBRARYCACHE ;

PROMPT
PROMPT ~~ THE RATIO OF RELOADS TO PINS SHOULD BE NEAR 0 ~~
PROMPT

-- THIS SCRIPT MONITOR THE NUMBER OF REQUESTS FOR DICTIONARY
-- DATA ('GETS') & THE NUMBER OF CACHE MISSES ('GETMISSES')

PROMPT 
PROMPT << DATA DICTIONARY CACHE MONITOR >>

SELECT 
  SUM(GETS) " DATA DICTIONARY GETS ",
  SUM(GETMISSES) " DATA DICTIONARY CACHE MISSES ",
  SUM(GETMISSES) / SUM(GETS) * 100 " RATIO GETMISSES TO GETS "
FROM V$ROWCACHE ;

PROMPT
PROMPT ~~ THE RATIO OF GETMISSES TO GETS SHOULD BE BELOW 5 PERCENT ~~
PROMPT

-- THIS SCRIPT MONITORS THE NUMBER OF SUCCESSFUL REQUESTS
-- RETRIEVED FROM BUFFERS IN MEMORY ANDTHE NUMBER OF REQUESTS
-- RETRIEVED FROM DATA FILES ON DISK

PROMPT 
PROMPT << REDO LOG BUFFER MONITOR >>

SELECT NAME, VALUE FROM V$SYSSTAT WHERE NAME = 'redo log space requests' ;

PROMPT
PROMPT ~~ THE ABOVE VALUE SHOULD BE NEAR TO 0 ~~
PROMPT

-- THIS SCRIPT MONITORS REDO LOG ACTIVITY AND IS USED TO DETERMINE
-- REDO LOG LATCH CONTENTION

COL NAME FORM A20
SELECT LN.NAME,GETS,MISSES,IMMEDIATE_GETS,IMMEDIATE_MISSES
FROM V$LATCH L , V$LATCHNAME LN
WHERE LN.NAME IN ('redo allocation','redo copy')
AND LN.LATCH# = L.LATCH# ;

PROMPT
SELECT SUM(MISSES) / SUM(GETS) * 100 "MISSES TO GETS - ALLOC"
FROM V$LATCH L,V$LATCHNAME LN
WHERE LN.NAME = 'redo allocation'
AND LN.LATCH# = L.LATCH# ;

PROMPT
SELECT SUM(MISSES) / SUM(GETS) * 100 "MISSES TO GETS - COPY"
FROM V$LATCH L,V$LATCHNAME LN
WHERE LN.NAME = 'redo copy'
AND LN.LATCH# = L.LATCH# ;

PROMPT
SELECT SUM(IMMEDIATE_MISSES) / (1+(SUM(IMMEDIATE_GETS) + SUM(IMMEDIATE_MISSES)))
* 100 "IMM MISSES TO IMM GETS - ALLOC"
FROM V$LATCH L,V$LATCHNAME LN
WHERE LN.NAME = 'redo allocation'
AND LN.LATCH# = L.LATCH# ;

PROMPT
SELECT SUM(IMMEDIATE_MISSES) / (SUM(IMMEDIATE_GETS) + SUM(IMMEDIATE_MISSES))
* 100 "IMM MISSES TO IMM GETS - COPY"
FROM V$LATCH L,V$LATCHNAME LN
WHERE LN.NAME = 'redo copy'
AND LN.LATCH# = L.LATCH# ;

SPOOL OFF
exit

