#!/bin/ksh
## Filename: /$SERVICE_GROUP/export/oracle/dbasql/orarpt_brkjobs.sh
## Usage: ./orarpt_dbstat.sh  $SG  $ORACLE_HOME  $ORA_SID

SERVICE_GROUP=$1  ; export SERVICE_GROUP
ORACLE_HOME=$2    ; export ORACLE_HOME
ORACLE_SID=$3     ; export ORACLE_SID

LD_LIBRARY_PATH=$ORACLE_HOME/lib 
export LD_LIBRARY_PATH

PATH=$PATH:$ORACLE_HOME/bin:/opt/bin
export PATH

ADMIN=samson.wk.cheung@db.com
export ADMIN

OUT_FILE=/tmp/orarpt_brkjobs_${ORACLE_SID}.out
export OUT_FILE

$ORACLE_HOME/bin/sqlplus / << EOF  >>  $OUT_FILE
@/$SERVICE_GROUP/export/oracle/dbasql/orarpt_brkjobs.sql
EOF
 
counter=`grep -i broken $OUT_FILE | wc -l` 
if [ -f $OUT_FILE -a $counter -gt 0 ] ; then
   cat $OUT_FILE | /usr/bin/mailx -r sl2.apho@db.com -s "Broken Jobs Report for $ORACLE_SID@`hostname` - `date '+%y%m%d' " $ADMIN
else 
   cat /dev/null  > $OUT_FILE ;
fi

exit 0

